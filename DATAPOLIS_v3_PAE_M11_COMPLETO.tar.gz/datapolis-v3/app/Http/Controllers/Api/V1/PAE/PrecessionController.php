<?php

namespace App\Http\Controllers\Api\V1\PAE;

use App\Http\Controllers\Api\V1\BaseController;
use App\Services\PrecessionService;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Http\Resources\PrecessionAnalysisResource;
use App\Http\Resources\PrecessionAlertResource;
use App\Http\Resources\PrecessionDashboardResource;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

/**
 * PrecessionController - API Controller para el módulo PAE M11
 * 
 * Expone endpoints RESTful para análisis precesionales, dashboard,
 * heatmaps, scoring de inversión, alertas y comparaciones.
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4.3
 */
class PrecessionController extends BaseController
{
    public function __construct(
        protected PrecessionService $precessionService
    ) {}

    /**
     * Ejecutar análisis precesional sobre una copropiedad
     * 
     * POST /api/v1/pae/analyze/copropiedad/{id}
     * 
     * @param Request $request
     * @param int $id ID de la copropiedad
     * @return JsonResponse
     */
    public function analyzeCopropiedad(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'horizon' => 'nullable|integer|min:6|max:120',
            'radius' => 'nullable|integer|min:100|max:10000',
            'max_depth' => 'nullable|integer|min:1|max:6',
            'include_ml' => 'nullable|boolean',
            'generate_heatmap' => 'nullable|boolean',
            'force_refresh' => 'nullable|boolean',
        ]);

        try {
            $result = $this->precessionService->analyzeCopropiedad($id, $validated);

            return $this->successResponse(
                new PrecessionAnalysisResource((object) $result),
                'Análisis precesional completado'
            );
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error ejecutando análisis precesional: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Obtener dashboard precesional de una copropiedad
     * 
     * GET /api/v1/pae/dashboard/{copropiedadId}
     * 
     * @param int $copropiedadId
     * @return JsonResponse
     */
    public function getDashboard(int $copropiedadId): JsonResponse
    {
        try {
            $dashboard = $this->precessionService->getDashboard($copropiedadId);

            return $this->successResponse($dashboard);
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error obteniendo dashboard: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Obtener heatmap precesional para un área
     * 
     * GET /api/v1/pae/heatmap
     * 
     * Query params: minLat, minLng, maxLat, maxLng
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function getHeatmap(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'minLat' => 'required|numeric|between:-90,90',
            'minLng' => 'required|numeric|between:-180,180',
            'maxLat' => 'required|numeric|between:-90,90',
            'maxLng' => 'required|numeric|between:-180,180',
        ]);

        try {
            $heatmap = $this->precessionService->getHeatmap($validated);

            return $this->successResponse($heatmap);
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error generando heatmap: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Calcular score de inversión ajustado por precesión
     * 
     * POST /api/v1/pae/investment-score
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function calculateInvestmentScore(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'copropiedad_id' => 'nullable|integer|exists:copropiedades,id',
            'predio_id' => 'nullable|integer|exists:predios,id',
            'valor_inversion' => 'nullable|numeric|min:0',
            'cap_rate' => 'nullable|numeric|min:0|max:30',
            'cash_on_cash' => 'nullable|numeric|min:0|max:50',
            'ocupacion' => 'nullable|numeric|min:0|max:100',
            'arriendo_mensual' => 'nullable|numeric|min:0',
        ]);

        try {
            $score = $this->precessionService->calculateInvestmentScore($validated);

            return $this->successResponse($score);
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error calculando score de inversión: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Obtener alertas precesionales activas
     * 
     * GET /api/v1/pae/alerts
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function getActiveAlerts(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'copropiedad_id' => 'nullable|integer',
            'severity' => 'nullable|in:low,medium,high,critical',
            'alert_type' => 'nullable|string',
            'limit' => 'nullable|integer|min:1|max:100',
        ]);

        try {
            $alerts = $this->precessionService->getActiveAlerts($validated);

            return $this->successResponse(
                PrecessionAlertResource::collection(collect($alerts))
            );
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error obteniendo alertas: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Reconocer una alerta
     * 
     * POST /api/v1/pae/alerts/{id}/acknowledge
     * 
     * @param string $id UUID de la alerta
     * @return JsonResponse
     */
    public function acknowledgeAlert(string $id): JsonResponse
    {
        $alert = PrecessionAlert::forTenant()->findOrFail($id);

        $alert->acknowledge(auth()->id());

        return $this->successResponse(
            new PrecessionAlertResource($alert),
            'Alerta reconocida'
        );
    }

    /**
     * Resolver una alerta
     * 
     * POST /api/v1/pae/alerts/{id}/resolve
     * 
     * @param Request $request
     * @param string $id UUID de la alerta
     * @return JsonResponse
     */
    public function resolveAlert(Request $request, string $id): JsonResponse
    {
        $validated = $request->validate([
            'resolution_notes' => 'nullable|string|max:1000',
        ]);

        $alert = PrecessionAlert::forTenant()->findOrFail($id);

        $alert->resolve($validated['resolution_notes'] ?? null);

        return $this->successResponse(
            new PrecessionAlertResource($alert),
            'Alerta resuelta'
        );
    }

    /**
     * Comparar análisis precesionales entre copropiedades
     * 
     * POST /api/v1/pae/compare
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function comparePrecession(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'copropiedad_ids' => 'required|array|min:2|max:10',
            'copropiedad_ids.*' => 'integer|exists:copropiedades,id',
        ]);

        try {
            $comparison = $this->precessionService->comparePrecession(
                $validated['copropiedad_ids']
            );

            return $this->successResponse($comparison);
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error comparando copropiedades: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Generar reporte para inversionistas
     * 
     * GET /api/v1/pae/report/{copropiedadId}
     * 
     * @param Request $request
     * @param int $copropiedadId
     * @return JsonResponse
     */
    public function generateInvestorReport(Request $request, int $copropiedadId): JsonResponse
    {
        $validated = $request->validate([
            'format' => 'nullable|in:json,pdf',
            'include_heatmap' => 'nullable|boolean',
            'include_predictions' => 'nullable|boolean',
        ]);

        try {
            $dashboard = $this->precessionService->getDashboard($copropiedadId);

            if (!$dashboard['has_analysis']) {
                return $this->errorResponse(
                    'No existe análisis precesional para esta copropiedad',
                    404
                );
            }

            $report = [
                'generated_at' => now()->toIso8601String(),
                'copropiedad' => $dashboard['copropiedad'],
                'executive_summary' => $this->generateExecutiveSummary($dashboard),
                'scores' => $dashboard['scores'],
                'value_analysis' => $dashboard['values_uf'],
                'effects_by_angle' => $dashboard['effects_summary'],
                'risk_assessment' => $this->generateRiskAssessment($dashboard),
                'opportunities' => $this->generateOpportunitiesAnalysis($dashboard),
                'predictions' => $validated['include_predictions'] ?? true 
                    ? $dashboard['ml_predictions'] 
                    : null,
                'alerts' => $dashboard['alerts'],
                'recommendations' => $this->generateRecommendations($dashboard),
            ];

            if ($validated['include_heatmap'] ?? false) {
                $report['heatmap'] = $dashboard['heatmap_data'];
            }

            // TODO: Generar PDF si format=pdf

            return $this->successResponse($report);
        } catch (\Exception $e) {
            return $this->errorResponse(
                'Error generando reporte: ' . $e->getMessage(),
                500
            );
        }
    }

    /**
     * Listar análisis precesionales
     * 
     * GET /api/v1/pae/analyses
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function listAnalyses(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'copropiedad_id' => 'nullable|integer',
            'status' => 'nullable|in:pending,processing,completed,failed,expired',
            'analysis_type' => 'nullable|string',
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date',
        ]);

        $query = PrecessionAnalysis::forTenant()
            ->with('copropiedad');

        if (isset($validated['copropiedad_id'])) {
            $query->where('copropiedad_id', $validated['copropiedad_id']);
        }

        if (isset($validated['status'])) {
            $query->where('status', $validated['status']);
        }

        if (isset($validated['analysis_type'])) {
            $query->where('analysis_type', $validated['analysis_type']);
        }

        if (isset($validated['from_date'])) {
            $query->whereDate('created_at', '>=', $validated['from_date']);
        }

        if (isset($validated['to_date'])) {
            $query->whereDate('created_at', '<=', $validated['to_date']);
        }

        $analyses = $query->orderByDesc('created_at')
            ->paginate($request->per_page ?? 15);

        return $this->successResponse(
            PrecessionAnalysisResource::collection($analyses)
        );
    }

    /**
     * Ver detalle de un análisis
     * 
     * GET /api/v1/pae/analyses/{id}
     * 
     * @param string $id UUID del análisis
     * @return JsonResponse
     */
    public function showAnalysis(string $id): JsonResponse
    {
        $analysis = PrecessionAnalysis::forTenant()
            ->with(['copropiedad', 'effects', 'alerts'])
            ->findOrFail($id);

        return $this->successResponse(
            new PrecessionAnalysisResource($analysis)
        );
    }

    // =========================================================
    // MÉTODOS AUXILIARES PARA REPORTES
    // =========================================================

    protected function generateExecutiveSummary(array $dashboard): array
    {
        $riskLevel = $this->categorizeScore($dashboard['scores']['risk'] ?? 0);
        $opportunityLevel = $this->categorizeScore($dashboard['scores']['opportunity'] ?? 0);

        return [
            'overall_assessment' => $this->getOverallAssessment($dashboard['scores']),
            'risk_level' => $riskLevel,
            'opportunity_level' => $opportunityLevel,
            'total_precession_value_uf' => $dashboard['values_uf']['total'] ?? 0,
            'key_findings' => $this->extractKeyFindings($dashboard),
        ];
    }

    protected function generateRiskAssessment(array $dashboard): array
    {
        return [
            'score' => $dashboard['scores']['risk'] ?? 0,
            'level' => $this->categorizeScore($dashboard['scores']['risk'] ?? 0),
            'primary_risks' => $this->extractPrimaryRisks($dashboard),
            'mitigation_strategies' => $this->suggestMitigationStrategies($dashboard),
        ];
    }

    protected function generateOpportunitiesAnalysis(array $dashboard): array
    {
        return [
            'score' => $dashboard['scores']['opportunity'] ?? 0,
            'level' => $this->categorizeScore($dashboard['scores']['opportunity'] ?? 0),
            'identified_opportunities' => $this->extractOpportunities($dashboard),
            'recommended_actions' => $this->suggestActions($dashboard),
        ];
    }

    protected function generateRecommendations(array $dashboard): array
    {
        $recommendations = [];

        if (($dashboard['scores']['risk'] ?? 0) > 0.6) {
            $recommendations[] = [
                'priority' => 'high',
                'category' => 'risk_mitigation',
                'recommendation' => 'Realizar due diligence exhaustivo antes de cualquier decisión de inversión',
            ];
        }

        if (($dashboard['scores']['opportunity'] ?? 0) > 0.7) {
            $recommendations[] = [
                'priority' => 'high',
                'category' => 'opportunity',
                'recommendation' => 'Considerar acción inmediata para aprovechar oportunidades precesionales identificadas',
            ];
        }

        if (($dashboard['values_uf']['precession'] ?? 0) > 0) {
            $recommendations[] = [
                'priority' => 'medium',
                'category' => 'monitoring',
                'recommendation' => 'Monitorear efectos precesionales a 90° que pueden materializarse en 12-24 meses',
            ];
        }

        return $recommendations;
    }

    protected function categorizeScore(float $score): string
    {
        return match (true) {
            $score >= 0.8 => 'critical',
            $score >= 0.6 => 'high',
            $score >= 0.4 => 'moderate',
            $score >= 0.2 => 'low',
            default => 'minimal',
        };
    }

    protected function getOverallAssessment(array $scores): string
    {
        $risk = $scores['risk'] ?? 0;
        $opportunity = $scores['opportunity'] ?? 0;

        if ($opportunity > 0.7 && $risk < 0.4) {
            return 'Altamente favorable - Oportunidades significativas con riesgo controlado';
        }

        if ($risk > 0.7) {
            return 'Requiere precaución - Riesgos precesionales elevados detectados';
        }

        if ($opportunity > 0.5) {
            return 'Favorable - Oportunidades moderadas identificadas';
        }

        return 'Neutral - Sin señales precesionales significativas';
    }

    protected function extractKeyFindings(array $dashboard): array
    {
        return [
            'Valor precesional total estimado: ' . number_format($dashboard['values_uf']['total'] ?? 0) . ' UF',
            'Efectos a 90° representan el mayor impacto potencial',
            'Confianza del análisis: ' . round(($dashboard['scores']['confidence'] ?? 0) * 100) . '%',
        ];
    }

    protected function extractPrimaryRisks(array $dashboard): array
    {
        $risks = [];
        
        if (($dashboard['values_uf']['counter'] ?? 0) < -50000) {
            $risks[] = 'Contra-precesión significativa detectada (efectos negativos a 180°)';
        }

        if (count($dashboard['alerts'] ?? []) > 0) {
            $risks[] = count($dashboard['alerts']) . ' alertas activas requieren atención';
        }

        return $risks;
    }

    protected function suggestMitigationStrategies(array $dashboard): array
    {
        return [
            'Diversificar inversiones para reducir exposición a efectos precesionales',
            'Mantener monitoreo activo de indicadores territoriales',
            'Considerar seguros contra riesgos identificados',
        ];
    }

    protected function extractOpportunities(array $dashboard): array
    {
        $opportunities = [];

        if (($dashboard['values_uf']['precession'] ?? 0) > 100000) {
            $opportunities[] = 'Valorización potencial por efectos precesionales positivos';
        }

        if (($dashboard['values_uf']['induced'] ?? 0) > 50000) {
            $opportunities[] = 'Efectos inducidos favorables en el corto plazo';
        }

        return $opportunities;
    }

    protected function suggestActions(array $dashboard): array
    {
        return [
            'Evaluar timing óptimo para entrada/salida de inversión',
            'Considerar expansión en zonas con efectos precesionales positivos',
        ];
    }
}

// =========================================================
// API RESOURCES
// =========================================================

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

/**
 * PrecessionAnalysisResource
 */
class PrecessionAnalysisResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'copropiedad_id' => $this->copropiedad_id,
            'analysis_type' => $this->analysis_type,
            'status' => $this->status,
            'location' => [
                'lat' => $this->latitud,
                'lng' => $this->longitud,
            ],
            'parameters' => [
                'radius_meters' => $this->radius_meters,
                'time_horizon_months' => $this->time_horizon_months,
                'max_depth' => $this->max_depth,
            ],
            'scores' => [
                'precession' => $this->precession_score,
                'risk' => $this->risk_score,
                'opportunity' => $this->opportunity_score,
                'confidence' => $this->confidence,
            ],
            'values_uf' => [
                'total' => $this->total_precession_value_uf,
                'direct_0' => $this->direct_value_uf,
                'induced_45' => $this->induced_value_uf,
                'precession_90' => $this->precession_value_uf,
                'systemic_135' => $this->systemic_value_uf,
                'counter_180' => $this->counter_value_uf,
            ],
            'effects' => [
                'direct' => $this->direct_effects,
                'induced' => $this->induced_effects,
                'precession' => $this->precession_effects,
                'systemic' => $this->systemic_effects,
                'counter' => $this->counter_effects,
            ],
            'ml_predictions' => $this->ml_predictions,
            'affected_parcels' => $this->affected_parcels_count,
            'completed_at' => $this->completed_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}

/**
 * PrecessionAlertResource
 */
class PrecessionAlertResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'alert_type' => $this->alert_type,
            'severity' => $this->severity,
            'precession_angle' => $this->precession_angle,
            'title' => $this->title,
            'description' => $this->description,
            'recommendation' => $this->recommendation,
            'metrics' => $this->metrics,
            'probability' => $this->probability,
            'potential_impact_uf' => $this->potential_impact_uf,
            'expected_months' => $this->expected_months,
            'status' => $this->status,
            'copropiedad_id' => $this->copropiedad_id,
            'acknowledged_at' => $this->acknowledged_at?->toIso8601String(),
            'resolved_at' => $this->resolved_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
