<?php

namespace App\Models\PAE;

use App\Models\Traits\HasTenant;
use App\Models\PropTech\Copropiedad;
use App\Models\Core\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

/**
 * PrecessionAnalysis - Modelo para análisis precesionales
 * 
 * Representa un análisis precesional ejecutado sobre una entidad
 * (copropiedad, predio, comuna, proyecto). Almacena los resultados
 * del análisis incluyendo efectos por ángulo (0°, 45°, 90°, 135°, 180°),
 * predicciones ML y zonas de influencia geoespacial.
 * 
 * @property string $id UUID
 * @property int $tenant_id
 * @property int|null $copropiedad_id
 * @property string $analysis_type
 * @property float|null $precession_score
 * @property float|null $risk_score
 * @property float|null $opportunity_score
 * @property array|null $ml_predictions
 * @property string $status
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4
 */
class PrecessionAnalysis extends Model
{
    use HasUuids, HasTenant, SoftDeletes;

    protected $table = 'precession_analyses';
    protected $keyType = 'string';
    public $incrementing = false;

    /**
     * Ángulos precesionales según teoría de Fuller
     */
    public const ANGLE_DIRECT = 'direct_0';
    public const ANGLE_INDUCED = 'induced_45';
    public const ANGLE_PRECESSION = 'precession_90';
    public const ANGLE_SYSTEMIC = 'systemic_135';
    public const ANGLE_COUNTER = 'counter_180';

    public const ANGLES = [
        self::ANGLE_DIRECT,
        self::ANGLE_INDUCED,
        self::ANGLE_PRECESSION,
        self::ANGLE_SYSTEMIC,
        self::ANGLE_COUNTER,
    ];

    /**
     * Tipos de análisis soportados
     */
    public const TYPE_COPROPIEDAD = 'copropiedad_precession';
    public const TYPE_TERRITORIAL = 'territorial_intervention';
    public const TYPE_MARKET = 'market_impact';
    public const TYPE_REGULATORY = 'regulatory_change';
    public const TYPE_INFRASTRUCTURE = 'infrastructure_project';
    public const TYPE_INVESTMENT = 'investment_assessment';

    /**
     * Estados del análisis
     */
    public const STATUS_PENDING = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_FAILED = 'failed';
    public const STATUS_EXPIRED = 'expired';

    protected $fillable = [
        'tenant_id',
        'analyzable_type',
        'analyzable_id',
        'copropiedad_id',
        'latitud',
        'longitud',
        'analysis_type',
        'radius_meters',
        'time_horizon_months',
        'max_depth',
        'context_financial',
        'context_compliance',
        'context_building',
        'context_territorial',
        'precession_score',
        'risk_score',
        'opportunity_score',
        'confidence',
        'total_precession_value_uf',
        'direct_value_uf',
        'induced_value_uf',
        'precession_value_uf',
        'systemic_value_uf',
        'counter_value_uf',
        'ml_predictions',
        'ml_confidence',
        'ml_model_version',
        'direct_effects',
        'induced_effects',
        'precession_effects',
        'systemic_effects',
        'counter_effects',
        'influence_zones',
        'affected_parcels_count',
        'heatmap_data',
        'status',
        'error_message',
        'completed_at',
        'expires_at',
        'requested_by',
        'request_ip',
    ];

    protected $casts = [
        'latitud' => 'decimal:8',
        'longitud' => 'decimal:8',
        'radius_meters' => 'integer',
        'time_horizon_months' => 'integer',
        'max_depth' => 'integer',
        'context_financial' => 'array',
        'context_compliance' => 'array',
        'context_building' => 'array',
        'context_territorial' => 'array',
        'precession_score' => 'decimal:4',
        'risk_score' => 'decimal:4',
        'opportunity_score' => 'decimal:4',
        'confidence' => 'decimal:4',
        'total_precession_value_uf' => 'decimal:2',
        'direct_value_uf' => 'decimal:2',
        'induced_value_uf' => 'decimal:2',
        'precession_value_uf' => 'decimal:2',
        'systemic_value_uf' => 'decimal:2',
        'counter_value_uf' => 'decimal:2',
        'ml_predictions' => 'array',
        'ml_confidence' => 'decimal:4',
        'direct_effects' => 'array',
        'induced_effects' => 'array',
        'precession_effects' => 'array',
        'systemic_effects' => 'array',
        'counter_effects' => 'array',
        'influence_zones' => 'array',
        'affected_parcels_count' => 'integer',
        'heatmap_data' => 'array',
        'completed_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    // =========================================================
    // RELACIONES
    // =========================================================

    /**
     * Entidad analizada (polimórfica)
     */
    public function analyzable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Copropiedad asociada (referencia directa)
     */
    public function copropiedad(): BelongsTo
    {
        return $this->belongsTo(Copropiedad::class);
    }

    /**
     * Usuario que solicitó el análisis
     */
    public function requestedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    /**
     * Efectos detallados del análisis
     */
    public function effects(): HasMany
    {
        return $this->hasMany(PrecessionEffect::class, 'analysis_id');
    }

    /**
     * Alertas generadas por este análisis
     */
    public function alerts(): HasMany
    {
        return $this->hasMany(PrecessionAlert::class, 'analysis_id');
    }

    // =========================================================
    // SCOPES ESPACIALES (PostGIS)
    // =========================================================

    /**
     * Filtrar por radio desde un punto
     */
    public function scopeWithinRadius(Builder $query, float $lat, float $lng, int $radiusMeters): Builder
    {
        return $query->whereRaw("
            ST_DWithin(
                location::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography,
                ?
            )
        ", [$lng, $lat, $radiusMeters]);
    }

    /**
     * Filtrar por bounding box
     */
    public function scopeWithinBounds(Builder $query, float $minLat, float $minLng, float $maxLat, float $maxLng): Builder
    {
        return $query->whereRaw("
            location && ST_MakeEnvelope(?, ?, ?, ?, 4326)
        ", [$minLng, $minLat, $maxLng, $maxLat]);
    }

    /**
     * Ordenar por distancia a un punto
     */
    public function scopeOrderByDistance(Builder $query, float $lat, float $lng): Builder
    {
        return $query->orderByRaw("
            ST_Distance(
                location::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography
            )
        ", [$lng, $lat]);
    }

    /**
     * Agregar distancia como columna calculada
     */
    public function scopeWithDistanceTo(Builder $query, float $lat, float $lng): Builder
    {
        return $query->selectRaw("
            *, ST_Distance(
                location::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography
            ) as distance_meters
        ", [$lng, $lat]);
    }

    // =========================================================
    // SCOPES DE ESTADO
    // =========================================================

    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    public function scopeProcessing(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PROCESSING);
    }

    public function scopeCompleted(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_COMPLETED);
    }

    public function scopeFailed(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_FAILED);
    }

    public function scopeValid(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_COMPLETED)
            ->where(function ($q) {
                $q->whereNull('expires_at')
                    ->orWhere('expires_at', '>', now());
            });
    }

    public function scopeExpired(Builder $query): Builder
    {
        return $query->where('expires_at', '<=', now());
    }

    // =========================================================
    // SCOPES DE TIPO
    // =========================================================

    public function scopeOfType(Builder $query, string $type): Builder
    {
        return $query->where('analysis_type', $type);
    }

    public function scopeCopropiedadAnalyses(Builder $query): Builder
    {
        return $query->where('analysis_type', self::TYPE_COPROPIEDAD);
    }

    public function scopeHighRisk(Builder $query, float $threshold = 0.7): Builder
    {
        return $query->where('risk_score', '>=', $threshold);
    }

    public function scopeHighOpportunity(Builder $query, float $threshold = 0.7): Builder
    {
        return $query->where('opportunity_score', '>=', $threshold);
    }

    // =========================================================
    // MÉTODOS DE INSTANCIA
    // =========================================================

    /**
     * Verificar si el análisis está completo
     */
    public function isCompleted(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    /**
     * Verificar si el análisis está expirado
     */
    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    /**
     * Verificar si el análisis es válido (completo y no expirado)
     */
    public function isValid(): bool
    {
        return $this->isCompleted() && !$this->isExpired();
    }

    /**
     * Obtener efectos por ángulo
     */
    public function getEffectsByAngle(string $angle): array
    {
        $property = str_replace('_', '_', $angle) . '_effects';
        return $this->{$property} ?? [];
    }

    /**
     * Obtener valor por ángulo
     */
    public function getValueByAngle(string $angle): ?float
    {
        $property = str_replace('_', '_', $angle) . '_value_uf';
        return $this->{$property};
    }

    /**
     * Obtener resumen de efectos
     */
    public function getEffectsSummary(): array
    {
        return [
            self::ANGLE_DIRECT => [
                'count' => count($this->direct_effects ?? []),
                'value_uf' => $this->direct_value_uf,
            ],
            self::ANGLE_INDUCED => [
                'count' => count($this->induced_effects ?? []),
                'value_uf' => $this->induced_value_uf,
            ],
            self::ANGLE_PRECESSION => [
                'count' => count($this->precession_effects ?? []),
                'value_uf' => $this->precession_value_uf,
            ],
            self::ANGLE_SYSTEMIC => [
                'count' => count($this->systemic_effects ?? []),
                'value_uf' => $this->systemic_value_uf,
            ],
            self::ANGLE_COUNTER => [
                'count' => count($this->counter_effects ?? []),
                'value_uf' => $this->counter_value_uf,
            ],
        ];
    }

    /**
     * Marcar como completado
     */
    public function markAsCompleted(array $results): void
    {
        $this->update([
            'status' => self::STATUS_COMPLETED,
            'completed_at' => now(),
            'expires_at' => now()->addHours(config('datapolis.pae.cache_ttl_hours', 24)),
            ...$results,
        ]);
    }

    /**
     * Marcar como fallido
     */
    public function markAsFailed(string $error): void
    {
        $this->update([
            'status' => self::STATUS_FAILED,
            'error_message' => $error,
            'completed_at' => now(),
        ]);
    }

    /**
     * Actualizar location PostGIS al guardar
     */
    protected static function booted(): void
    {
        static::saving(function (self $model) {
            if ($model->latitud && $model->longitud) {
                DB::statement("
                    UPDATE precession_analyses 
                    SET location = ST_SetSRID(ST_MakePoint(?, ?), 4326)
                    WHERE id = ?
                ", [$model->longitud, $model->latitud, $model->id]);
            }
        });
    }
}

/**
 * PrecessionGraphNode - Nodo de la ontología territorial
 * 
 * Representa una variable, indicador, evento o estado del sistema
 * territorial que puede ser afectado por efectos precesionales.
 */
class PrecessionGraphNode extends Model
{
    use HasUuids, HasTenant;

    protected $table = 'precession_graph_nodes';
    protected $keyType = 'string';
    public $incrementing = false;

    public const DOMAIN_ECONOMIC = 'economic';
    public const DOMAIN_SOCIAL = 'social';
    public const DOMAIN_NORMATIVE = 'normative';
    public const DOMAIN_ENVIRONMENTAL = 'environmental';
    public const DOMAIN_INFRASTRUCTURE = 'infrastructure';

    public const TYPE_VARIABLE = 'variable';
    public const TYPE_INDICATOR = 'indicator';
    public const TYPE_EVENT = 'event';
    public const TYPE_STATE = 'state';

    protected $fillable = [
        'tenant_id',
        'code',
        'name',
        'description',
        'domain',
        'node_type',
        'unit',
        'data_source',
        'update_frequency',
        'current_value',
        'min_value',
        'max_value',
        'avg_value',
        'std_deviation',
        'feature_importance',
        'correlations',
        'is_active',
        'is_system',
    ];

    protected $casts = [
        'current_value' => 'decimal:6',
        'min_value' => 'decimal:6',
        'max_value' => 'decimal:6',
        'avg_value' => 'decimal:6',
        'std_deviation' => 'decimal:6',
        'feature_importance' => 'array',
        'correlations' => 'array',
        'is_active' => 'boolean',
        'is_system' => 'boolean',
    ];

    /**
     * Relaciones salientes (este nodo es source)
     */
    public function outgoingEdges(): HasMany
    {
        return $this->hasMany(PrecessionGraphEdge::class, 'source_node_id');
    }

    /**
     * Relaciones entrantes (este nodo es target)
     */
    public function incomingEdges(): HasMany
    {
        return $this->hasMany(PrecessionGraphEdge::class, 'target_node_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeByDomain(Builder $query, string $domain): Builder
    {
        return $query->where('domain', $domain);
    }

    public function scopeSystem(Builder $query): Builder
    {
        return $query->where('is_system', true);
    }
}

/**
 * PrecessionGraphEdge - Relación precesional entre nodos
 * 
 * Representa una relación causa-efecto entre dos variables
 * del sistema territorial, con su ángulo precesional, peso,
 * lag temporal y nivel de confianza.
 */
class PrecessionGraphEdge extends Model
{
    use HasUuids, HasTenant;

    protected $table = 'precession_graph_edges';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'tenant_id',
        'source_node_id',
        'target_node_id',
        'precession_angle',
        'weight',
        'temporal_lag_months',
        'confidence',
        'evidence_source',
        'evidence_description',
        'evidence_data',
        'ml_predicted_weight',
        'ml_confidence',
        'ml_last_trained_at',
        'is_active',
        'is_system',
    ];

    protected $casts = [
        'weight' => 'decimal:4',
        'temporal_lag_months' => 'integer',
        'confidence' => 'decimal:4',
        'evidence_data' => 'array',
        'ml_predicted_weight' => 'decimal:4',
        'ml_confidence' => 'decimal:4',
        'ml_last_trained_at' => 'datetime',
        'is_active' => 'boolean',
        'is_system' => 'boolean',
    ];

    public function sourceNode(): BelongsTo
    {
        return $this->belongsTo(PrecessionGraphNode::class, 'source_node_id');
    }

    public function targetNode(): BelongsTo
    {
        return $this->belongsTo(PrecessionGraphNode::class, 'target_node_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeByAngle(Builder $query, string $angle): Builder
    {
        return $query->where('precession_angle', $angle);
    }

    public function scopeHighConfidence(Builder $query, float $threshold = 0.7): Builder
    {
        return $query->where('confidence', '>=', $threshold);
    }
}

/**
 * PrecessionEffect - Efecto individual detectado en un análisis
 */
class PrecessionEffect extends Model
{
    use HasUuids;

    protected $table = 'precession_effects';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'analysis_id',
        'source_node_id',
        'target_node_id',
        'angle',
        'depth',
        'intensity',
        'value_uf',
        'probability',
        'manifestation_months',
        'description',
        'supporting_data',
    ];

    protected $casts = [
        'depth' => 'integer',
        'intensity' => 'decimal:4',
        'value_uf' => 'decimal:2',
        'probability' => 'decimal:4',
        'manifestation_months' => 'integer',
        'supporting_data' => 'array',
    ];

    public function analysis(): BelongsTo
    {
        return $this->belongsTo(PrecessionAnalysis::class, 'analysis_id');
    }

    public function sourceNode(): BelongsTo
    {
        return $this->belongsTo(PrecessionGraphNode::class, 'source_node_id');
    }

    public function targetNode(): BelongsTo
    {
        return $this->belongsTo(PrecessionGraphNode::class, 'target_node_id');
    }
}

/**
 * PrecessionAlert - Alerta predictiva precesional
 * 
 * Representa una alerta generada por el análisis precesional,
 * indicando riesgos, oportunidades o cambios de tendencia.
 */
class PrecessionAlert extends Model
{
    use HasUuids, HasTenant, SoftDeletes;

    protected $table = 'precession_alerts';
    protected $keyType = 'string';
    public $incrementing = false;

    public const TYPE_RISK = 'risk_threshold';
    public const TYPE_OPPORTUNITY = 'opportunity_detected';
    public const TYPE_TREND = 'trend_change';
    public const TYPE_ANOMALY = 'anomaly_detected';
    public const TYPE_DEADLINE = 'deadline_approaching';
    public const TYPE_REGULATORY = 'regulatory_impact';
    public const TYPE_MARKET = 'market_shift';

    public const SEVERITY_LOW = 'low';
    public const SEVERITY_MEDIUM = 'medium';
    public const SEVERITY_HIGH = 'high';
    public const SEVERITY_CRITICAL = 'critical';

    public const STATUS_ACTIVE = 'active';
    public const STATUS_ACKNOWLEDGED = 'acknowledged';
    public const STATUS_RESOLVED = 'resolved';
    public const STATUS_DISMISSED = 'dismissed';
    public const STATUS_EXPIRED = 'expired';

    protected $fillable = [
        'tenant_id',
        'analysis_id',
        'alertable_type',
        'alertable_id',
        'copropiedad_id',
        'alert_type',
        'severity',
        'precession_angle',
        'title',
        'description',
        'recommendation',
        'affected_entities',
        'metrics',
        'probability',
        'potential_impact_uf',
        'expected_months',
        'status',
        'acknowledged_by',
        'acknowledged_at',
        'resolution_notes',
        'resolved_at',
        'expires_at',
        'notification_sent',
        'notification_sent_at',
        'notification_channels',
    ];

    protected $casts = [
        'affected_entities' => 'array',
        'metrics' => 'array',
        'probability' => 'decimal:4',
        'potential_impact_uf' => 'decimal:2',
        'expected_months' => 'integer',
        'acknowledged_at' => 'datetime',
        'resolved_at' => 'datetime',
        'expires_at' => 'datetime',
        'notification_sent' => 'boolean',
        'notification_sent_at' => 'datetime',
        'notification_channels' => 'array',
    ];

    public function analysis(): BelongsTo
    {
        return $this->belongsTo(PrecessionAnalysis::class, 'analysis_id');
    }

    public function alertable(): MorphTo
    {
        return $this->morphTo();
    }

    public function copropiedad(): BelongsTo
    {
        return $this->belongsTo(Copropiedad::class);
    }

    public function acknowledgedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'acknowledged_by');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    public function scopeBySeverity(Builder $query, string $severity): Builder
    {
        return $query->where('severity', $severity);
    }

    public function scopeCritical(Builder $query): Builder
    {
        return $query->where('severity', self::SEVERITY_CRITICAL);
    }

    public function scopeUnacknowledged(Builder $query): Builder
    {
        return $query->whereIn('status', [self::STATUS_ACTIVE]);
    }

    public function acknowledge(int $userId): void
    {
        $this->update([
            'status' => self::STATUS_ACKNOWLEDGED,
            'acknowledged_by' => $userId,
            'acknowledged_at' => now(),
        ]);
    }

    public function resolve(string $notes = null): void
    {
        $this->update([
            'status' => self::STATUS_RESOLVED,
            'resolution_notes' => $notes,
            'resolved_at' => now(),
        ]);
    }

    public function dismiss(): void
    {
        $this->update([
            'status' => self::STATUS_DISMISSED,
        ]);
    }
}

/**
 * PrecessionComparison - Comparación entre entidades
 */
class PrecessionComparison extends Model
{
    use HasUuids, HasTenant;

    protected $table = 'precession_comparisons';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'tenant_id',
        'comparison_name',
        'description',
        'entity_ids',
        'entity_type',
        'comparison_results',
        'best_performer_id',
        'highest_risk_id',
        'best_opportunity_id',
        'avg_precession_score',
        'avg_risk_score',
        'avg_opportunity_score',
        'created_by',
    ];

    protected $casts = [
        'entity_ids' => 'array',
        'comparison_results' => 'array',
        'avg_precession_score' => 'decimal:4',
        'avg_risk_score' => 'decimal:4',
        'avg_opportunity_score' => 'decimal:4',
    ];

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
