<?php

namespace App\Services;

use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Models\PAE\PrecessionComparison;
use App\Models\PAE\PrecessionGraphNode;
use App\Models\PAE\PrecessionGraphEdge;
use App\Models\PropTech\Copropiedad;
use App\Events\PrecessionAnalysisCompleted;
use App\Events\PrecessionAlertTriggered;
use App\Exceptions\PrecessionAnalysisException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * PrecessionService - Servicio principal del módulo PAE M11
 * 
 * Implementa la lógica de negocio para análisis precesionales sobre
 * copropiedades y entidades territoriales. Integra con el PAE Core
 * (Multi-Agent M11 FastAPI) y gestiona cache, alertas y comparaciones.
 * 
 * Basado en la teoría de precesión sistémica de R. Buckminster Fuller,
 * el servicio analiza efectos indirectos (a 90°) de intervenciones
 * urbanas e inmobiliarias.
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4
 */
class PrecessionService
{
    /**
     * URL base del PAE Core API
     */
    protected string $paeApiUrl;

    /**
     * API Key para autenticación
     */
    protected string $paeApiKey;

    /**
     * TTL de cache para análisis (segundos)
     */
    protected int $analysisCacheTtl;

    /**
     * TTL de cache para scoring (segundos)
     */
    protected int $scoringCacheTtl;

    /**
     * Timeout HTTP en segundos
     */
    protected int $httpTimeout;

    public function __construct()
    {
        $this->paeApiUrl = config('datapolis.pae.api_url', 'http://localhost:8000/api/v1/pae');
        $this->paeApiKey = config('datapolis.pae.api_key', '');
        $this->analysisCacheTtl = config('datapolis.pae.cache_ttl_analysis', 3600); // 1 hora
        $this->scoringCacheTtl = config('datapolis.pae.cache_ttl_scoring', 86400); // 24 horas
        $this->httpTimeout = config('datapolis.pae.http_timeout', 30);
    }

    // =========================================================
    // ANÁLISIS DE COPROPIEDADES
    // =========================================================

    /**
     * Analiza efectos precesionales sobre una copropiedad.
     * 
     * Integra datos de módulos DATAPOLIS existentes (M01-M23) para
     * construir el contexto precesional y llama al PAE Core para
     * ejecutar el análisis completo.
     * 
     * @param int $copropiedadId ID de la copropiedad
     * @param array $options Opciones: horizon, radius, force_refresh
     * @return array Resultados del análisis precesional
     * @throws PrecessionAnalysisException
     */
    public function analyzeCopropiedad(int $copropiedadId, array $options = []): array
    {
        // Verificar cache si no se fuerza refresh
        if (!($options['force_refresh'] ?? false)) {
            $cached = $this->getCachedAnalysis($copropiedadId, 'copropiedad');
            if ($cached) {
                return $cached;
            }
        }

        // Cargar copropiedad con relaciones
        $copropiedad = Copropiedad::with([
            'unidades',
            'unidades.propietario',
            'gastosComunes' => fn($q) => $q->latest()->limit(12),
            // 'compliance',
            // 'tributario',
        ])->findOrFail($copropiedadId);

        // Construir contexto precesional desde módulos DATAPOLIS
        $context = $this->buildCopropiedadContext($copropiedad);

        // Crear registro de análisis pendiente
        $analysis = PrecessionAnalysis::create([
            'tenant_id' => tenant()->id,
            'copropiedad_id' => $copropiedadId,
            'analyzable_type' => Copropiedad::class,
            'analyzable_id' => $copropiedadId,
            'latitud' => $copropiedad->latitud,
            'longitud' => $copropiedad->longitud,
            'analysis_type' => PrecessionAnalysis::TYPE_COPROPIEDAD,
            'radius_meters' => $options['radius'] ?? 1000,
            'time_horizon_months' => $options['horizon'] ?? 36,
            'max_depth' => $options['max_depth'] ?? 4,
            'context_financial' => $context['financial'],
            'context_compliance' => $context['compliance'],
            'context_building' => $context['building'],
            'status' => PrecessionAnalysis::STATUS_PROCESSING,
            'requested_by' => auth()->id(),
            'request_ip' => request()->ip(),
        ]);

        try {
            // Llamar al PAE Core (Multi-Agent M11 FastAPI)
            $response = Http::withToken($this->paeApiKey)
                ->timeout($this->httpTimeout)
                ->post("{$this->paeApiUrl}/analyze", [
                    'context' => $context,
                    'analysis_type' => 'copropiedad_precession',
                    'time_horizon_months' => $options['horizon'] ?? 36,
                    'radius_meters' => $options['radius'] ?? 1000,
                    'max_depth' => $options['max_depth'] ?? 4,
                    'include_ml_predictions' => $options['include_ml'] ?? true,
                    'generate_heatmap' => $options['generate_heatmap'] ?? true,
                ]);

            if ($response->successful()) {
                $results = $response->json();

                // Actualizar análisis con resultados
                $analysis->markAsCompleted([
                    'precession_score' => $results['total_precession_value'] ?? 0,
                    'risk_score' => $results['risk_score'] ?? 0,
                    'opportunity_score' => $results['opportunity_score'] ?? 0,
                    'confidence' => $results['confidence'] ?? 0,
                    'total_precession_value_uf' => $results['total_value_uf'] ?? 0,
                    'direct_value_uf' => $results['direct_value_uf'] ?? 0,
                    'induced_value_uf' => $results['induced_value_uf'] ?? 0,
                    'precession_value_uf' => $results['precession_value_uf'] ?? 0,
                    'systemic_value_uf' => $results['systemic_value_uf'] ?? 0,
                    'counter_value_uf' => $results['counter_value_uf'] ?? 0,
                    'ml_predictions' => $results['ml_predictions'] ?? null,
                    'ml_confidence' => $results['ml_confidence'] ?? null,
                    'ml_model_version' => $results['ml_model_version'] ?? null,
                    'direct_effects' => $results['direct_effects'] ?? [],
                    'induced_effects' => $results['induced_effects'] ?? [],
                    'precession_effects' => $results['precession_effects'] ?? [],
                    'systemic_effects' => $results['systemic_effects'] ?? [],
                    'counter_effects' => $results['counter_effects'] ?? [],
                    'influence_zones' => $results['influence_zones'] ?? null,
                    'affected_parcels_count' => $results['affected_parcels'] ?? 0,
                    'heatmap_data' => $results['heatmap_data'] ?? null,
                ]);

                // Generar alertas si corresponde
                $this->generateAlertsFromAnalysis($analysis, $results);

                // Cachear resultado
                $this->cacheAnalysis($copropiedadId, 'copropiedad', $analysis->toArray());

                // Publicar evento
                event(new PrecessionAnalysisCompleted($analysis));

                return $analysis->fresh()->toArray();
            }

            throw new PrecessionAnalysisException(
                'PAE Core respondió con error: ' . $response->body()
            );
        } catch (\Exception $e) {
            $analysis->markAsFailed($e->getMessage());

            Log::error('PrecessionService: Error en análisis', [
                'copropiedad_id' => $copropiedadId,
                'error' => $e->getMessage(),
            ]);

            // En caso de error, intentar análisis local fallback
            if (config('datapolis.pae.fallback_enabled', true)) {
                return $this->executeLocalAnalysis($analysis, $context);
            }

            throw new PrecessionAnalysisException(
                'Error ejecutando análisis precesional: ' . $e->getMessage(),
                previous: $e
            );
        }
    }

    /**
     * Construye el contexto precesional desde datos de copropiedad
     */
    protected function buildCopropiedadContext(Copropiedad $copropiedad): array
    {
        return [
            'location' => [
                'lat' => $copropiedad->latitud,
                'lng' => $copropiedad->longitud,
                'comuna' => $copropiedad->comuna,
                'region' => $copropiedad->region ?? 'Metropolitana',
            ],
            'financial' => [
                'morosidad_rate' => $this->calcMorosidad($copropiedad),
                'gasto_comun_avg' => $copropiedad->gastosComunes->avg('monto_total') ?? 0,
                'gasto_comun_trend' => $this->calcGastoTrend($copropiedad),
                'valor_tasacion_uf' => $copropiedad->valor_tasacion_uf ?? 0,
                'fondo_reserva' => $copropiedad->fondo_reserva ?? 0,
                'deuda_total' => $this->calcDeudaTotal($copropiedad),
            ],
            'compliance' => [
                'score_ds7' => $copropiedad->compliance_score ?? 0,
                'ley_21442_status' => $copropiedad->ley21442_status ?? 'pending',
                'reglamento_inscrito' => $copropiedad->reglamento_inscrito ?? false,
                'administrador_vigente' => !empty($copropiedad->nombre_administracion),
                'cuenta_bancaria_exclusiva' => !empty($copropiedad->cuenta_bancaria),
                'declaraciones_pendientes' => $this->getPendingDeclarations($copropiedad),
            ],
            'building' => [
                'unidades_total' => $copropiedad->unidades->count(),
                'unidades_habitadas' => $copropiedad->unidades->where('estado', 'habitada')->count(),
                'antiguedad_anos' => $copropiedad->ano_construccion 
                    ? now()->year - $copropiedad->ano_construccion 
                    : null,
                'tipo' => $copropiedad->tipo,
                'pisos' => $copropiedad->numero_pisos,
                'superficie_total' => $copropiedad->superficie_total,
            ],
        ];
    }

    /**
     * Calcula tasa de morosidad de la copropiedad
     */
    protected function calcMorosidad(Copropiedad $copropiedad): float
    {
        $totalUnidades = $copropiedad->unidades->count();
        if ($totalUnidades === 0) return 0;

        $morosas = $copropiedad->unidades->filter(function ($unidad) {
            return $unidad->gastosComunes()
                ->where('estado', 'pendiente')
                ->where('fecha_vencimiento', '<', now())
                ->exists();
        })->count();

        return round(($morosas / $totalUnidades) * 100, 2);
    }

    /**
     * Calcula tendencia de gastos comunes (últimos 12 meses)
     */
    protected function calcGastoTrend(Copropiedad $copropiedad): float
    {
        $gastos = $copropiedad->gastosComunes()
            ->orderByDesc('ano')
            ->orderByDesc('mes')
            ->limit(12)
            ->pluck('monto_total')
            ->reverse()
            ->values();

        if ($gastos->count() < 2) return 0;

        $first = $gastos->first();
        $last = $gastos->last();

        if ($first == 0) return 0;

        return round((($last - $first) / $first) * 100, 2);
    }

    /**
     * Calcula deuda total de la copropiedad
     */
    protected function calcDeudaTotal(Copropiedad $copropiedad): float
    {
        return $copropiedad->unidades()
            ->with('gastosComunes')
            ->get()
            ->flatMap(fn($u) => $u->gastosComunes)
            ->where('estado', 'pendiente')
            ->sum('monto_total');
    }

    /**
     * Obtiene declaraciones tributarias pendientes
     */
    protected function getPendingDeclarations(Copropiedad $copropiedad): int
    {
        // Implementar según módulo tributario existente
        return 0;
    }

    // =========================================================
    // SCORING DE INVERSIÓN
    // =========================================================

    /**
     * Calcula score de inversión ajustado por precesión
     * 
     * @param array $investmentData Datos de la inversión
     * @return array Score y desglose precesional
     */
    public function calculateInvestmentScore(array $investmentData): array
    {
        $cacheKey = 'pae:investment:' . md5(json_encode($investmentData));

        return Cache::remember($cacheKey, $this->scoringCacheTtl, function () use ($investmentData) {
            $copropiedadId = $investmentData['copropiedad_id'] ?? null;
            
            // Obtener análisis precesional existente o ejecutar nuevo
            if ($copropiedadId) {
                $analysis = PrecessionAnalysis::forTenant()
                    ->where('copropiedad_id', $copropiedadId)
                    ->valid()
                    ->latest()
                    ->first();

                if (!$analysis) {
                    $this->analyzeCopropiedad($copropiedadId);
                    $analysis = PrecessionAnalysis::forTenant()
                        ->where('copropiedad_id', $copropiedadId)
                        ->completed()
                        ->latest()
                        ->first();
                }
            }

            // Calcular score base tradicional
            $baseScore = $this->calculateBaseInvestmentScore($investmentData);

            // Ajustar por factores precesionales
            $precessionAdjustment = $this->calculatePrecessionAdjustment($analysis ?? null);

            $finalScore = $baseScore * (1 + $precessionAdjustment);

            return [
                'base_score' => round($baseScore, 2),
                'precession_adjustment' => round($precessionAdjustment * 100, 2),
                'final_score' => round($finalScore, 2),
                'risk_level' => $this->categorizeRisk($analysis?->risk_score ?? 0.5),
                'opportunity_level' => $this->categorizeOpportunity($analysis?->opportunity_score ?? 0.5),
                'precession_effects' => [
                    'direct' => $analysis?->direct_value_uf ?? 0,
                    'induced' => $analysis?->induced_value_uf ?? 0,
                    'precession' => $analysis?->precession_value_uf ?? 0,
                    'systemic' => $analysis?->systemic_value_uf ?? 0,
                    'counter' => $analysis?->counter_value_uf ?? 0,
                ],
                'recommendations' => $this->generateInvestmentRecommendations($analysis, $investmentData),
                'confidence' => $analysis?->confidence ?? 0.5,
            ];
        });
    }

    protected function calculateBaseInvestmentScore(array $data): float
    {
        $score = 50; // Base

        // Cap Rate
        if (isset($data['cap_rate'])) {
            $score += min(($data['cap_rate'] - 4) * 5, 20);
        }

        // Cash on Cash
        if (isset($data['cash_on_cash'])) {
            $score += min(($data['cash_on_cash'] - 5) * 3, 15);
        }

        // Ocupación
        if (isset($data['ocupacion'])) {
            $score += ($data['ocupacion'] - 80) * 0.5;
        }

        return max(0, min(100, $score));
    }

    protected function calculatePrecessionAdjustment(?PrecessionAnalysis $analysis): float
    {
        if (!$analysis) return 0;

        $adjustment = 0;

        // Ajuste por oportunidades precesionales
        $adjustment += ($analysis->opportunity_score ?? 0) * 0.15;

        // Penalización por riesgos
        $adjustment -= ($analysis->risk_score ?? 0) * 0.20;

        // Bonus por valor precesional positivo
        if (($analysis->precession_value_uf ?? 0) > 0) {
            $adjustment += 0.05;
        }

        return max(-0.3, min(0.3, $adjustment));
    }

    protected function categorizeRisk(float $score): string
    {
        return match (true) {
            $score >= 0.8 => 'critical',
            $score >= 0.6 => 'high',
            $score >= 0.4 => 'medium',
            $score >= 0.2 => 'low',
            default => 'minimal',
        };
    }

    protected function categorizeOpportunity(float $score): string
    {
        return match (true) {
            $score >= 0.8 => 'exceptional',
            $score >= 0.6 => 'high',
            $score >= 0.4 => 'moderate',
            $score >= 0.2 => 'limited',
            default => 'minimal',
        };
    }

    protected function generateInvestmentRecommendations(?PrecessionAnalysis $analysis, array $data): array
    {
        $recommendations = [];

        if (!$analysis) {
            $recommendations[] = [
                'type' => 'info',
                'message' => 'Ejecute un análisis precesional completo para recomendaciones detalladas',
            ];
            return $recommendations;
        }

        if ($analysis->risk_score >= 0.6) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'Alto riesgo precesional detectado. Revisar efectos sistémicos antes de invertir.',
            ];
        }

        if ($analysis->opportunity_score >= 0.7) {
            $recommendations[] = [
                'type' => 'success',
                'message' => 'Oportunidades precesionales significativas identificadas en la zona.',
            ];
        }

        if (($analysis->counter_value_uf ?? 0) < -100000) {
            $recommendations[] = [
                'type' => 'danger',
                'message' => 'Contra-precesión negativa significativa. Evaluar impactos a largo plazo.',
            ];
        }

        return $recommendations;
    }

    // =========================================================
    // ALERTAS PRECESIONALES
    // =========================================================

    /**
     * Genera alertas desde un análisis completado
     */
    protected function generateAlertsFromAnalysis(PrecessionAnalysis $analysis, array $results): void
    {
        $alerts = [];

        // Alerta por riesgo alto
        if (($results['risk_score'] ?? 0) >= 0.7) {
            $alerts[] = [
                'alert_type' => PrecessionAlert::TYPE_RISK,
                'severity' => $results['risk_score'] >= 0.85 
                    ? PrecessionAlert::SEVERITY_CRITICAL 
                    : PrecessionAlert::SEVERITY_HIGH,
                'title' => 'Riesgo precesional elevado detectado',
                'description' => 'El análisis ha detectado un nivel de riesgo precesional superior al umbral recomendado.',
                'recommendation' => 'Revise los efectos sistémicos y contra-precesionales antes de tomar decisiones de inversión.',
                'metrics' => ['risk_score' => $results['risk_score']],
            ];
        }

        // Alerta por oportunidad
        if (($results['opportunity_score'] ?? 0) >= 0.75) {
            $alerts[] = [
                'alert_type' => PrecessionAlert::TYPE_OPPORTUNITY,
                'severity' => PrecessionAlert::SEVERITY_MEDIUM,
                'title' => 'Oportunidad precesional identificada',
                'description' => 'Se han detectado efectos precesionales positivos significativos en la zona.',
                'recommendation' => 'Considere aprovechar las oportunidades antes de que se materialicen cambios en el mercado.',
                'metrics' => ['opportunity_score' => $results['opportunity_score']],
            ];
        }

        // Alerta por cambio de tendencia
        if (isset($results['trend_change']) && $results['trend_change']['detected']) {
            $alerts[] = [
                'alert_type' => PrecessionAlert::TYPE_TREND,
                'severity' => PrecessionAlert::SEVERITY_MEDIUM,
                'title' => 'Cambio de tendencia precesional detectado',
                'description' => $results['trend_change']['description'] ?? 'Se ha detectado un cambio significativo en los patrones precesionales.',
                'metrics' => $results['trend_change'],
            ];
        }

        // Crear alertas en BD
        foreach ($alerts as $alertData) {
            $alert = PrecessionAlert::create([
                'tenant_id' => $analysis->tenant_id,
                'analysis_id' => $analysis->id,
                'copropiedad_id' => $analysis->copropiedad_id,
                'precession_angle' => $alertData['precession_angle'] ?? null,
                'status' => PrecessionAlert::STATUS_ACTIVE,
                'expires_at' => now()->addDays(30),
                ...$alertData,
            ]);

            // Disparar evento
            event(new PrecessionAlertTriggered($alert));
        }
    }

    /**
     * Obtiene alertas activas para el tenant
     */
    public function getActiveAlerts(array $filters = []): array
    {
        $query = PrecessionAlert::forTenant()->active();

        if (isset($filters['copropiedad_id'])) {
            $query->where('copropiedad_id', $filters['copropiedad_id']);
        }

        if (isset($filters['severity'])) {
            $query->where('severity', $filters['severity']);
        }

        if (isset($filters['alert_type'])) {
            $query->where('alert_type', $filters['alert_type']);
        }

        return $query->with('copropiedad')
            ->orderByRaw("CASE severity 
                WHEN 'critical' THEN 1 
                WHEN 'high' THEN 2 
                WHEN 'medium' THEN 3 
                ELSE 4 END")
            ->orderByDesc('created_at')
            ->limit($filters['limit'] ?? 50)
            ->get()
            ->toArray();
    }

    // =========================================================
    // COMPARACIÓN ENTRE COPROPIEDADES
    // =========================================================

    /**
     * Compara análisis precesionales entre copropiedades
     */
    public function comparePrecession(array $copropiedadIds): array
    {
        if (count($copropiedadIds) < 2) {
            throw new \InvalidArgumentException('Se requieren al menos 2 copropiedades para comparar');
        }

        $analyses = [];
        foreach ($copropiedadIds as $id) {
            $analysis = PrecessionAnalysis::forTenant()
                ->where('copropiedad_id', $id)
                ->valid()
                ->latest()
                ->first();

            if (!$analysis) {
                // Ejecutar análisis si no existe
                $this->analyzeCopropiedad($id);
                $analysis = PrecessionAnalysis::forTenant()
                    ->where('copropiedad_id', $id)
                    ->completed()
                    ->latest()
                    ->first();
            }

            if ($analysis) {
                $analyses[$id] = $analysis;
            }
        }

        // Calcular métricas comparativas
        $comparison = [
            'entities' => [],
            'rankings' => [],
            'aggregates' => [
                'avg_precession_score' => 0,
                'avg_risk_score' => 0,
                'avg_opportunity_score' => 0,
            ],
        ];

        $totalPrecession = 0;
        $totalRisk = 0;
        $totalOpportunity = 0;
        $count = count($analyses);

        foreach ($analyses as $id => $analysis) {
            $comparison['entities'][$id] = [
                'copropiedad_id' => $id,
                'precession_score' => $analysis->precession_score,
                'risk_score' => $analysis->risk_score,
                'opportunity_score' => $analysis->opportunity_score,
                'total_value_uf' => $analysis->total_precession_value_uf,
                'confidence' => $analysis->confidence,
            ];

            $totalPrecession += $analysis->precession_score ?? 0;
            $totalRisk += $analysis->risk_score ?? 0;
            $totalOpportunity += $analysis->opportunity_score ?? 0;
        }

        if ($count > 0) {
            $comparison['aggregates'] = [
                'avg_precession_score' => round($totalPrecession / $count, 4),
                'avg_risk_score' => round($totalRisk / $count, 4),
                'avg_opportunity_score' => round($totalOpportunity / $count, 4),
            ];
        }

        // Rankings
        $entities = collect($comparison['entities']);
        $comparison['rankings'] = [
            'best_precession' => $entities->sortByDesc('precession_score')->keys()->first(),
            'lowest_risk' => $entities->sortBy('risk_score')->keys()->first(),
            'best_opportunity' => $entities->sortByDesc('opportunity_score')->keys()->first(),
            'highest_value' => $entities->sortByDesc('total_value_uf')->keys()->first(),
        ];

        // Persistir comparación
        PrecessionComparison::create([
            'tenant_id' => tenant()->id,
            'entity_ids' => $copropiedadIds,
            'entity_type' => 'copropiedad',
            'comparison_results' => $comparison,
            'best_performer_id' => $comparison['rankings']['best_precession'],
            'highest_risk_id' => $entities->sortByDesc('risk_score')->keys()->first(),
            'best_opportunity_id' => $comparison['rankings']['best_opportunity'],
            'avg_precession_score' => $comparison['aggregates']['avg_precession_score'],
            'avg_risk_score' => $comparison['aggregates']['avg_risk_score'],
            'avg_opportunity_score' => $comparison['aggregates']['avg_opportunity_score'],
            'created_by' => auth()->id(),
        ]);

        return $comparison;
    }

    // =========================================================
    // DASHBOARD Y REPORTES
    // =========================================================

    /**
     * Obtiene datos del dashboard precesional
     */
    public function getDashboard(int $copropiedadId): array
    {
        $analysis = PrecessionAnalysis::forTenant()
            ->where('copropiedad_id', $copropiedadId)
            ->valid()
            ->latest()
            ->first();

        if (!$analysis) {
            return [
                'has_analysis' => false,
                'message' => 'No existe análisis precesional válido. Ejecute uno nuevo.',
            ];
        }

        $copropiedad = Copropiedad::find($copropiedadId);

        return [
            'has_analysis' => true,
            'analysis_id' => $analysis->id,
            'copropiedad' => [
                'id' => $copropiedad->id,
                'nombre' => $copropiedad->nombre,
                'direccion' => $copropiedad->direccion,
                'comuna' => $copropiedad->comuna,
            ],
            'scores' => [
                'precession' => $analysis->precession_score,
                'risk' => $analysis->risk_score,
                'opportunity' => $analysis->opportunity_score,
                'confidence' => $analysis->confidence,
            ],
            'values_uf' => [
                'total' => $analysis->total_precession_value_uf,
                'direct' => $analysis->direct_value_uf,
                'induced' => $analysis->induced_value_uf,
                'precession' => $analysis->precession_value_uf,
                'systemic' => $analysis->systemic_value_uf,
                'counter' => $analysis->counter_value_uf,
            ],
            'effects_summary' => $analysis->getEffectsSummary(),
            'ml_predictions' => $analysis->ml_predictions,
            'heatmap_data' => $analysis->heatmap_data,
            'alerts' => PrecessionAlert::forTenant()
                ->where('copropiedad_id', $copropiedadId)
                ->active()
                ->orderByDesc('severity')
                ->limit(5)
                ->get()
                ->toArray(),
            'analysis_date' => $analysis->completed_at?->toIso8601String(),
            'expires_at' => $analysis->expires_at?->toIso8601String(),
        ];
    }

    /**
     * Genera heatmap precesional para visualización
     */
    public function getHeatmap(array $bounds, array $filters = []): array
    {
        $analyses = PrecessionAnalysis::forTenant()
            ->completed()
            ->valid()
            ->withDistanceTo(
                ($bounds['minLat'] + $bounds['maxLat']) / 2,
                ($bounds['minLng'] + $bounds['maxLng']) / 2
            )
            ->withinBounds(
                $bounds['minLat'],
                $bounds['minLng'],
                $bounds['maxLat'],
                $bounds['maxLng']
            )
            ->limit(500)
            ->get();

        $heatmapPoints = [];

        foreach ($analyses as $analysis) {
            if ($analysis->heatmap_data) {
                foreach ($analysis->heatmap_data as $point) {
                    $heatmapPoints[] = $point;
                }
            } else {
                // Generar punto simple si no hay heatmap detallado
                $heatmapPoints[] = [
                    'lat' => $analysis->latitud,
                    'lng' => $analysis->longitud,
                    'intensity' => $analysis->precession_score ?? 0.5,
                    'type' => $analysis->analysis_type,
                ];
            }
        }

        return [
            'points' => $heatmapPoints,
            'total_analyses' => $analyses->count(),
            'bounds' => $bounds,
        ];
    }

    // =========================================================
    // CACHE
    // =========================================================

    protected function getCachedAnalysis(int $entityId, string $type): ?array
    {
        $cacheKey = "pae:analysis:{$type}:{$entityId}:" . tenant()->id;
        return Cache::get($cacheKey);
    }

    protected function cacheAnalysis(int $entityId, string $type, array $data): void
    {
        $cacheKey = "pae:analysis:{$type}:{$entityId}:" . tenant()->id;
        Cache::put($cacheKey, $data, $this->analysisCacheTtl);
    }

    public function invalidateCache(int $entityId, string $type): void
    {
        $cacheKey = "pae:analysis:{$type}:{$entityId}:" . tenant()->id;
        Cache::forget($cacheKey);
    }

    // =========================================================
    // FALLBACK LOCAL
    // =========================================================

    /**
     * Ejecuta análisis local cuando PAE Core no está disponible
     */
    protected function executeLocalAnalysis(PrecessionAnalysis $analysis, array $context): array
    {
        Log::info('PrecessionService: Ejecutando análisis local fallback', [
            'analysis_id' => $analysis->id,
        ]);

        // Análisis simplificado basado en datos locales
        $riskScore = 0.5;
        $opportunityScore = 0.5;

        // Ajustar por morosidad
        $morosidad = $context['financial']['morosidad_rate'] ?? 0;
        if ($morosidad > 20) {
            $riskScore += 0.2;
        } elseif ($morosidad < 5) {
            $opportunityScore += 0.1;
        }

        // Ajustar por compliance
        $complianceScore = $context['compliance']['score_ds7'] ?? 0;
        if ($complianceScore >= 80) {
            $opportunityScore += 0.15;
        } elseif ($complianceScore < 50) {
            $riskScore += 0.15;
        }

        $analysis->markAsCompleted([
            'precession_score' => (1 - $riskScore + $opportunityScore) / 2,
            'risk_score' => min(1, $riskScore),
            'opportunity_score' => min(1, $opportunityScore),
            'confidence' => 0.5, // Baja confianza en análisis local
            'ml_predictions' => null,
        ]);

        return $analysis->fresh()->toArray();
    }
}
