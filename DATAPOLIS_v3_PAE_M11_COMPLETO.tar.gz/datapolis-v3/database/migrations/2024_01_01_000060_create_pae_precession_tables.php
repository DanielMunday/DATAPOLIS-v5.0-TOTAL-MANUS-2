<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/**
 * Migración para el Módulo PAE M11 - Precession Analytics Engine
 * 
 * Implementa el modelo de datos para análisis precesionales basado en
 * la teoría de precesión sistémica de R. Buckminster Fuller.
 * 
 * Tablas:
 * - precession_analyses: Análisis precesionales principales
 * - precession_graph_nodes: Nodos de la ontología territorial
 * - precession_graph_edges: Relaciones precesionales entre nodos
 * - precession_alerts: Alertas predictivas precesionales
 * - precession_effects: Efectos detallados por ángulo
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 9
 */
return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // =========================================================
        // TABLA: precession_graph_nodes
        // Ontología territorial - Nodos del grafo precesional
        // =========================================================
        Schema::create('precession_graph_nodes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            
            // Identificación del nodo
            $table->string('code', 50)->unique()->comment('Código único del nodo');
            $table->string('name', 100)->comment('Nombre descriptivo');
            $table->text('description')->nullable();
            
            // Clasificación
            $table->enum('domain', [
                'economic',      // Económico: valores, transacciones, morosidad
                'social',        // Social: densidad, equipamiento, servicios
                'normative',     // Normativo: compliance, permisos, zonificación
                'environmental', // Ambiental: riesgos, áreas verdes, contaminación
                'infrastructure' // Infraestructura: transporte, servicios básicos
            ])->index();
            
            $table->enum('node_type', [
                'variable',      // Variable medible (ej: valor_suelo_m2)
                'indicator',     // Indicador calculado (ej: score_precession)
                'event',         // Evento discreto (ej: permiso_edificacion)
                'state'          // Estado del sistema (ej: mercado_saturado)
            ])->default('variable');
            
            // Metadatos de la variable
            $table->string('unit', 50)->nullable()->comment('Unidad de medida');
            $table->string('data_source', 50)->nullable()->comment('Fuente: SII, INE, MINVU, DOM, CBR, DATAPOLIS');
            $table->string('update_frequency', 20)->nullable()->comment('Frecuencia: diario, semanal, mensual, anual');
            
            // Valor actual y estadísticas
            $table->decimal('current_value', 20, 6)->nullable();
            $table->decimal('min_value', 20, 6)->nullable();
            $table->decimal('max_value', 20, 6)->nullable();
            $table->decimal('avg_value', 20, 6)->nullable();
            $table->decimal('std_deviation', 20, 6)->nullable();
            
            // Metadatos ML
            $table->json('feature_importance')->nullable()->comment('Importancia en modelos ML');
            $table->json('correlations')->nullable()->comment('Correlaciones con otros nodos');
            
            // Control
            $table->boolean('is_active')->default(true);
            $table->boolean('is_system')->default(false)->comment('Nodo del sistema base');
            $table->timestamps();
            
            $table->index(['tenant_id', 'domain']);
            $table->index(['tenant_id', 'is_active']);
        });

        // =========================================================
        // TABLA: precession_graph_edges
        // Relaciones precesionales entre nodos
        // =========================================================
        Schema::create('precession_graph_edges', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            
            // Relación source -> target
            $table->uuid('source_node_id');
            $table->uuid('target_node_id');
            
            $table->foreign('source_node_id')
                ->references('id')
                ->on('precession_graph_nodes')
                ->cascadeOnDelete();
            
            $table->foreign('target_node_id')
                ->references('id')
                ->on('precession_graph_nodes')
                ->cascadeOnDelete();
            
            // Ángulo precesional (teoría de Fuller)
            $table->enum('precession_angle', [
                'direct_0',       // 0° - Efecto directo causa-efecto
                'induced_45',     // 45° - Efecto inducido
                'precession_90',  // 90° - Efecto precesional clásico (perpendicular)
                'systemic_135',   // 135° - Efecto sistémico
                'counter_180'     // 180° - Contra-precesión (efecto inverso)
            ])->index();
            
            // Peso y temporalidad
            $table->decimal('weight', 5, 4)->comment('-1.0 a 1.0 intensidad de la relación');
            $table->unsignedSmallInteger('temporal_lag_months')->comment('Meses hasta manifestación del efecto');
            $table->decimal('confidence', 5, 4)->comment('0.0 a 1.0 nivel de confianza estadística');
            
            // Evidencia empírica
            $table->string('evidence_source', 100)->nullable()->comment('Fuente: SII-Transacciones-2020-2025');
            $table->text('evidence_description')->nullable();
            $table->json('evidence_data')->nullable()->comment('Datos de respaldo');
            
            // Metadatos ML
            $table->decimal('ml_predicted_weight', 5, 4)->nullable()->comment('Peso predicho por ML');
            $table->decimal('ml_confidence', 5, 4)->nullable();
            $table->timestamp('ml_last_trained_at')->nullable();
            
            // Control
            $table->boolean('is_active')->default(true);
            $table->boolean('is_system')->default(false);
            $table->timestamps();
            
            $table->unique(['source_node_id', 'target_node_id', 'precession_angle']);
            $table->index(['tenant_id', 'precession_angle']);
        });

        // =========================================================
        // TABLA: precession_analyses
        // Análisis precesionales ejecutados
        // =========================================================
        Schema::create('precession_analyses', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            
            // Entidad analizada (polimórfica)
            $table->nullableMorphs('analyzable'); // copropiedad, predio, comuna, proyecto
            
            // Referencia específica a copropiedad (para backwards compatibility)
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            
            // Ubicación geoespacial (PostGIS)
            $table->decimal('latitud', 10, 8)->nullable();
            $table->decimal('longitud', 11, 8)->nullable();
            // Geometry column se agrega después con raw SQL
            
            // Parámetros del análisis
            $table->enum('analysis_type', [
                'copropiedad_precession',   // Análisis de copropiedad
                'territorial_intervention', // Intervención territorial
                'market_impact',            // Impacto de mercado
                'regulatory_change',        // Cambio normativo
                'infrastructure_project',   // Proyecto de infraestructura
                'investment_assessment'     // Evaluación de inversión
            ])->index();
            
            $table->unsignedInteger('radius_meters')->default(1000);
            $table->unsignedSmallInteger('time_horizon_months')->default(36);
            $table->unsignedTinyInteger('max_depth')->default(4);
            
            // Contexto del análisis
            $table->json('context_financial')->nullable()->comment('Datos financieros: morosidad, gastos, valor');
            $table->json('context_compliance')->nullable()->comment('Datos compliance: score, ley21442');
            $table->json('context_building')->nullable()->comment('Datos edificio: unidades, antigüedad, tipo');
            $table->json('context_territorial')->nullable()->comment('Datos territoriales: zonificación, usos');
            
            // Scores precesionales
            $table->decimal('precession_score', 8, 4)->nullable()->comment('Score precesional total');
            $table->decimal('risk_score', 5, 4)->nullable()->comment('0.0 a 1.0');
            $table->decimal('opportunity_score', 5, 4)->nullable()->comment('0.0 a 1.0');
            $table->decimal('confidence', 5, 4)->nullable()->comment('0.0 a 1.0');
            
            // Valor económico precesional
            $table->decimal('total_precession_value_uf', 15, 2)->nullable();
            $table->decimal('direct_value_uf', 15, 2)->nullable()->comment('Valor efectos 0°');
            $table->decimal('induced_value_uf', 15, 2)->nullable()->comment('Valor efectos 45°');
            $table->decimal('precession_value_uf', 15, 2)->nullable()->comment('Valor efectos 90°');
            $table->decimal('systemic_value_uf', 15, 2)->nullable()->comment('Valor efectos 135°');
            $table->decimal('counter_value_uf', 15, 2)->nullable()->comment('Valor efectos 180°');
            
            // Predicciones ML
            $table->json('ml_predictions')->nullable()->comment('Predicciones por horizonte temporal');
            $table->decimal('ml_confidence', 5, 4)->nullable();
            $table->string('ml_model_version', 20)->nullable();
            
            // Resultados completos
            $table->json('direct_effects')->nullable()->comment('Efectos 0°');
            $table->json('induced_effects')->nullable()->comment('Efectos 45°');
            $table->json('precession_effects')->nullable()->comment('Efectos 90°');
            $table->json('systemic_effects')->nullable()->comment('Efectos 135°');
            $table->json('counter_effects')->nullable()->comment('Efectos 180°');
            
            // Zonas de influencia (GeoJSON)
            $table->json('influence_zones')->nullable()->comment('Polígonos por ángulo');
            $table->unsignedInteger('affected_parcels_count')->nullable();
            
            // Heatmap data
            $table->json('heatmap_data')->nullable();
            
            // Estado del análisis
            $table->enum('status', [
                'pending',      // Pendiente de ejecución
                'processing',   // En proceso
                'completed',    // Completado
                'failed',       // Fallido
                'expired'       // Expirado (cache invalidado)
            ])->default('pending')->index();
            
            $table->text('error_message')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            
            // Auditoría
            $table->foreignId('requested_by')->nullable()->constrained('users')->nullOnDelete();
            $table->ipAddress('request_ip')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            // Índices
            $table->index(['tenant_id', 'status']);
            $table->index(['tenant_id', 'analysis_type']);
            $table->index(['copropiedad_id', 'status']);
            $table->index(['created_at']);
        });

        // Agregar columna geometry PostGIS
        DB::statement("
            ALTER TABLE precession_analyses 
            ADD COLUMN IF NOT EXISTS location geometry(Point, 4326)
        ");
        
        DB::statement("
            CREATE INDEX IF NOT EXISTS precession_analyses_location_idx 
            ON precession_analyses USING GIST (location)
        ");

        // =========================================================
        // TABLA: precession_effects
        // Efectos individuales detectados en cada análisis
        // =========================================================
        Schema::create('precession_effects', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('analysis_id');
            
            $table->foreign('analysis_id')
                ->references('id')
                ->on('precession_analyses')
                ->cascadeOnDelete();
            
            // Nodos afectados
            $table->uuid('source_node_id');
            $table->uuid('target_node_id');
            
            $table->foreign('source_node_id')
                ->references('id')
                ->on('precession_graph_nodes')
                ->cascadeOnDelete();
            
            $table->foreign('target_node_id')
                ->references('id')
                ->on('precession_graph_nodes')
                ->cascadeOnDelete();
            
            // Clasificación del efecto
            $table->enum('angle', [
                'direct_0',
                'induced_45',
                'precession_90',
                'systemic_135',
                'counter_180'
            ]);
            
            $table->unsignedTinyInteger('depth')->comment('Profundidad en el grafo BFS');
            
            // Valores calculados
            $table->decimal('intensity', 5, 4)->comment('-1.0 a 1.0');
            $table->decimal('value_uf', 15, 2)->nullable();
            $table->decimal('probability', 5, 4)->comment('Probabilidad de ocurrencia');
            $table->unsignedSmallInteger('manifestation_months')->comment('Meses hasta manifestación');
            
            // Descripción
            $table->text('description')->nullable();
            $table->json('supporting_data')->nullable();
            
            $table->timestamps();
            
            $table->index(['analysis_id', 'angle']);
        });

        // =========================================================
        // TABLA: precession_alerts
        // Alertas predictivas precesionales
        // =========================================================
        Schema::create('precession_alerts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            
            // Referencia al análisis origen
            $table->uuid('analysis_id')->nullable();
            $table->foreign('analysis_id')
                ->references('id')
                ->on('precession_analyses')
                ->nullOnDelete();
            
            // Entidad afectada
            $table->nullableMorphs('alertable');
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            
            // Clasificación de la alerta
            $table->enum('alert_type', [
                'risk_threshold',       // Umbral de riesgo superado
                'opportunity_detected', // Oportunidad detectada
                'trend_change',         // Cambio de tendencia
                'anomaly_detected',     // Anomalía estadística
                'deadline_approaching', // Plazo cercano
                'regulatory_impact',    // Impacto normativo
                'market_shift'          // Cambio de mercado
            ])->index();
            
            $table->enum('severity', [
                'low',
                'medium',
                'high',
                'critical'
            ])->default('medium')->index();
            
            $table->enum('precession_angle', [
                'direct_0',
                'induced_45',
                'precession_90',
                'systemic_135',
                'counter_180'
            ])->nullable();
            
            // Contenido de la alerta
            $table->string('title', 200);
            $table->text('description');
            $table->text('recommendation')->nullable();
            $table->json('affected_entities')->nullable();
            $table->json('metrics')->nullable()->comment('Métricas asociadas');
            
            // Predicción
            $table->decimal('probability', 5, 4)->nullable();
            $table->decimal('potential_impact_uf', 15, 2)->nullable();
            $table->unsignedSmallInteger('expected_months')->nullable()->comment('Meses hasta materialización');
            
            // Estado
            $table->enum('status', [
                'active',       // Alerta activa
                'acknowledged', // Reconocida por usuario
                'resolved',     // Resuelta
                'dismissed',    // Descartada
                'expired'       // Expirada por tiempo
            ])->default('active')->index();
            
            $table->foreignId('acknowledged_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('acknowledged_at')->nullable();
            $table->text('resolution_notes')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            
            // Notificaciones
            $table->boolean('notification_sent')->default(false);
            $table->timestamp('notification_sent_at')->nullable();
            $table->json('notification_channels')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'status']);
            $table->index(['tenant_id', 'alert_type']);
            $table->index(['copropiedad_id', 'status']);
        });

        // =========================================================
        // TABLA: precession_comparisons
        // Comparaciones entre copropiedades/entidades
        // =========================================================
        Schema::create('precession_comparisons', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            
            $table->string('comparison_name', 100)->nullable();
            $table->text('description')->nullable();
            
            // Entidades comparadas (JSON array de IDs)
            $table->json('entity_ids')->comment('Array de IDs de copropiedades/predios');
            $table->string('entity_type', 50)->default('copropiedad');
            
            // Resultados de la comparación
            $table->json('comparison_results')->nullable();
            $table->uuid('best_performer_id')->nullable();
            $table->uuid('highest_risk_id')->nullable();
            $table->uuid('best_opportunity_id')->nullable();
            
            // Métricas agregadas
            $table->decimal('avg_precession_score', 8, 4)->nullable();
            $table->decimal('avg_risk_score', 5, 4)->nullable();
            $table->decimal('avg_opportunity_score', 5, 4)->nullable();
            
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            
            $table->index(['tenant_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('precession_comparisons');
        Schema::dropIfExists('precession_alerts');
        Schema::dropIfExists('precession_effects');
        Schema::dropIfExists('precession_analyses');
        Schema::dropIfExists('precession_graph_edges');
        Schema::dropIfExists('precession_graph_nodes');
    }
};
