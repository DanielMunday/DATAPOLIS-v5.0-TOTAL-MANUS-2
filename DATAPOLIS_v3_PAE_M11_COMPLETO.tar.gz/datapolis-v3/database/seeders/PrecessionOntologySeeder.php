<?php

namespace Database\Seeders;

use App\Models\PAE\PrecessionGraphNode;
use App\Models\PAE\PrecessionGraphEdge;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

/**
 * PrecessionOntologySeeder
 * 
 * Carga la ontología base del sistema PAE M11 con nodos y relaciones
 * precesionales fundamentales para el análisis territorial chileno.
 * 
 * Basado en la teoría de precesión sistémica de R. Buckminster Fuller.
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 3.2.1
 */
class PrecessionOntologySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->seedNodes();
        $this->seedEdges();
    }

    /**
     * Crear nodos base de la ontología territorial
     */
    protected function seedNodes(): void
    {
        $nodes = [
            // ========== DOMINIO ECONÓMICO ==========
            [
                'code' => 'permisos_edificacion',
                'name' => 'Permisos de Edificación',
                'description' => 'Cantidad de permisos de edificación otorgados por DOM municipal',
                'domain' => 'economic',
                'node_type' => 'event',
                'unit' => 'unidades/mes',
                'data_source' => 'DOM',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'valor_suelo_m2',
                'name' => 'Valor Suelo UF/m²',
                'description' => 'Valor promedio del suelo por metro cuadrado en UF',
                'domain' => 'economic',
                'node_type' => 'variable',
                'unit' => 'UF/m²',
                'data_source' => 'SII',
                'update_frequency' => 'semestral',
            ],
            [
                'code' => 'transacciones_inmobiliarias',
                'name' => 'Transacciones Inmobiliarias',
                'description' => 'Número de compraventas registradas en CBR',
                'domain' => 'economic',
                'node_type' => 'variable',
                'unit' => 'unidades/mes',
                'data_source' => 'CBR',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'indice_morosidad',
                'name' => 'Índice Morosidad Condominios',
                'description' => 'Porcentaje de unidades con gastos comunes impagos',
                'domain' => 'economic',
                'node_type' => 'indicator',
                'unit' => 'porcentaje',
                'data_source' => 'DATAPOLIS',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'arriendo_promedio',
                'name' => 'Arriendo Promedio',
                'description' => 'Valor promedio de arriendo en la zona',
                'domain' => 'economic',
                'node_type' => 'variable',
                'unit' => 'UF/mes',
                'data_source' => 'DATAPOLIS',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'cap_rate_zona',
                'name' => 'Cap Rate Zonal',
                'description' => 'Tasa de capitalización promedio de la zona',
                'domain' => 'economic',
                'node_type' => 'indicator',
                'unit' => 'porcentaje',
                'data_source' => 'DATAPOLIS',
                'update_frequency' => 'trimestral',
            ],
            [
                'code' => 'inversion_publica',
                'name' => 'Inversión Pública',
                'description' => 'Montos de inversión pública en infraestructura',
                'domain' => 'economic',
                'node_type' => 'variable',
                'unit' => 'UF',
                'data_source' => 'DIPRES',
                'update_frequency' => 'anual',
            ],

            // ========== DOMINIO SOCIAL ==========
            [
                'code' => 'densidad_poblacional',
                'name' => 'Densidad Poblacional',
                'description' => 'Habitantes por hectárea en la zona',
                'domain' => 'social',
                'node_type' => 'variable',
                'unit' => 'hab/ha',
                'data_source' => 'INE',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'cobertura_equipamiento',
                'name' => 'Cobertura de Equipamiento',
                'description' => 'Porcentaje de cobertura de equipamiento urbano',
                'domain' => 'social',
                'node_type' => 'indicator',
                'unit' => 'porcentaje',
                'data_source' => 'MINVU',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'acceso_transporte',
                'name' => 'Acceso a Transporte Público',
                'description' => 'Índice de accesibilidad a transporte público',
                'domain' => 'social',
                'node_type' => 'indicator',
                'unit' => 'score_0_100',
                'data_source' => 'MTT',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'indice_seguridad',
                'name' => 'Índice de Seguridad',
                'description' => 'Índice compuesto de seguridad ciudadana',
                'domain' => 'social',
                'node_type' => 'indicator',
                'unit' => 'score_0_100',
                'data_source' => 'CEAD',
                'update_frequency' => 'trimestral',
            ],
            [
                'code' => 'cobertura_educacion',
                'name' => 'Cobertura Educacional',
                'description' => 'Establecimientos educacionales por cada 1000 habitantes',
                'domain' => 'social',
                'node_type' => 'variable',
                'unit' => 'establecimientos/1000hab',
                'data_source' => 'MINEDUC',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'cobertura_salud',
                'name' => 'Cobertura de Salud',
                'description' => 'Centros de salud por cada 1000 habitantes',
                'domain' => 'social',
                'node_type' => 'variable',
                'unit' => 'centros/1000hab',
                'data_source' => 'MINSAL',
                'update_frequency' => 'anual',
            ],

            // ========== DOMINIO NORMATIVO ==========
            [
                'code' => 'compliance_score',
                'name' => 'Score Compliance Normativo',
                'description' => 'Puntaje de cumplimiento normativo general',
                'domain' => 'normative',
                'node_type' => 'indicator',
                'unit' => 'score_0_100',
                'data_source' => 'DATAPOLIS',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'ley21442_compliance',
                'name' => 'Cumplimiento Ley 21.442',
                'description' => 'Estado de cumplimiento de Ley de Copropiedad',
                'domain' => 'normative',
                'node_type' => 'state',
                'unit' => 'estado',
                'data_source' => 'DATAPOLIS',
                'update_frequency' => 'mensual',
            ],
            [
                'code' => 'cambio_zonificacion',
                'name' => 'Cambio de Zonificación',
                'description' => 'Modificaciones al Plan Regulador Comunal',
                'domain' => 'normative',
                'node_type' => 'event',
                'unit' => 'evento',
                'data_source' => 'DOM',
                'update_frequency' => 'variable',
            ],
            [
                'code' => 'declaraciones_tributarias',
                'name' => 'Declaraciones Tributarias',
                'description' => 'Estado de declaraciones tributarias (DJ 1879, 1907)',
                'domain' => 'normative',
                'node_type' => 'state',
                'unit' => 'estado',
                'data_source' => 'SII',
                'update_frequency' => 'anual',
            ],

            // ========== DOMINIO AMBIENTAL ==========
            [
                'code' => 'riesgo_inundacion',
                'name' => 'Riesgo de Inundación',
                'description' => 'Nivel de riesgo de inundación según GIRES',
                'domain' => 'environmental',
                'node_type' => 'indicator',
                'unit' => 'nivel_riesgo',
                'data_source' => 'ONEMI',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'riesgo_sismico',
                'name' => 'Riesgo Sísmico',
                'description' => 'Nivel de riesgo sísmico de la zona',
                'domain' => 'environmental',
                'node_type' => 'indicator',
                'unit' => 'nivel_riesgo',
                'data_source' => 'CSN',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'areas_verdes',
                'name' => 'Áreas Verdes per Cápita',
                'description' => 'Metros cuadrados de áreas verdes por habitante',
                'domain' => 'environmental',
                'node_type' => 'variable',
                'unit' => 'm²/hab',
                'data_source' => 'MINVU',
                'update_frequency' => 'anual',
            ],
            [
                'code' => 'calidad_aire',
                'name' => 'Calidad del Aire',
                'description' => 'Índice de calidad del aire (ICA)',
                'domain' => 'environmental',
                'node_type' => 'indicator',
                'unit' => 'ICA',
                'data_source' => 'MMA',
                'update_frequency' => 'diario',
            ],

            // ========== DOMINIO INFRAESTRUCTURA ==========
            [
                'code' => 'proyecto_metro',
                'name' => 'Proyecto Metro/Tren',
                'description' => 'Proyectos de extensión de red Metro o tren',
                'domain' => 'infrastructure',
                'node_type' => 'event',
                'unit' => 'proyecto',
                'data_source' => 'MTT',
                'update_frequency' => 'variable',
            ],
            [
                'code' => 'proyecto_vial',
                'name' => 'Proyecto Vialidad',
                'description' => 'Proyectos de mejoramiento vial',
                'domain' => 'infrastructure',
                'node_type' => 'event',
                'unit' => 'proyecto',
                'data_source' => 'MOP',
                'update_frequency' => 'variable',
            ],
            [
                'code' => 'cobertura_servicios',
                'name' => 'Cobertura Servicios Básicos',
                'description' => 'Cobertura de agua, luz y alcantarillado',
                'domain' => 'infrastructure',
                'node_type' => 'indicator',
                'unit' => 'porcentaje',
                'data_source' => 'SISS',
                'update_frequency' => 'anual',
            ],
        ];

        foreach ($nodes as $nodeData) {
            PrecessionGraphNode::updateOrCreate(
                ['code' => $nodeData['code']],
                [
                    'id' => Str::uuid(),
                    'tenant_id' => 1, // Sistema
                    'is_system' => true,
                    'is_active' => true,
                    ...$nodeData,
                ]
            );
        }

        $this->command->info('✓ ' . count($nodes) . ' nodos de ontología creados');
    }

    /**
     * Crear aristas (relaciones precesionales) base
     */
    protected function seedEdges(): void
    {
        // Obtener nodos por código
        $nodes = PrecessionGraphNode::all()->keyBy('code');

        $edges = [
            // ========== EFECTOS DIRECTOS (0°) ==========
            [
                'source' => 'permisos_edificacion',
                'target' => 'transacciones_inmobiliarias',
                'angle' => 'direct_0',
                'weight' => 0.75,
                'lag' => 6,
                'confidence' => 0.88,
                'evidence' => 'SII-CBR-Correlación-2020-2025',
            ],

            // ========== EFECTOS INDUCIDOS (45°) ==========
            [
                'source' => 'permisos_edificacion',
                'target' => 'valor_suelo_m2',
                'angle' => 'induced_45',
                'weight' => 0.72,
                'lag' => 12,
                'confidence' => 0.85,
                'evidence' => 'SII-Transacciones-2020-2025',
            ],
            [
                'source' => 'proyecto_metro',
                'target' => 'valor_suelo_m2',
                'angle' => 'induced_45',
                'weight' => 0.82,
                'lag' => 18,
                'confidence' => 0.90,
                'evidence' => 'Metro-Santiago-Líneas-4-5-6',
            ],
            [
                'source' => 'inversion_publica',
                'target' => 'cobertura_equipamiento',
                'angle' => 'induced_45',
                'weight' => 0.68,
                'lag' => 24,
                'confidence' => 0.78,
                'evidence' => 'DIPRES-MINVU-2018-2024',
            ],

            // ========== EFECTOS PRECESIONALES (90°) ==========
            [
                'source' => 'permisos_edificacion',
                'target' => 'densidad_poblacional',
                'angle' => 'precession_90',
                'weight' => 0.65,
                'lag' => 24,
                'confidence' => 0.78,
                'evidence' => 'INE-Censo-2017-Proyecciones',
            ],
            [
                'source' => 'densidad_poblacional',
                'target' => 'cobertura_equipamiento',
                'angle' => 'precession_90',
                'weight' => 0.58,
                'lag' => 36,
                'confidence' => 0.72,
                'evidence' => 'MINVU-Diagnósticos-Urbanos',
            ],
            [
                'source' => 'proyecto_metro',
                'target' => 'densidad_poblacional',
                'angle' => 'precession_90',
                'weight' => 0.70,
                'lag' => 48,
                'confidence' => 0.82,
                'evidence' => 'Metro-INE-Estudios-Densificación',
            ],
            [
                'source' => 'valor_suelo_m2',
                'target' => 'cap_rate_zona',
                'angle' => 'precession_90',
                'weight' => -0.55,
                'lag' => 12,
                'confidence' => 0.80,
                'evidence' => 'DATAPOLIS-Analytics-2024',
            ],
            [
                'source' => 'cambio_zonificacion',
                'target' => 'permisos_edificacion',
                'angle' => 'precession_90',
                'weight' => 0.78,
                'lag' => 18,
                'confidence' => 0.85,
                'evidence' => 'DOM-Municipalidades-RM',
            ],

            // ========== EFECTOS SISTÉMICOS (135°) ==========
            [
                'source' => 'densidad_poblacional',
                'target' => 'acceso_transporte',
                'angle' => 'systemic_135',
                'weight' => 0.62,
                'lag' => 48,
                'confidence' => 0.70,
                'evidence' => 'MTT-Estudios-Demanda',
            ],
            [
                'source' => 'densidad_poblacional',
                'target' => 'indice_seguridad',
                'angle' => 'systemic_135',
                'weight' => -0.45,
                'lag' => 36,
                'confidence' => 0.65,
                'evidence' => 'CEAD-INE-Correlaciones',
            ],
            [
                'source' => 'cobertura_equipamiento',
                'target' => 'valor_suelo_m2',
                'angle' => 'systemic_135',
                'weight' => 0.52,
                'lag' => 60,
                'confidence' => 0.68,
                'evidence' => 'MINVU-SII-Estudios',
            ],
            [
                'source' => 'areas_verdes',
                'target' => 'valor_suelo_m2',
                'angle' => 'systemic_135',
                'weight' => 0.48,
                'lag' => 48,
                'confidence' => 0.72,
                'evidence' => 'Estudios-Hedónicos-2020',
            ],

            // ========== CONTRA-PRECESIÓN (180°) ==========
            [
                'source' => 'valor_suelo_m2',
                'target' => 'indice_morosidad',
                'angle' => 'counter_180',
                'weight' => -0.45,
                'lag' => 18,
                'confidence' => 0.68,
                'evidence' => 'DATAPOLIS-Analytics-2024-2025',
            ],
            [
                'source' => 'densidad_poblacional',
                'target' => 'areas_verdes',
                'angle' => 'counter_180',
                'weight' => -0.58,
                'lag' => 60,
                'confidence' => 0.75,
                'evidence' => 'MINVU-Diagnósticos-Urbanos',
            ],
            [
                'source' => 'valor_suelo_m2',
                'target' => 'arriendo_promedio',
                'angle' => 'counter_180',
                'weight' => 0.72,
                'lag' => 6,
                'confidence' => 0.88,
                'evidence' => 'DATAPOLIS-Mercado-Arriendos',
            ],
            [
                'source' => 'densidad_poblacional',
                'target' => 'calidad_aire',
                'angle' => 'counter_180',
                'weight' => -0.42,
                'lag' => 24,
                'confidence' => 0.65,
                'evidence' => 'MMA-Estudios-Contaminación',
            ],
        ];

        $created = 0;
        foreach ($edges as $edgeData) {
            $sourceNode = $nodes->get($edgeData['source']);
            $targetNode = $nodes->get($edgeData['target']);

            if (!$sourceNode || !$targetNode) {
                $this->command->warn("Nodo no encontrado: {$edgeData['source']} -> {$edgeData['target']}");
                continue;
            }

            PrecessionGraphEdge::updateOrCreate(
                [
                    'source_node_id' => $sourceNode->id,
                    'target_node_id' => $targetNode->id,
                    'precession_angle' => $edgeData['angle'],
                ],
                [
                    'id' => Str::uuid(),
                    'tenant_id' => 1,
                    'weight' => $edgeData['weight'],
                    'temporal_lag_months' => $edgeData['lag'],
                    'confidence' => $edgeData['confidence'],
                    'evidence_source' => $edgeData['evidence'],
                    'is_system' => true,
                    'is_active' => true,
                ]
            );
            $created++;
        }

        $this->command->info("✓ {$created} relaciones precesionales creadas");
    }
}
