# PAE M11 - Precession Analytics Engine

## Módulo de Análisis Precesional para DATAPOLIS v3.0

### Descripción

El **Precession Analytics Engine (PAE)** es el Módulo M11 del Sistema Multi-Agente DATAPOLIS AI v2.0. Implementa análisis de efectos precesionales (impactos indirectos a +90°) sobre intervenciones urbanas e inmobiliarias, basado en la teoría de **precesión sistémica de R. Buckminster Fuller**.

### Fundamento Teórico

La precesión, concepto derivado de la física rotatoria, describe cómo fuerzas aplicadas a sistemas giratorios producen efectos perpendiculares a la dirección de la fuerza. Fuller aplicó este concepto a sistemas sociales y urbanos, identificando que:

> "Los efectos más significativos de cualquier acción ocurren a 90° de la intención original."

El PAE transpone este modelo a análisis territorial chileno, identificando 5 tipos de efectos:

| Ángulo | Nombre | Descripción | Horizonte |
|--------|--------|-------------|-----------|
| 0° | Directo | Causa-efecto lineal inmediato | 0-6 meses |
| 45° | Inducido | Efectos secundarios correlacionados | 3-18 meses |
| 90° | Precesional | Efectos perpendiculares (Fuller) | 12-36 meses |
| 135° | Sistémico | Efectos de segundo orden | 24-60 meses |
| 180° | Contra-Precesión | Efectos inversos/retroalimentación | 36-120 meses |

### Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│  DATAPOLIS v3.0 (Laravel 11)                                │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  app/Services/PrecessionService.php                  │    │
│  │  app/Http/Controllers/Api/V1/PAE/                   │    │
│  │  app/Models/PAE/                                     │    │
│  │  routes/pae.php                                      │    │
│  └─────────────────────┬───────────────────────────────┘    │
│                        │ HTTP/REST                          │
├────────────────────────┼────────────────────────────────────┤
│  Multi-Agent System v2.0 ─ M11 PAE (CORE ENGINE)            │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────┐  │
│  │  Precession     │  │  ML Prediction  │  │  Spatial    │  │
│  │  Graph Engine   │  │  Engine         │  │  Analysis   │  │
│  └─────────────────┘  └─────────────────┘  └─────────────┘  │
├─────────────────────────────────────────────────────────────┤
│  PostgreSQL 16 + PostGIS 3.4  │  Redis 7  │  Ollama LLM   │
└─────────────────────────────────────────────────────────────┘
```

### Instalación

#### 1. Ejecutar Migraciones

```bash
php artisan migrate
```

Esto creará las tablas:
- `precession_graph_nodes` - Nodos de ontología territorial
- `precession_graph_edges` - Relaciones precesionales
- `precession_analyses` - Análisis ejecutados
- `precession_effects` - Efectos individuales
- `precession_alerts` - Alertas predictivas
- `precession_comparisons` - Comparaciones

#### 2. Cargar Ontología Base

```bash
php artisan db:seed --class=PrecessionOntologySeeder
```

#### 3. Configurar Variables de Entorno

```env
# PAE Core API (Multi-Agent M11)
PAE_API_URL=http://localhost:8000/api/v1/pae
PAE_API_KEY=your-api-key-here
PAE_HTTP_TIMEOUT=30

# Cache TTL
PAE_CACHE_TTL_ANALYSIS=3600    # 1 hora
PAE_CACHE_TTL_SCORING=86400    # 24 horas
PAE_CACHE_TTL_HOURS=24

# Fallback
PAE_FALLBACK_ENABLED=true
```

#### 4. Incluir Rutas

En `routes/api.php`:

```php
require __DIR__ . '/pae.php';
```

### API Endpoints

#### Análisis

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/v1/pae/analyze/copropiedad/{id}` | Ejecutar análisis precesional |
| GET | `/api/v1/pae/analyses` | Listar análisis |
| GET | `/api/v1/pae/analyses/{id}` | Ver detalle de análisis |

#### Dashboard y Visualización

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/pae/dashboard/{copropiedadId}` | Dashboard precesional |
| GET | `/api/v1/pae/heatmap` | Mapa de calor precesional |

#### Scoring y Comparación

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/v1/pae/investment-score` | Score de inversión |
| POST | `/api/v1/pae/compare` | Comparar copropiedades |

#### Alertas

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/pae/alerts` | Listar alertas activas |
| POST | `/api/v1/pae/alerts/{id}/acknowledge` | Reconocer alerta |
| POST | `/api/v1/pae/alerts/{id}/resolve` | Resolver alerta |

#### Reportes

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/pae/report/{copropiedadId}` | Reporte para inversionistas |

### Uso del Servicio

```php
use App\Services\PrecessionService;

$pae = app(PrecessionService::class);

// Análisis de copropiedad
$analysis = $pae->analyzeCopropiedad($copropiedadId, [
    'horizon' => 36,      // meses
    'radius' => 1000,     // metros
    'max_depth' => 4,
    'include_ml' => true,
]);

// Score de inversión
$score = $pae->calculateInvestmentScore([
    'copropiedad_id' => $copropiedadId,
    'cap_rate' => 6.5,
    'ocupacion' => 95,
]);

// Comparación
$comparison = $pae->comparePrecession([
    $copropiedad1Id,
    $copropiedad2Id,
    $copropiedad3Id,
]);

// Dashboard
$dashboard = $pae->getDashboard($copropiedadId);

// Alertas
$alerts = $pae->getActiveAlerts([
    'severity' => 'critical',
    'limit' => 10,
]);
```

### Modelo de Datos

#### PrecessionAnalysis

Campos principales:

```php
[
    'id' => 'uuid',
    'copropiedad_id' => 'int',
    'latitud' => 'decimal',
    'longitud' => 'decimal',
    'analysis_type' => 'enum',  // copropiedad_precession, territorial_intervention...
    'precession_score' => 'decimal',  // 0-100
    'risk_score' => 'decimal',        // 0.0-1.0
    'opportunity_score' => 'decimal', // 0.0-1.0
    'confidence' => 'decimal',        // 0.0-1.0
    'total_precession_value_uf' => 'decimal',
    'direct_value_uf' => 'decimal',   // Efectos 0°
    'induced_value_uf' => 'decimal',  // Efectos 45°
    'precession_value_uf' => 'decimal', // Efectos 90°
    'systemic_value_uf' => 'decimal', // Efectos 135°
    'counter_value_uf' => 'decimal',  // Efectos 180°
    'ml_predictions' => 'json',       // Predicciones por horizonte
    'status' => 'enum',               // pending, processing, completed, failed
]
```

#### Scopes Espaciales (PostGIS)

```php
// Análisis dentro de radio
PrecessionAnalysis::withinRadius($lat, $lng, $radiusMeters)->get();

// Análisis dentro de bounding box
PrecessionAnalysis::withinBounds($minLat, $minLng, $maxLat, $maxLng)->get();

// Ordenar por distancia
PrecessionAnalysis::orderByDistance($lat, $lng)->get();

// Agregar distancia como columna
PrecessionAnalysis::withDistanceTo($lat, $lng)->get();
```

### Eventos

#### PrecessionAnalysisCompleted

Se dispara cuando un análisis se completa exitosamente.

```php
use App\Events\PrecessionAnalysisCompleted;

Event::listen(PrecessionAnalysisCompleted::class, function ($event) {
    $analysis = $event->analysis;
    // Ejecutar acciones post-análisis
});
```

#### PrecessionAlertTriggered

Se dispara cuando se genera una nueva alerta.

```php
use App\Events\PrecessionAlertTriggered;

Event::listen(PrecessionAlertTriggered::class, function ($event) {
    $alert = $event->alert;
    // Enviar notificaciones
});
```

### Frontend (Vue 3)

Componentes disponibles:

- `PAEDashboard.vue` - Dashboard principal
- `PAEAlerts.vue` - Gestión de alertas
- `PAECompare.vue` - Comparación entre copropiedades

### Tests

Ejecutar tests del módulo PAE:

```bash
php artisan test --filter=Precession
```

Tests incluidos:
- `PrecessionControllerTest` - Tests de endpoints API
- `PrecessionServiceTest` - Tests de servicio

### Ontología Territorial

El sistema incluye una ontología base con 25 nodos y 18 relaciones precesionales:

**Dominios:**
- Economic: valor_suelo, transacciones, morosidad, cap_rate
- Social: densidad, equipamiento, transporte, seguridad
- Normative: compliance, zonificación, tributario
- Environmental: riesgos, áreas_verdes, calidad_aire
- Infrastructure: metro, vialidad, servicios

**Fuentes de datos:**
- SII (Servicio de Impuestos Internos)
- INE (Instituto Nacional de Estadísticas)
- MINVU (Ministerio de Vivienda)
- CBR (Conservador de Bienes Raíces)
- DOM (Direcciones de Obras Municipales)
- DATAPOLIS (datos propios)

### Configuración Avanzada

Ver `config/datapolis.php` sección `pae`:

```php
'pae' => [
    'api_url' => env('PAE_API_URL'),
    'api_key' => env('PAE_API_KEY'),
    'http_timeout' => 30,
    'cache_ttl_analysis' => 3600,
    'cache_ttl_scoring' => 86400,
    'fallback_enabled' => true,
    'defaults' => [
        'radius_meters' => 1000,
        'time_horizon_months' => 36,
        'max_depth' => 4,
    ],
    'alert_thresholds' => [
        'risk_critical' => 0.85,
        'risk_high' => 0.7,
        'opportunity_exceptional' => 0.85,
        'opportunity_high' => 0.75,
    ],
    'angles' => [
        'direct_0' => [...],
        'induced_45' => [...],
        'precession_90' => [...],
        'systemic_135' => [...],
        'counter_180' => [...],
    ],
],
```

### Propuesta de Valor

El PAE M11 ofrece capacidades únicas en el mercado PropTech chileno y latinoamericano:

1. **Análisis de efectos indirectos** - Identifica impactos que ocurren a 90° de la acción original
2. **Predicciones ML** - Modelos entrenados con datos territoriales chilenos
3. **Integración espacial** - PostGIS para análisis geoespacial
4. **Ontología territorial** - Grafo de relaciones causa-efecto basado en evidencia
5. **Alertas predictivas** - Detección temprana de riesgos y oportunidades
6. **Scoring de inversión** - Ajustado por factores precesionales

### Licencia

Propiedad de DATAPOLIS SpA. Todos los derechos reservados.

### Contacto

Para soporte técnico o consultas comerciales:
- Email: dev@datapolis.cl
- Documentación: https://docs.datapolis.cl/pae

---

*PAE M11 - Precession Analytics Engine*
*DATAPOLIS SpA © 2025*
