/**
 * =========================================================
 * PAE M11 - Dashboard Precesional
 * =========================================================
 */

'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import paeApi from '@/lib/api/pae';
import { AlertSeverity } from '@/types/pae.types';
import {
  PrecessionScoreCard,
  PrecessionAlertBadge,
  KPICard,
  CardSkeleton,
} from '@/components/pae/PrecessionCards';
import { PrecessionRadarChart } from '@/components/pae/PrecessionRadarChart';
import { MLPredictionsChart, PrecessionHeatmapMini } from '@/components/pae/PrecessionCharts';

export default function PrecessionDashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [topRisks, setTopRisks] = useState<any[]>([]);
  const [topOpportunities, setTopOpportunities] = useState<any[]>([]);
  const [selectedCopropiedad, setSelectedCopropiedad] = useState<any>(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [statsData, alertsData, risksData, oppsData] = await Promise.all([
        paeApi.getSystemStats(7),
        paeApi.getAlerts({ status: AlertSeverity.CRITICAL }),
        paeApi.getTopRisks(5),
        paeApi.getTopOpportunities(5),
      ]);
      setStats(statsData);
      setAlerts(alertsData.slice(0, 5));
      setTopRisks(risksData);
      setTopOpportunities(oppsData);
      
      if (risksData.length > 0) {
        const dashboard = await paeApi.getDashboard(risksData[0].id);
        setSelectedCopropiedad(dashboard);
      }
    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      </div>
    );
  }

  const totalAlerts = Object.values(stats?.activeAlerts || {}).reduce((a: any, b: any) => a + b, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <span className="text-3xl">🔮</span>
                Precession Analytics Engine
              </h1>
              <p className="text-gray-500 text-sm mt-1">
                Análisis precesional basado en R. Buckminster Fuller
              </p>
            </div>
            <div className="flex gap-3">
              <Link
                href="/precession/analyze"
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                + Nuevo Análisis
              </Link>
              <Link
                href="/precession/compare"
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Comparar
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            label="Análisis Completados"
            value={stats?.totals?.analyses_completed || 0}
            subValue="Últimos 7 días"
            trend="up"
            trendValue={`${stats?.successRate?.toFixed(0) || 0}% éxito`}
          />
          <KPICard
            label="Alertas Activas"
            value={totalAlerts}
            subValue={`${stats?.activeAlerts?.[AlertSeverity.CRITICAL] || 0} críticas`}
          />
          <KPICard
            label="Score Promedio"
            value={stats?.averages?.avg_precession_score?.toFixed(1) || 'N/A'}
            subValue="Sistema completo"
          />
          <KPICard
            label="Tiempo Ejecución"
            value={`${((stats?.averages?.avg_execution_time || 0) / 1000).toFixed(1)}s`}
            subValue="Promedio"
          />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Score Cards */}
            {selectedCopropiedad && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <PrecessionScoreCard
                  title="Precession Score"
                  value={selectedCopropiedad.scores?.precession || 0}
                  subtitle="Score general"
                  color="purple"
                />
                <PrecessionScoreCard
                  title="Risk Score"
                  value={(selectedCopropiedad.scores?.risk || 0) * 100}
                  subtitle="Nivel de riesgo"
                  color="red"
                />
                <PrecessionScoreCard
                  title="Opportunity"
                  value={(selectedCopropiedad.scores?.opportunity || 0) * 100}
                  subtitle="Potencial"
                  color="green"
                />
              </div>
            )}

            {/* Radar Chart */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Efectos por Ángulo Precesional
              </h2>
              {selectedCopropiedad?.latestAnalysis ? (
                <PrecessionRadarChart
                  data={{
                    direct_0: 75,
                    induced_45: 60,
                    precession_90: 85,
                    systemic_135: 45,
                    counter_180: 30,
                  }}
                  height={300}
                />
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  Seleccione una copropiedad para ver el análisis
                </div>
              )}
            </div>

            {/* Heatmap Placeholder */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Zona de Influencia
              </h2>
              <PrecessionHeatmapMini
                center={{ lat: -33.4489, lng: -70.6693 }}
                intensity={0.7}
                radius={1000}
                className="h-64"
              />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Alerts */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">Alertas</h2>
                <Link href="/precession/alerts" className="text-sm text-purple-600 hover:underline">
                  Ver todas →
                </Link>
              </div>
              {alerts.length > 0 ? (
                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <div key={alert.id} className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <div className="flex items-start gap-2">
                        <PrecessionAlertBadge severity={alert.severity} />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 text-sm truncate">{alert.title}</p>
                          <p className="text-xs text-gray-500">{alert.expectedMonths}m horizonte</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">Sin alertas activas</p>
              )}
            </div>

            {/* Top Risks */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">🔴 Top Riesgos</h2>
              <div className="space-y-2">
                {topRisks.map((risk, i) => (
                  <div key={risk.id} className="flex items-center gap-3 p-2 hover:bg-red-50 rounded cursor-pointer">
                    <span className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-sm font-bold">
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{risk.nombre}</p>
                      <p className="text-xs text-gray-500">{risk.comuna}</p>
                    </div>
                    <span className="text-red-600 font-semibold">
                      {(risk.pae_risk_score * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Opportunities */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">🟢 Top Oportunidades</h2>
              <div className="space-y-2">
                {topOpportunities.map((opp, i) => (
                  <div key={opp.id} className="flex items-center gap-3 p-2 hover:bg-green-50 rounded cursor-pointer">
                    <span className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-bold">
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{opp.nombre}</p>
                      <p className="text-xs text-gray-500">{opp.comuna}</p>
                    </div>
                    <span className="text-green-600 font-semibold">
                      +{opp.appreciation_60m_pct?.toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
