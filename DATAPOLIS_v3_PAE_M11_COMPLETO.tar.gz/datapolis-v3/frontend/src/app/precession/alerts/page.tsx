/**
 * =========================================================
 * PAE M11 - Página de Alertas Precesionales
 * =========================================================
 * 
 * Página: /precession/alerts
 * Gestión de alertas del sistema PAE
 */

'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  PrecessionAlertCard,
  PrecessionAlertBadge,
  PrecessionSkeleton,
  SEVERITY_CONFIG,
  ANGLE_CONFIG,
} from '@/components/pae/components';
import { paeApi } from '@/services/pae.service';
import {
  PrecessionAlert,
  AlertSeverity,
  AlertStatus,
  AlertType,
  Copropiedad,
  PrecessionAngle,
} from '@/types/pae.types';

// =========================================================
// CONSTANTS
// =========================================================

const ALERT_TYPE_LABELS: Record<AlertType, string> = {
  [AlertType.RISK_THRESHOLD]: 'Umbral de Riesgo',
  [AlertType.OPPORTUNITY_DETECTED]: 'Oportunidad Detectada',
  [AlertType.TREND_CHANGE]: 'Cambio de Tendencia',
  [AlertType.ANOMALY_DETECTED]: 'Anomalía Detectada',
  [AlertType.DEADLINE_APPROACHING]: 'Fecha Límite Próxima',
  [AlertType.REGULATORY_IMPACT]: 'Impacto Regulatorio',
  [AlertType.MARKET_SHIFT]: 'Cambio de Mercado',
};

const STATUS_LABELS: Record<AlertStatus, { label: string; color: string }> = {
  [AlertStatus.ACTIVE]: { label: 'Activa', color: 'bg-red-100 text-red-700' },
  [AlertStatus.ACKNOWLEDGED]: { label: 'Reconocida', color: 'bg-yellow-100 text-yellow-700' },
  [AlertStatus.RESOLVED]: { label: 'Resuelta', color: 'bg-green-100 text-green-700' },
  [AlertStatus.EXPIRED]: { label: 'Expirada', color: 'bg-gray-100 text-gray-700' },
};

// =========================================================
// PAGE COMPONENT
// =========================================================

export default function AlertsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const highlightedId = searchParams.get('id');

  // State
  const [loading, setLoading] = useState(true);
  const [alerts, setAlerts] = useState<PrecessionAlert[]>([]);
  const [copropiedades, setCopropiedades] = useState<Copropiedad[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<PrecessionAlert | null>(null);
  const [showResolveModal, setShowResolveModal] = useState(false);
  const [resolveNotes, setResolveNotes] = useState('');

  // Filters
  const [filters, setFilters] = useState({
    severity: '' as AlertSeverity | '',
    status: '' as AlertStatus | '',
    type: '' as AlertType | '',
    copropiedad_id: '' as string,
    from_date: '',
    to_date: '',
  });

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    bySeverity: {} as Record<AlertSeverity, number>,
    byStatus: {} as Record<AlertStatus, number>,
  });

  // Load data
  useEffect(() => {
    loadData();
  }, []);

  // Apply filters
  useEffect(() => {
    loadAlerts();
  }, [filters]);

  const loadData = async () => {
    try {
      setLoading(true);

      // Load copropiedades for filter
      const copData = await paeApi.getCopropiedades({ activa: true, per_page: 200 });
      setCopropiedades(copData.data);

      // Load alerts
      await loadAlerts();

    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadAlerts = async () => {
    try {
      const filterParams: any = {};
      if (filters.severity) filterParams.severity = filters.severity;
      if (filters.status) filterParams.status = filters.status;
      if (filters.type) filterParams.type = filters.type;
      if (filters.copropiedad_id) filterParams.copropiedad_id = Number(filters.copropiedad_id);
      if (filters.from_date) filterParams.from_date = filters.from_date;
      if (filters.to_date) filterParams.to_date = filters.to_date;

      const data = await paeApi.getAlerts(filterParams);
      setAlerts(data);

      // Calculate stats
      const bySeverity = {} as Record<AlertSeverity, number>;
      const byStatus = {} as Record<AlertStatus, number>;

      data.forEach((alert) => {
        bySeverity[alert.severity] = (bySeverity[alert.severity] || 0) + 1;
        byStatus[alert.status] = (byStatus[alert.status] || 0) + 1;
      });

      setStats({
        total: data.length,
        bySeverity,
        byStatus,
      });

      // Highlight specific alert if in URL
      if (highlightedId) {
        const highlighted = data.find((a) => a.id === highlightedId);
        if (highlighted) {
          setSelectedAlert(highlighted);
        }
      }

    } catch (err) {
      console.error('Error loading alerts:', err);
    }
  };

  const handleAcknowledge = async (alertId: string) => {
    try {
      await paeApi.acknowledgeAlert(alertId);
      await loadAlerts();
    } catch (err) {
      console.error('Error acknowledging alert:', err);
    }
  };

  const handleResolve = async () => {
    if (!selectedAlert) return;

    try {
      await paeApi.resolveAlert(selectedAlert.id, resolveNotes);
      setShowResolveModal(false);
      setResolveNotes('');
      setSelectedAlert(null);
      await loadAlerts();
    } catch (err) {
      console.error('Error resolving alert:', err);
    }
  };

  const handleExportReport = () => {
    // Generate CSV export
    const headers = ['ID', 'Severidad', 'Tipo', 'Copropiedad', 'Título', 'Estado', 'Fecha'];
    const rows = alerts.map((a) => [
      a.id,
      a.severity,
      ALERT_TYPE_LABELS[a.alert_type] || a.alert_type,
      a.copropiedad?.nombre || a.copropiedad_id,
      a.title,
      a.status,
      new Date(a.created_at).toLocaleDateString('es-CL'),
    ]);

    const csv = [headers, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pae_alerts_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearFilters = () => {
    setFilters({
      severity: '',
      status: '',
      type: '',
      copropiedad_id: '',
      from_date: '',
      to_date: '',
    });
  };

  // =========================================================
  // RENDER
  // =========================================================

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <PrecessionSkeleton />
        <PrecessionSkeleton type="list" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/dashboard/precession" className="hover:text-purple-600">
              Dashboard PAE
            </Link>
            <span>/</span>
            <span>Alertas</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <span>🔔</span>
            Alertas Precesionales
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportReport}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
          >
            <span>📥</span>
            Exportar CSV
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
          <div className="text-sm text-gray-500">Total</div>
          <div className="text-2xl font-bold text-gray-800">{stats.total}</div>
        </div>
        {Object.values(AlertSeverity).map((severity) => (
          <div
            key={severity}
            className={`rounded-lg p-4 shadow-sm border ${SEVERITY_CONFIG[severity].bgColor} ${SEVERITY_CONFIG[severity].borderColor}`}
          >
            <div className={`text-sm ${SEVERITY_CONFIG[severity].color}`}>
              {SEVERITY_CONFIG[severity].label}
            </div>
            <div className={`text-2xl font-bold ${SEVERITY_CONFIG[severity].color}`}>
              {stats.bySeverity[severity] || 0}
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            <span>🔍</span>
            Filtros
          </h2>
          <button
            onClick={clearFilters}
            className="text-sm text-purple-600 hover:text-purple-700"
          >
            Limpiar filtros
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
          {/* Severity */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Severidad
            </label>
            <select
              value={filters.severity}
              onChange={(e) => setFilters({ ...filters, severity: e.target.value as AlertSeverity })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Todas</option>
              {Object.values(AlertSeverity).map((s) => (
                <option key={s} value={s}>{SEVERITY_CONFIG[s].label}</option>
              ))}
            </select>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Estado
            </label>
            <select
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value as AlertStatus })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Todos</option>
              {Object.values(AlertStatus).map((s) => (
                <option key={s} value={s}>{STATUS_LABELS[s].label}</option>
              ))}
            </select>
          </div>

          {/* Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tipo
            </label>
            <select
              value={filters.type}
              onChange={(e) => setFilters({ ...filters, type: e.target.value as AlertType })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Todos</option>
              {Object.entries(ALERT_TYPE_LABELS).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>

          {/* Copropiedad */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Copropiedad
            </label>
            <select
              value={filters.copropiedad_id}
              onChange={(e) => setFilters({ ...filters, copropiedad_id: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Todas</option>
              {copropiedades.map((c) => (
                <option key={c.id} value={c.id}>{c.nombre}</option>
              ))}
            </select>
          </div>

          {/* From Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Desde
            </label>
            <input
              type="date"
              value={filters.from_date}
              onChange={(e) => setFilters({ ...filters, from_date: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* To Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Hasta
            </label>
            <input
              type="date"
              value={filters.to_date}
              onChange={(e) => setFilters({ ...filters, to_date: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {alerts.length > 0 ? (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className={`transition-all ${
                highlightedId === alert.id ? 'ring-2 ring-purple-500 ring-offset-2' : ''
              }`}
            >
              <PrecessionAlertCard
                alert={alert}
                onAcknowledge={handleAcknowledge}
                onResolve={(id) => {
                  const a = alerts.find((x) => x.id === id);
                  if (a) {
                    setSelectedAlert(a);
                    setShowResolveModal(true);
                  }
                }}
                onViewDetails={(id) => {
                  const a = alerts.find((x) => x.id === id);
                  if (a) setSelectedAlert(a);
                }}
              />
            </div>
          ))
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <div className="text-6xl mb-4">✅</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Sin alertas
            </h3>
            <p className="text-gray-600">
              No hay alertas que coincidan con los filtros seleccionados
            </p>
          </div>
        )}
      </div>

      {/* Alert Detail Modal */}
      {selectedAlert && !showResolveModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className={`p-6 ${SEVERITY_CONFIG[selectedAlert.severity].bgColor}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <PrecessionAlertBadge severity={selectedAlert.severity} showLabel size="lg" />
                  <span
                    className="px-2 py-1 rounded text-white text-sm"
                    style={{ backgroundColor: ANGLE_CONFIG[selectedAlert.precession_angle]?.color }}
                  >
                    {ANGLE_CONFIG[selectedAlert.precession_angle]?.label}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedAlert(null)}
                  className="text-gray-500 hover:text-gray-700 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-2">
                {selectedAlert.title}
              </h2>

              <p className="text-gray-600 mb-4">
                {selectedAlert.description}
              </p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Copropiedad</div>
                  <div className="font-medium">
                    {selectedAlert.copropiedad?.nombre || `ID: ${selectedAlert.copropiedad_id}`}
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Tipo</div>
                  <div className="font-medium">
                    {ALERT_TYPE_LABELS[selectedAlert.alert_type] || selectedAlert.alert_type}
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Impacto Potencial</div>
                  <div className="font-medium text-red-600">
                    {selectedAlert.potential_impact_uf.toLocaleString()} UF
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Probabilidad</div>
                  <div className="font-medium">
                    {(selectedAlert.probability * 100).toFixed(0)}%
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Horizonte</div>
                  <div className="font-medium">
                    {selectedAlert.expected_months} meses
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-500">Estado</div>
                  <div className={`font-medium inline-block px-2 py-0.5 rounded ${STATUS_LABELS[selectedAlert.status].color}`}>
                    {STATUS_LABELS[selectedAlert.status].label}
                  </div>
                </div>
              </div>

              {selectedAlert.recommendation && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
                  <h4 className="font-semibold text-purple-800 mb-2">💡 Recomendación</h4>
                  <p className="text-purple-700">{selectedAlert.recommendation}</p>
                </div>
              )}

              <div className="text-sm text-gray-500 mb-6">
                <p>Creada: {new Date(selectedAlert.created_at).toLocaleString('es-CL')}</p>
                <p>Expira: {new Date(selectedAlert.expires_at).toLocaleString('es-CL')}</p>
                {selectedAlert.acknowledged_at && (
                  <p>Reconocida: {new Date(selectedAlert.acknowledged_at).toLocaleString('es-CL')}</p>
                )}
                {selectedAlert.resolved_at && (
                  <p>Resuelta: {new Date(selectedAlert.resolved_at).toLocaleString('es-CL')}</p>
                )}
              </div>

              <div className="flex gap-3">
                {selectedAlert.status === AlertStatus.ACTIVE && (
                  <button
                    onClick={() => handleAcknowledge(selectedAlert.id)}
                    className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                  >
                    Reconocer
                  </button>
                )}
                {selectedAlert.status === AlertStatus.ACKNOWLEDGED && (
                  <button
                    onClick={() => setShowResolveModal(true)}
                    className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
                  >
                    Resolver
                  </button>
                )}
                <Link
                  href={`/precession/analyze/${selectedAlert.copropiedad_id}`}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Ver Análisis
                </Link>
                <button
                  onClick={() => setSelectedAlert(null)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 ml-auto"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Resolve Modal */}
      {showResolveModal && selectedAlert && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                Resolver Alerta
              </h2>

              <p className="text-gray-600 mb-4">
                ¿Está seguro de resolver esta alerta?
              </p>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notas de Resolución (opcional)
                </label>
                <textarea
                  value={resolveNotes}
                  onChange={(e) => setResolveNotes(e.target.value)}
                  rows={3}
                  placeholder="Describa las acciones tomadas..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleResolve}
                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
                >
                  Confirmar Resolución
                </button>
                <button
                  onClick={() => {
                    setShowResolveModal(false);
                    setResolveNotes('');
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
