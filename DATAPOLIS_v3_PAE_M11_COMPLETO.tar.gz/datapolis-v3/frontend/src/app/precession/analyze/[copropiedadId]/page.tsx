/**
 * =========================================================
 * PAE M11 - Página de Análisis Precesional
 * =========================================================
 * 
 * Página: /precession/analyze/[copropiedadId]
 * Ejecutar y visualizar análisis precesional detallado
 */

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  PrecessionScoreCard,
  PrecessionRadarChart,
  PrecessionValuesChart,
  MLPredictionsChart,
  PrecessionTimeline,
  PrecessionAlertCard,
  PrecessionHeatmapMini,
  PrecessionSkeleton,
  ANGLE_CONFIG,
} from '@/components/pae/components';
import { paeApi } from '@/services/pae.service';
import {
  PrecessionAnalysis,
  PrecessionAlert,
  Copropiedad,
  CopropiedadMetrics,
  AnalyzeFormData,
  PrecessionAngle,
  TimelineItem,
} from '@/types/pae.types';

// =========================================================
// TYPES
// =========================================================

interface AnalysisResult {
  analysis: PrecessionAnalysis;
  alerts: PrecessionAlert[];
}

// =========================================================
// PAGE COMPONENT
// =========================================================

export default function AnalyzeCopropiedadPage() {
  const params = useParams();
  const router = useRouter();
  const copropiedadId = Number(params.copropiedadId);

  // State
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copropiedad, setCopropiedad] = useState<Copropiedad | null>(null);
  const [metrics, setMetrics] = useState<CopropiedadMetrics | null>(null);
  const [analysis, setAnalysis] = useState<PrecessionAnalysis | null>(null);
  const [alerts, setAlerts] = useState<PrecessionAlert[]>([]);

  // Form state
  const [formData, setFormData] = useState<AnalyzeFormData>({
    copropiedad_id: copropiedadId,
    horizon: 36,
    radius: 1000,
    max_depth: 4,
    include_ml: true,
    generate_heatmap: false,
    force_refresh: false,
  });

  // Load initial data
  useEffect(() => {
    if (copropiedadId) {
      loadData();
    }
  }, [copropiedadId]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load copropiedad
      const cop = await paeApi.getCopropiedad(copropiedadId);
      setCopropiedad(cop);

      // Try to load existing metrics
      try {
        const met = await paeApi.getConsolidatedMetrics(copropiedadId);
        setMetrics(met);
      } catch {
        // No metrics yet - that's ok
      }

      // Try to load existing analysis
      try {
        const dashboard = await paeApi.getDashboard(copropiedadId);
        if (dashboard?.analysis) {
          setAnalysis(dashboard.analysis);
          setAlerts(dashboard.alerts || []);
        }
      } catch {
        // No analysis yet - that's ok
      }

    } catch (err) {
      console.error('Error loading data:', err);
      setError('Error al cargar datos de la copropiedad');
    } finally {
      setLoading(false);
    }
  };

  const handleRunAnalysis = async () => {
    try {
      setAnalyzing(true);
      setError(null);

      const result = await paeApi.analyzeCopropiedad(copropiedadId, formData);
      setAnalysis(result);

      // Reload alerts
      const alertsData = await paeApi.getAlerts({ copropiedad_id: copropiedadId });
      setAlerts(alertsData);

      // Reload metrics
      try {
        const met = await paeApi.getConsolidatedMetrics(copropiedadId);
        setMetrics(met);
      } catch {
        // Ignore
      }

    } catch (err: any) {
      console.error('Error running analysis:', err);
      setError(err.response?.data?.message || 'Error al ejecutar análisis');
    } finally {
      setAnalyzing(false);
    }
  };

  // Transform effects to timeline
  const timelineItems: TimelineItem[] = analysis?.effects_summary?.top_effects?.map((effect, i) => ({
    id: effect.id || `effect-${i}`,
    title: `Efecto ${ANGLE_CONFIG[effect.precession_angle]?.label || 'N/A'}`,
    description: effect.description,
    date: new Date(Date.now() + effect.temporal_lag_months * 30 * 24 * 60 * 60 * 1000)
      .toLocaleDateString('es-CL'),
    horizon_months: effect.temporal_lag_months,
    type: effect.effect_type || (effect.value_uf >= 0 ? 'positive' : 'negative'),
    value_uf: effect.value_uf,
    angle: effect.precession_angle,
  })) || [];

  // Radar data
  const radarData = analysis ? {
    direct_0: (analysis.direct_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    induced_45: (analysis.induced_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    precession_90: (analysis.precession_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    systemic_135: (analysis.systemic_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    counter_180: (analysis.counter_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
  } : null;

  // =========================================================
  // RENDER
  // =========================================================

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <PrecessionSkeleton />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PrecessionSkeleton type="chart" />
          <PrecessionSkeleton type="chart" />
        </div>
      </div>
    );
  }

  if (!copropiedad) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <span className="text-4xl">❌</span>
          <h2 className="text-xl font-semibold text-red-800 mt-4">
            Copropiedad no encontrada
          </h2>
          <p className="text-red-600 mt-2">
            No se encontró la copropiedad con ID {copropiedadId}
          </p>
          <Link
            href="/dashboard/precession"
            className="inline-block mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Volver al Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/dashboard/precession" className="hover:text-purple-600">
              Dashboard PAE
            </Link>
            <span>/</span>
            <span>Análisis</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">
            {copropiedad.nombre}
          </h1>
          <p className="text-gray-600">
            {copropiedad.direccion}, {copropiedad.comuna}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href={`/precession/report/${copropiedadId}`}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            📄 Ver Reporte
          </Link>
          <Link
            href={`/precession/compare?ids=${copropiedadId}`}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            ⚖️ Comparar
          </Link>
        </div>
      </div>

      {/* Analysis Form */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <span>⚙️</span>
          Configuración del Análisis
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* Horizon */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Horizonte Temporal (meses)
            </label>
            <select
              value={formData.horizon}
              onChange={(e) => setFormData({ ...formData, horizon: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value={12}>12 meses</option>
              <option value={24}>24 meses</option>
              <option value={36}>36 meses</option>
              <option value={60}>60 meses</option>
              <option value={120}>120 meses</option>
            </select>
          </div>

          {/* Radius */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Radio de Influencia (metros)
            </label>
            <select
              value={formData.radius}
              onChange={(e) => setFormData({ ...formData, radius: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value={500}>500 m</option>
              <option value={1000}>1,000 m</option>
              <option value={2000}>2,000 m</option>
              <option value={5000}>5,000 m</option>
            </select>
          </div>

          {/* Max Depth */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Profundidad Máxima
            </label>
            <select
              value={formData.max_depth}
              onChange={(e) => setFormData({ ...formData, max_depth: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value={2}>2 niveles</option>
              <option value={3}>3 niveles</option>
              <option value={4}>4 niveles</option>
              <option value={5}>5 niveles</option>
              <option value={6}>6 niveles</option>
            </select>
          </div>

          {/* Options */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Opciones
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.include_ml}
                onChange={(e) => setFormData({ ...formData, include_ml: e.target.checked })}
                className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
              />
              <span className="text-sm text-gray-600">Incluir ML</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.force_refresh}
                onChange={(e) => setFormData({ ...formData, force_refresh: e.target.checked })}
                className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
              />
              <span className="text-sm text-gray-600">Forzar recálculo</span>
            </label>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
            {error}
          </div>
        )}

        <button
          onClick={handleRunAnalysis}
          disabled={analyzing}
          className="w-full md:w-auto px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <span className="animate-spin">⏳</span>
              Analizando...
            </>
          ) : (
            <>
              <span>▶️</span>
              Ejecutar Análisis Precesional
            </>
          )}
        </button>
      </div>

      {/* Results */}
      {analysis ? (
        <>
          {/* Score Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <PrecessionScoreCard
              title="Score Precesional"
              value={analysis.precession_score}
              maxValue={100}
              color="purple"
            />
            <PrecessionScoreCard
              title="Score de Riesgo"
              value={analysis.risk_score * 100}
              maxValue={100}
              color="red"
            />
            <PrecessionScoreCard
              title="Score Oportunidad"
              value={analysis.opportunity_score * 100}
              maxValue={100}
              color="green"
            />
            <PrecessionScoreCard
              title="Confianza"
              value={analysis.confidence * 100}
              maxValue={100}
              color="blue"
            />
          </div>

          {/* Values Table with Traffic Lights */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <span>📊</span>
              Valores por Ángulo Precesional
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Ángulo</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Grados</th>
                    <th className="text-right py-3 px-4 font-medium text-gray-600">Valor (UF)</th>
                    <th className="text-right py-3 px-4 font-medium text-gray-600">% del Total</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">Semáforo</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Descripción</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { key: PrecessionAngle.DIRECT_0, value: analysis.direct_value_uf },
                    { key: PrecessionAngle.INDUCED_45, value: analysis.induced_value_uf },
                    { key: PrecessionAngle.PRECESSION_90, value: analysis.precession_value_uf },
                    { key: PrecessionAngle.SYSTEMIC_135, value: analysis.systemic_value_uf },
                    { key: PrecessionAngle.COUNTER_180, value: analysis.counter_value_uf },
                  ].map(({ key, value }) => {
                    const config = ANGLE_CONFIG[key];
                    const percentage = (value / analysis.total_precession_value_uf) * 100;
                    const isPositive = value >= 0;
                    
                    return (
                      <tr key={key} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: config.color }}
                            />
                            <span className="font-medium">{config.label}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-gray-600">{config.degrees}°</td>
                        <td className="py-3 px-4 text-right font-mono">
                          {value.toLocaleString()} UF
                        </td>
                        <td className="py-3 px-4 text-right">
                          {percentage.toFixed(1)}%
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block w-4 h-4 rounded-full ${
                              percentage > 30 ? 'bg-green-500' :
                              percentage > 15 ? 'bg-yellow-500' :
                              percentage > 5 ? 'bg-orange-500' : 'bg-red-500'
                            }`}
                          />
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-500">
                          {config.description}
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="bg-purple-50 font-semibold">
                    <td className="py-3 px-4" colSpan={2}>TOTAL</td>
                    <td className="py-3 px-4 text-right font-mono">
                      {analysis.total_precession_value_uf.toLocaleString()} UF
                    </td>
                    <td className="py-3 px-4 text-right">100%</td>
                    <td className="py-3 px-4"></td>
                    <td className="py-3 px-4"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Radar */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Distribución Radial
              </h3>
              {radarData && <PrecessionRadarChart data={radarData} height={300} />}
            </div>

            {/* Bar Chart */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Valores por Ángulo
              </h3>
              <PrecessionValuesChart analysis={analysis} height={300} />
            </div>
          </div>

          {/* ML Predictions */}
          {analysis.ml_predictions && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <span>🤖</span>
                Predicciones Machine Learning
              </h3>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <MLPredictionsChart
                  predictions={analysis.ml_predictions.predictions}
                  confidenceIntervals={analysis.ml_predictions.confidence_intervals}
                  height={250}
                />

                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Intervalos de Confianza (95%)</h4>
                  <div className="space-y-2">
                    {Object.entries(analysis.ml_predictions.predictions).map(([horizon, value]) => {
                      const interval = analysis.ml_predictions?.confidence_intervals?.[horizon];
                      return (
                        <div key={horizon} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <span className="font-medium">{horizon}</span>
                          <div className="text-right">
                            <span className="text-purple-600 font-semibold">
                              {(value * 100).toFixed(1)}%
                            </span>
                            {interval && (
                              <span className="text-gray-500 text-sm ml-2">
                                [{(interval[0] * 100).toFixed(1)}% - {(interval[1] * 100).toFixed(1)}%]
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {analysis.ml_predictions.feature_importance && (
                    <div className="mt-4">
                      <h4 className="font-medium text-gray-700 mb-3">Importancia de Features</h4>
                      <div className="space-y-2">
                        {Object.entries(analysis.ml_predictions.feature_importance)
                          .sort(([, a], [, b]) => b - a)
                          .slice(0, 5)
                          .map(([feature, importance]) => (
                            <div key={feature} className="flex items-center gap-2">
                              <div className="flex-1">
                                <div className="flex justify-between text-sm mb-1">
                                  <span className="text-gray-600">{feature}</span>
                                  <span className="font-medium">{(importance * 100).toFixed(0)}%</span>
                                </div>
                                <div className="h-2 bg-gray-200 rounded-full">
                                  <div
                                    className="h-2 bg-purple-500 rounded-full"
                                    style={{ width: `${importance * 100}%` }}
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Timeline */}
          {timelineItems.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <span>⏱️</span>
                Timeline de Efectos Proyectados
              </h3>
              <PrecessionTimeline items={timelineItems} />
            </div>
          )}

          {/* Alerts */}
          {alerts.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <span>🚨</span>
                Alertas Generadas ({alerts.length})
              </h3>
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <PrecessionAlertCard
                    key={alert.id}
                    alert={alert}
                    onViewDetails={(id) => router.push(`/precession/alerts?id=${id}`)}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Analysis Metadata */}
          <div className="bg-gray-100 rounded-lg p-4 text-sm text-gray-600">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <span className="font-medium">ID Análisis:</span> {analysis.id}
              </div>
              <div>
                <span className="font-medium">Estado:</span> {analysis.status}
              </div>
              <div>
                <span className="font-medium">Creado:</span>{' '}
                {new Date(analysis.created_at).toLocaleString('es-CL')}
              </div>
              <div>
                <span className="font-medium">Expira:</span>{' '}
                {new Date(analysis.expires_at).toLocaleString('es-CL')}
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Sin análisis previo
          </h3>
          <p className="text-gray-600 mb-6">
            Configure los parámetros y ejecute el análisis precesional
          </p>
        </div>
      )}
    </div>
  );
}
