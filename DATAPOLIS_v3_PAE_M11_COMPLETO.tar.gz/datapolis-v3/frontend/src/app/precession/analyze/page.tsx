/**
 * =========================================================
 * PAE M11 - Página de Análisis
 * =========================================================
 * 
 * /precession/analyze/[copropiedadId]
 */

'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import paeApi from '@/lib/api/pae';
import {
  PrecessionAnalysis,
  AnalysisFormData,
  AnalysisStatus,
  PRECESSION_ANGLES,
} from '@/types/pae.types';
import { PrecessionScoreCard, AngleBadge, CardSkeleton } from '@/components/pae/PrecessionCards';
import { PrecessionRadarChart, AngleDetailsTable } from '@/components/pae/PrecessionRadarChart';
import { ValuesByAngleChart, MLPredictionsChart } from '@/components/pae/PrecessionCharts';
import { PrecessionTimeline } from '@/components/pae/PrecessionTimeline';

// =========================================================
// ANALYSIS FORM
// =========================================================

interface AnalysisFormProps {
  onSubmit: (data: AnalysisFormData) => void;
  loading: boolean;
  copropiedadId?: number;
}

function AnalysisForm({ onSubmit, loading, copropiedadId }: AnalysisFormProps) {
  const [copropiedades, setCopropiedades] = useState<any[]>([]);
  const [formData, setFormData] = useState<AnalysisFormData>({
    copropiedadId: copropiedadId || 0,
    horizon: 36,
    radius: 1000,
    maxDepth: 4,
    includeMl: true,
    generateHeatmap: false,
    forceRefresh: false,
  });

  useEffect(() => {
    loadCopropiedades();
  }, []);

  const loadCopropiedades = async () => {
    try {
      const result = await paeApi.getCopropiedades({});
      setCopropiedades(result.data);
      if (!copropiedadId && result.data.length > 0) {
        setFormData(prev => ({ ...prev, copropiedadId: result.data[0].id }));
      }
    } catch (err) {
      console.error('Error loading copropiedades:', err);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">
        Configuración del Análisis
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Copropiedad Select */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Copropiedad
          </label>
          <select
            value={formData.copropiedadId}
            onChange={(e) => setFormData(prev => ({ ...prev, copropiedadId: Number(e.target.value) }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            disabled={!!copropiedadId}
          >
            <option value={0}>Seleccione...</option>
            {copropiedades.map(cop => (
              <option key={cop.id} value={cop.id}>
                {cop.nombre} - {cop.comuna}
              </option>
            ))}
          </select>
        </div>

        {/* Horizon */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Horizonte Temporal (meses)
          </label>
          <select
            value={formData.horizon}
            onChange={(e) => setFormData(prev => ({ ...prev, horizon: Number(e.target.value) }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value={12}>12 meses</option>
            <option value={24}>24 meses</option>
            <option value={36}>36 meses (recomendado)</option>
            <option value={60}>60 meses</option>
            <option value={120}>120 meses</option>
          </select>
        </div>

        {/* Radius */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Radio de Influencia (metros)
          </label>
          <select
            value={formData.radius}
            onChange={(e) => setFormData(prev => ({ ...prev, radius: Number(e.target.value) }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value={500}>500m</option>
            <option value={1000}>1.000m (recomendado)</option>
            <option value={2000}>2.000m</option>
            <option value={5000}>5.000m</option>
          </select>
        </div>

        {/* Max Depth */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Profundidad Máxima
          </label>
          <select
            value={formData.maxDepth}
            onChange={(e) => setFormData(prev => ({ ...prev, maxDepth: Number(e.target.value) }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value={2}>2 niveles</option>
            <option value={3}>3 niveles</option>
            <option value={4}>4 niveles (recomendado)</option>
            <option value={5}>5 niveles</option>
            <option value={6}>6 niveles (máximo)</option>
          </select>
        </div>

        {/* Options */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.includeMl}
              onChange={(e) => setFormData(prev => ({ ...prev, includeMl: e.target.checked }))}
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className="text-sm text-gray-700">Incluir predicciones ML</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.generateHeatmap}
              onChange={(e) => setFormData(prev => ({ ...prev, generateHeatmap: e.target.checked }))}
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className="text-sm text-gray-700">Generar heatmap</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.forceRefresh}
              onChange={(e) => setFormData(prev => ({ ...prev, forceRefresh: e.target.checked }))}
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className="text-sm text-gray-700">Forzar recálculo</span>
          </label>
        </div>

        {/* Submit Button */}
        <div className="flex items-end">
          <button
            type="submit"
            disabled={loading || !formData.copropiedadId}
            className="w-full px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Analizando...
              </>
            ) : (
              <>
                🔮 Ejecutar Análisis
              </>
            )}
          </button>
        </div>
      </div>
    </form>
  );
}

// =========================================================
// ANALYSIS RESULTS
// =========================================================

interface AnalysisResultsProps {
  analysis: PrecessionAnalysis;
}

function AnalysisResults({ analysis }: AnalysisResultsProps) {
  const radarData = {
    direct_0: (analysis.directValueUf / analysis.totalPrecessionValueUf) * 100,
    induced_45: (analysis.inducedValueUf / analysis.totalPrecessionValueUf) * 100,
    precession_90: (analysis.precessionValueUf / analysis.totalPrecessionValueUf) * 100,
    systemic_135: (analysis.systemicValueUf / analysis.totalPrecessionValueUf) * 100,
    counter_180: (analysis.counterValueUf / analysis.totalPrecessionValueUf) * 100,
  };

  const getStatusColor = (value: number) => {
    if (value >= 70) return 'bg-green-100 text-green-800';
    if (value >= 40) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="space-y-6">
      {/* Scores */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <PrecessionScoreCard
          title="Precession Score"
          value={analysis.precessionScore}
          subtitle={`Confianza: ${(analysis.confidence * 100).toFixed(0)}%`}
          color="purple"
        />
        <PrecessionScoreCard
          title="Risk Score"
          value={analysis.riskScore * 100}
          subtitle="Nivel de riesgo"
          color="red"
        />
        <PrecessionScoreCard
          title="Opportunity"
          value={analysis.opportunityScore * 100}
          subtitle="Potencial"
          color="green"
        />
        <div className="bg-white rounded-xl shadow-lg p-5">
          <div className="text-sm text-gray-500 mb-1">Valor Total</div>
          <div className="text-3xl font-bold text-purple-600">
            {analysis.totalPrecessionValueUf.toLocaleString()}
          </div>
          <div className="text-sm text-gray-500">UF</div>
        </div>
      </div>

      {/* Radar and Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Distribución por Ángulo
          </h3>
          <PrecessionRadarChart data={radarData} height={300} />
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Valores por Ángulo (UF)
          </h3>
          <ValuesByAngleChart analysis={analysis} height={300} />
        </div>
      </div>

      {/* Angle Details Table */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Detalle por Ángulo Precesional
        </h3>
        <AngleDetailsTable data={radarData} showProgress={true} />
      </div>

      {/* ML Predictions */}
      {analysis.mlPredictions && Object.keys(analysis.mlPredictions).length > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            📈 Predicciones Machine Learning
          </h3>
          <MLPredictionsChart
            predictions={analysis.mlPredictions}
            height={280}
            showConfidence={true}
          />
          <div className="mt-4 p-3 bg-purple-50 rounded-lg">
            <p className="text-sm text-purple-800">
              <strong>Modelo:</strong> PAE-ML v{analysis.mlPredictions['12m']?.modelVersion || '1.0'} | 
              <strong className="ml-2">Confianza:</strong> {((analysis.mlPredictions['12m']?.confidence || 0) * 100).toFixed(0)}%
            </p>
          </div>
        </div>
      )}

      {/* Effects Timeline */}
      {analysis.effects && analysis.effects.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Timeline de Efectos
          </h3>
          <PrecessionTimeline effects={analysis.effects} maxItems={10} />
        </div>
      )}

      {/* Metadata */}
      <div className="bg-gray-100 rounded-lg p-4 text-sm text-gray-600">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <span className="font-medium">ID:</span> {analysis.id.slice(0, 8)}...
          </div>
          <div>
            <span className="font-medium">Estado:</span> {analysis.status}
          </div>
          <div>
            <span className="font-medium">Tiempo:</span> {analysis.executionTimeMs}ms
          </div>
          <div>
            <span className="font-medium">Creado:</span> {new Date(analysis.createdAt).toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================
// MAIN PAGE
// =========================================================

export default function AnalyzePage() {
  const params = useParams();
  const router = useRouter();
  const copropiedadId = params?.copropiedadId ? Number(params.copropiedadId) : undefined;
  
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<PrecessionAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (data: AnalysisFormData) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await paeApi.analyzeCopropiedad(data.copropiedadId, {
        horizon: data.horizon,
        radius: data.radius,
        maxDepth: data.maxDepth,
        includeMl: data.includeMl,
        generateHeatmap: data.generateHeatmap,
        forceRefresh: data.forceRefresh,
      });
      setAnalysis(result);
    } catch (err: any) {
      setError(err.message || 'Error ejecutando análisis');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard/precession" className="text-gray-500 hover:text-gray-700">
              ← Volver
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                🔮 Ejecutar Análisis Precesional
              </h1>
              <p className="text-gray-500 text-sm">
                Configure los parámetros y ejecute el análisis
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* Form */}
        <AnalysisForm
          onSubmit={handleAnalyze}
          loading={loading}
          copropiedadId={copropiedadId}
        />

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Results */}
        {analysis && <AnalysisResults analysis={analysis} />}
      </main>
    </div>
  );
}
