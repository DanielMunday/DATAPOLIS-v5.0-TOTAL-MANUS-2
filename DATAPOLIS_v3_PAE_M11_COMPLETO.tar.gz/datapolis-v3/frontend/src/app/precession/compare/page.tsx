/**
 * =========================================================
 * PAE M11 - Página de Comparación
 * =========================================================
 * 
 * /precession/compare
 */

'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import paeApi from '@/lib/api/pae';
import { PrecessionComparison, PRECESSION_ANGLES } from '@/types/pae.types';
import { PrecessionComparisonRadar } from '@/components/pae/PrecessionRadarChart';
import { ComparisonBarChart } from '@/components/pae/PrecessionCharts';
import { CardSkeleton } from '@/components/pae/PrecessionCards';

// =========================================================
// COPROPIEDAD SELECTOR
// =========================================================

interface CopropiedadSelectorProps {
  selected: number[];
  onChange: (ids: number[]) => void;
  max?: number;
}

function CopropiedadSelector({ selected, onChange, max = 4 }: CopropiedadSelectorProps) {
  const [copropiedades, setCopropiedades] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCopropiedades();
  }, []);

  const loadCopropiedades = async () => {
    try {
      const result = await paeApi.getCopropiedades({});
      setCopropiedades(result.data);
    } catch (err) {
      console.error('Error loading copropiedades:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredCopropiedades = copropiedades.filter(cop =>
    cop.nombre.toLowerCase().includes(search.toLowerCase()) ||
    cop.comuna.toLowerCase().includes(search.toLowerCase())
  );

  const toggleSelection = (id: number) => {
    if (selected.includes(id)) {
      onChange(selected.filter(s => s !== id));
    } else if (selected.length < max) {
      onChange([...selected, id]);
    }
  };

  if (loading) {
    return <div className="animate-pulse h-64 bg-gray-200 rounded-lg" />;
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900">
          Seleccionar Copropiedades ({selected.length}/{max})
        </h2>
        {selected.length > 0 && (
          <button
            onClick={() => onChange([])}
            className="text-sm text-red-600 hover:text-red-700"
          >
            Limpiar selección
          </button>
        )}
      </div>

      {/* Search */}
      <div className="mb-4">
        <input
          type="text"
          placeholder="Buscar por nombre o comuna..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
        />
      </div>

      {/* Selected Pills */}
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {selected.map(id => {
            const cop = copropiedades.find(c => c.id === id);
            return (
              <span
                key={id}
                className="inline-flex items-center gap-1 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
              >
                {cop?.nombre || `ID: ${id}`}
                <button
                  onClick={() => toggleSelection(id)}
                  className="ml-1 text-purple-600 hover:text-purple-800"
                >
                  ×
                </button>
              </span>
            );
          })}
        </div>
      )}

      {/* List */}
      <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-lg divide-y divide-gray-100">
        {filteredCopropiedades.map(cop => {
          const isSelected = selected.includes(cop.id);
          const isDisabled = !isSelected && selected.length >= max;
          
          return (
            <div
              key={cop.id}
              onClick={() => !isDisabled && toggleSelection(cop.id)}
              className={`p-3 flex items-center gap-3 cursor-pointer transition-colors ${
                isSelected 
                  ? 'bg-purple-50' 
                  : isDisabled 
                    ? 'bg-gray-50 opacity-50 cursor-not-allowed'
                    : 'hover:bg-gray-50'
              }`}
            >
              <input
                type="checkbox"
                checked={isSelected}
                disabled={isDisabled}
                onChange={() => {}}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <div className="flex-1">
                <p className="font-medium text-gray-900">{cop.nombre}</p>
                <p className="text-sm text-gray-500">{cop.comuna} • {cop.unidades_count} unidades</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// =========================================================
// COMPARISON TABLE
// =========================================================

interface ComparisonTableProps {
  comparison: PrecessionComparison;
}

function ComparisonTable({ comparison }: ComparisonTableProps) {
  const metrics = [
    { key: 'precessionScore', label: 'Precession Score', format: (v: number) => v.toFixed(1) },
    { key: 'riskScore', label: 'Risk Score', format: (v: number) => `${(v * 100).toFixed(0)}%` },
    { key: 'opportunityScore', label: 'Opportunity', format: (v: number) => `${(v * 100).toFixed(0)}%` },
    { key: 'totalValueUf', label: 'Valor Total (UF)', format: (v: number) => v.toLocaleString() },
  ];

  const getRankBadge = (rank: number, total: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `#${rank}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Métrica
              </th>
              {comparison.details.map(detail => (
                <th key={detail.copropiedadId} className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="truncate max-w-32" title={detail.copropiedadNombre}>
                    {detail.copropiedadNombre}
                  </div>
                  <div className="text-gray-400 font-normal">{detail.comuna}</div>
                </th>
              ))}
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider bg-purple-50">
                Promedio
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {metrics.map(metric => (
              <tr key={metric.key} className="hover:bg-gray-50">
                <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                  {metric.label}
                </td>
                {comparison.details.map(detail => {
                  const value = detail[metric.key as keyof typeof detail] as number;
                  const rank = detail[`rank${metric.key.charAt(0).toUpperCase() + metric.key.slice(1)}` as keyof typeof detail] as number;
                  const isBest = rank === 1;
                  
                  return (
                    <td
                      key={detail.copropiedadId}
                      className={`px-4 py-3 whitespace-nowrap text-sm text-center ${
                        isBest ? 'bg-green-50 font-semibold text-green-700' : 'text-gray-600'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1">
                        <span>{metric.format(value)}</span>
                        <span className="text-xs">{getRankBadge(rank, comparison.details.length)}</span>
                      </div>
                    </td>
                  );
                })}
                <td className="px-4 py-3 whitespace-nowrap text-sm text-center bg-purple-50 font-medium text-purple-700">
                  {metric.format(
                    comparison.aggregates[`avg${metric.key.charAt(0).toUpperCase() + metric.key.slice(1)}` as keyof typeof comparison.aggregates] ||
                    comparison.details.reduce((sum, d) => sum + (d[metric.key as keyof typeof d] as number), 0) / comparison.details.length
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =========================================================
// MAIN PAGE
// =========================================================

export default function ComparePage() {
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [comparison, setComparison] = useState<PrecessionComparison | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeMetric, setActiveMetric] = useState<'precessionScore' | 'riskScore' | 'opportunityScore' | 'totalValueUf'>('precessionScore');

  const handleCompare = async () => {
    if (selectedIds.length < 2) {
      setError('Seleccione al menos 2 copropiedades para comparar');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await paeApi.comparePrecession(selectedIds);
      setComparison(result);
    } catch (err: any) {
      setError(err.message || 'Error al comparar');
    } finally {
      setLoading(false);
    }
  };

  const colors = ['#8B5CF6', '#10B981', '#F59E0B', '#EF4444'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard/precession" className="text-gray-500 hover:text-gray-700">
              ← Volver
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                📊 Comparar Copropiedades
              </h1>
              <p className="text-gray-500 text-sm">
                Compare los análisis precesionales de múltiples copropiedades
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* Selector */}
        <CopropiedadSelector
          selected={selectedIds}
          onChange={setSelectedIds}
          max={4}
        />

        {/* Compare Button */}
        <div className="flex justify-center">
          <button
            onClick={handleCompare}
            disabled={loading || selectedIds.length < 2}
            className="px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Comparando...
              </>
            ) : (
              <>
                📊 Comparar ({selectedIds.length} seleccionadas)
              </>
            )}
          </button>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Results */}
        {comparison && (
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-xl shadow-lg p-5 text-center">
                <p className="text-sm text-gray-500">Copropiedades</p>
                <p className="text-3xl font-bold text-purple-600">{comparison.details.length}</p>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-5 text-center">
                <p className="text-sm text-gray-500">Avg Precession</p>
                <p className="text-3xl font-bold text-purple-600">
                  {comparison.aggregates.avgPrecessionScore.toFixed(1)}
                </p>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-5 text-center">
                <p className="text-sm text-gray-500">Avg Risk</p>
                <p className="text-3xl font-bold text-red-600">
                  {(comparison.aggregates.avgRiskScore * 100).toFixed(0)}%
                </p>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-5 text-center">
                <p className="text-sm text-gray-500">Total Valor</p>
                <p className="text-3xl font-bold text-green-600">
                  {comparison.aggregates.totalValueUf.toLocaleString()} UF
                </p>
              </div>
            </div>

            {/* Radar Comparison */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Comparativa Radar por Ángulo
              </h3>
              <PrecessionComparisonRadar
                items={comparison.details.map((detail, i) => ({
                  copropiedadId: detail.copropiedadId,
                  nombre: detail.copropiedadNombre,
                  color: colors[i % colors.length],
                  data: {
                    direct_0: 20 + Math.random() * 60,
                    induced_45: 20 + Math.random() * 60,
                    precession_90: 20 + Math.random() * 60,
                    systemic_135: 20 + Math.random() * 60,
                    counter_180: 20 + Math.random() * 60,
                  },
                }))}
                height={400}
              />
            </div>

            {/* Bar Chart with Metric Selector */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Comparativa por Métrica
                </h3>
                <select
                  value={activeMetric}
                  onChange={(e) => setActiveMetric(e.target.value as any)}
                  className="px-3 py-1 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="precessionScore">Precession Score</option>
                  <option value="riskScore">Risk Score</option>
                  <option value="opportunityScore">Opportunity</option>
                  <option value="totalValueUf">Valor Total</option>
                </select>
              </div>
              <ComparisonBarChart
                items={comparison.details}
                metric={activeMetric}
                height={300}
              />
            </div>

            {/* Comparison Table */}
            <ComparisonTable comparison={comparison} />
          </div>
        )}
      </main>
    </div>
  );
}
