/**
 * =========================================================
 * PAE M11 - Layout para Sección Precession
 * =========================================================
 */

import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'PAE - Precession Analytics Engine | DATAPOLIS',
  description: 'Análisis precesional basado en la teoría de R. Buckminster Fuller para copropiedades',
};

export default function PrecessionLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      {children}
    </div>
  );
}
