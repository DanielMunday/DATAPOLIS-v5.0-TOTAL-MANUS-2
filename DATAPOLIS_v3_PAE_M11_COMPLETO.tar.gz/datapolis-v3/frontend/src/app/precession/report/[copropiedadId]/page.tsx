/**
 * =========================================================
 * PAE M11 - Página de Reporte para Inversor
 * =========================================================
 * 
 * Página: /precession/report/[copropiedadId]
 * Vista previa y generación de reporte PDF
 */

'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  PrecessionScoreCard,
  PrecessionRadarChart,
  PrecessionValuesChart,
  MLPredictionsChart,
  PrecessionSkeleton,
  ANGLE_CONFIG,
} from '@/components/pae/components';
import { paeApi } from '@/services/pae.service';
import {
  PrecessionAnalysis,
  Copropiedad,
  CopropiedadMetrics,
  InvestorReport,
  PrecessionAngle,
} from '@/types/pae.types';

// =========================================================
// PAGE COMPONENT
// =========================================================

export default function InvestorReportPage() {
  const params = useParams();
  const router = useRouter();
  const copropiedadId = Number(params.copropiedadId);
  const reportRef = useRef<HTMLDivElement>(null);

  // State
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copropiedad, setCopropiedad] = useState<Copropiedad | null>(null);
  const [analysis, setAnalysis] = useState<PrecessionAnalysis | null>(null);
  const [metrics, setMetrics] = useState<CopropiedadMetrics | null>(null);
  const [report, setReport] = useState<InvestorReport | null>(null);

  // Load data
  useEffect(() => {
    if (copropiedadId) {
      loadData();
    }
  }, [copropiedadId]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load copropiedad
      const cop = await paeApi.getCopropiedad(copropiedadId);
      setCopropiedad(cop);

      // Load analysis
      try {
        const dashboard = await paeApi.getDashboard(copropiedadId);
        if (dashboard?.analysis) {
          setAnalysis(dashboard.analysis);
        }
      } catch {
        // No analysis
      }

      // Load metrics
      try {
        const met = await paeApi.getConsolidatedMetrics(copropiedadId);
        setMetrics(met);
      } catch {
        // No metrics
      }

      // Try to load existing report
      try {
        const rep = await paeApi.generateInvestorReport(copropiedadId, 'json') as InvestorReport;
        setReport(rep);
      } catch {
        // No report yet
      }

    } catch (err) {
      console.error('Error loading data:', err);
      setError('Error al cargar datos');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    try {
      setGenerating(true);
      await paeApi.downloadReportPDF(copropiedadId);
    } catch (err) {
      console.error('Error generating PDF:', err);
      setError('Error al generar PDF');
    } finally {
      setGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Radar data
  const radarData = analysis ? {
    direct_0: (analysis.direct_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    induced_45: (analysis.induced_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    precession_90: (analysis.precession_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    systemic_135: (analysis.systemic_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
    counter_180: (analysis.counter_value_uf / (analysis.total_precession_value_uf || 1)) * 100,
  } : null;

  // =========================================================
  // RENDER
  // =========================================================

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <PrecessionSkeleton />
        <PrecessionSkeleton type="chart" />
      </div>
    );
  }

  if (!copropiedad) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <span className="text-4xl">❌</span>
          <h2 className="text-xl font-semibold text-red-800 mt-4">
            Copropiedad no encontrada
          </h2>
          <Link
            href="/dashboard/precession"
            className="inline-block mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Volver al Dashboard
          </Link>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
          <span className="text-4xl">⚠️</span>
          <h2 className="text-xl font-semibold text-yellow-800 mt-4">
            Sin análisis disponible
          </h2>
          <p className="text-yellow-700 mt-2">
            Ejecute un análisis precesional primero para generar el reporte
          </p>
          <Link
            href={`/precession/analyze/${copropiedadId}`}
            className="inline-block mt-4 px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
          >
            Ejecutar Análisis
          </Link>
        </div>
      </div>
    );
  }

  const currentDate = new Date().toLocaleDateString('es-CL', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Controls (not printed) */}
      <div className="print:hidden bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              href="/dashboard/precession"
              className="text-gray-500 hover:text-gray-700"
            >
              ← Volver
            </Link>
            <h1 className="text-lg font-semibold">Reporte para Inversor</h1>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center gap-2"
            >
              <span>🖨️</span>
              Imprimir
            </button>
            <button
              onClick={handleDownloadPDF}
              disabled={generating}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2"
            >
              {generating ? (
                <>
                  <span className="animate-spin">⏳</span>
                  Generando...
                </>
              ) : (
                <>
                  <span>📄</span>
                  Descargar PDF
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Report Content */}
      <div ref={reportRef} className="max-w-5xl mx-auto p-6 print:p-0">
        <div className="bg-white rounded-xl shadow-lg print:shadow-none print:rounded-none">
          {/* Cover Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-8 rounded-t-xl print:rounded-none">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm opacity-80 mb-2">
                  DATAPOLIS · Precession Analytics Engine
                </div>
                <h1 className="text-3xl font-bold mb-2">
                  Reporte de Análisis Precesional
                </h1>
                <h2 className="text-xl opacity-90">
                  {copropiedad.nombre}
                </h2>
              </div>
              <div className="text-right">
                <div className="text-6xl mb-2">🏢</div>
                <div className="text-sm opacity-80">{currentDate}</div>
              </div>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="p-8 border-b">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">📋</span>
              Resumen Ejecutivo
            </h3>
            
            <div className="grid grid-cols-3 gap-6 mb-6">
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-4xl font-bold text-purple-600">
                  {analysis.precession_score.toFixed(1)}
                </div>
                <div className="text-sm text-purple-800 font-medium">
                  Score Precesional
                </div>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-4xl font-bold text-red-600">
                  {(analysis.risk_score * 100).toFixed(0)}%
                </div>
                <div className="text-sm text-red-800 font-medium">
                  Índice de Riesgo
                </div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-4xl font-bold text-green-600">
                  {(analysis.opportunity_score * 100).toFixed(0)}%
                </div>
                <div className="text-sm text-green-800 font-medium">
                  Potencial de Oportunidad
                </div>
              </div>
            </div>

            <p className="text-gray-700 leading-relaxed">
              Este reporte presenta el análisis precesional de <strong>{copropiedad.nombre}</strong>, 
              ubicado en {copropiedad.direccion}, {copropiedad.comuna}. El análisis evalúa los efectos 
              directos e indirectos sobre el valor del activo, utilizando la metodología precesional 
              basada en la teoría de R. Buckminster Fuller, complementada con modelos de machine learning.
            </p>
          </div>

          {/* Property Info */}
          <div className="p-8 border-b">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">🏠</span>
              Información del Activo
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Nombre</div>
                <div className="font-semibold">{copropiedad.nombre}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Dirección</div>
                <div className="font-semibold">{copropiedad.direccion}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Comuna</div>
                <div className="font-semibold">{copropiedad.comuna}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Región</div>
                <div className="font-semibold">{copropiedad.region}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Tipo</div>
                <div className="font-semibold">{copropiedad.tipo}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Unidades</div>
                <div className="font-semibold">{copropiedad.unidades_count}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Superficie</div>
                <div className="font-semibold">
                  {copropiedad.superficie_total?.toLocaleString() || 'N/D'} m²
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500">Coordenadas</div>
                <div className="font-semibold text-sm">
                  {copropiedad.latitud.toFixed(4)}, {copropiedad.longitud.toFixed(4)}
                </div>
              </div>
            </div>
          </div>

          {/* Precession Analysis */}
          <div className="p-8 border-b">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">📊</span>
              Análisis Precesional por Ángulo
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Radar Chart */}
              <div>
                <h4 className="font-semibold text-gray-700 mb-3 text-center">
                  Distribución de Efectos
                </h4>
                {radarData && (
                  <PrecessionRadarChart data={radarData} height={280} showLegend={false} />
                )}
              </div>

              {/* Values Table */}
              <div>
                <h4 className="font-semibold text-gray-700 mb-3">
                  Valores por Ángulo
                </h4>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Ángulo</th>
                      <th className="text-right py-2">Valor (UF)</th>
                      <th className="text-right py-2">%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { key: PrecessionAngle.DIRECT_0, value: analysis.direct_value_uf },
                      { key: PrecessionAngle.INDUCED_45, value: analysis.induced_value_uf },
                      { key: PrecessionAngle.PRECESSION_90, value: analysis.precession_value_uf },
                      { key: PrecessionAngle.SYSTEMIC_135, value: analysis.systemic_value_uf },
                      { key: PrecessionAngle.COUNTER_180, value: analysis.counter_value_uf },
                    ].map(({ key, value }) => {
                      const config = ANGLE_CONFIG[key];
                      const pct = (value / analysis.total_precession_value_uf) * 100;
                      return (
                        <tr key={key} className="border-b">
                          <td className="py-2 flex items-center gap-2">
                            <span
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: config.color }}
                            />
                            {config.label} ({config.degrees}°)
                          </td>
                          <td className="text-right py-2 font-mono">
                            {value.toLocaleString()}
                          </td>
                          <td className="text-right py-2">
                            {pct.toFixed(1)}%
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="font-bold bg-gray-50">
                      <td className="py-2">TOTAL</td>
                      <td className="text-right py-2 font-mono">
                        {analysis.total_precession_value_uf.toLocaleString()}
                      </td>
                      <td className="text-right py-2">100%</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* ML Predictions */}
          {analysis.ml_predictions && (
            <div className="p-8 border-b">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <span className="text-2xl">🤖</span>
                Proyecciones Machine Learning
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <MLPredictionsChart
                    predictions={analysis.ml_predictions.predictions}
                    confidenceIntervals={analysis.ml_predictions.confidence_intervals}
                    height={250}
                  />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-700 mb-3">
                    Predicciones por Horizonte
                  </h4>
                  <div className="space-y-3">
                    {Object.entries(analysis.ml_predictions.predictions).map(([horizon, value]) => {
                      const interval = analysis.ml_predictions?.confidence_intervals?.[horizon];
                      return (
                        <div key={horizon} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <span className="font-medium">{horizon}</span>
                          <div className="text-right">
                            <span className={`font-bold ${value >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {value >= 0 ? '+' : ''}{(value * 100).toFixed(1)}%
                            </span>
                            {interval && (
                              <span className="text-gray-500 text-xs ml-2">
                                [{(interval[0] * 100).toFixed(0)}% - {(interval[1] * 100).toFixed(0)}%]
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 text-sm text-gray-500">
                    <strong>Confianza del modelo:</strong> {(analysis.confidence * 100).toFixed(0)}%
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Metrics Summary */}
          {metrics && (
            <div className="p-8 border-b">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <span className="text-2xl">📈</span>
                Métricas Integradas
              </h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {metrics.tax_risk_score !== undefined && (
                  <div className="bg-red-50 rounded-lg p-4">
                    <div className="text-sm text-red-700">Riesgo Tributario</div>
                    <div className="text-2xl font-bold text-red-600">
                      {(metrics.tax_risk_score * 100).toFixed(0)}%
                    </div>
                  </div>
                )}
                {metrics.compliance_score_global !== undefined && (
                  <div className="bg-green-50 rounded-lg p-4">
                    <div className="text-sm text-green-700">Compliance</div>
                    <div className="text-2xl font-bold text-green-600">
                      {metrics.compliance_score_global.toFixed(0)}/100
                    </div>
                  </div>
                )}
                {metrics.valuation_current_uf !== undefined && (
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="text-sm text-blue-700">Valor Actual</div>
                    <div className="text-2xl font-bold text-blue-600">
                      {metrics.valuation_current_uf.toLocaleString()} UF
                    </div>
                  </div>
                )}
                {metrics.rental_gross_yield !== undefined && (
                  <div className="bg-purple-50 rounded-lg p-4">
                    <div className="text-sm text-purple-700">Gross Yield</div>
                    <div className="text-2xl font-bold text-purple-600">
                      {metrics.rental_gross_yield.toFixed(1)}%
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Recommendations */}
          <div className="p-8 border-b">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">💡</span>
              Recomendaciones
            </h3>

            <div className="space-y-4">
              {analysis.risk_score >= 0.7 && (
                <div className="flex gap-4 p-4 bg-red-50 border-l-4 border-red-500 rounded">
                  <span className="text-2xl">⚠️</span>
                  <div>
                    <h4 className="font-semibold text-red-800">Gestión de Riesgo</h4>
                    <p className="text-red-700 text-sm">
                      El índice de riesgo es elevado. Se recomienda revisar los factores de riesgo 
                      identificados y establecer medidas de mitigación.
                    </p>
                  </div>
                </div>
              )}
              
              {analysis.opportunity_score >= 0.7 && (
                <div className="flex gap-4 p-4 bg-green-50 border-l-4 border-green-500 rounded">
                  <span className="text-2xl">🌟</span>
                  <div>
                    <h4 className="font-semibold text-green-800">Oportunidad de Inversión</h4>
                    <p className="text-green-700 text-sm">
                      El potencial de oportunidad es alto. Se recomienda evaluar estrategias de 
                      capitalización de los efectos precesionales positivos.
                    </p>
                  </div>
                </div>
              )}

              <div className="flex gap-4 p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
                <span className="text-2xl">📊</span>
                <div>
                  <h4 className="font-semibold text-blue-800">Monitoreo Continuo</h4>
                  <p className="text-blue-700 text-sm">
                    Se recomienda realizar análisis precesionales periódicos (mínimo trimestrales) 
                    para detectar cambios en los efectos y ajustar estrategias.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="p-8 bg-gray-50">
            <h3 className="text-lg font-bold text-gray-800 mb-3">
              Disclaimer
            </h3>
            <p className="text-sm text-gray-600 leading-relaxed">
              Este reporte es generado automáticamente por el Precession Analytics Engine de DATAPOLIS 
              y tiene carácter informativo. Las proyecciones y recomendaciones se basan en modelos 
              estadísticos y de machine learning que pueden no capturar todos los factores relevantes. 
              Las decisiones de inversión deben ser tomadas considerando asesoría profesional adicional 
              y análisis complementarios. DATAPOLIS SpA no se hace responsable por las decisiones tomadas 
              en base a este reporte.
            </p>
            
            <div className="mt-6 pt-6 border-t text-center text-sm text-gray-500">
              <p>
                <strong>DATAPOLIS SpA</strong> · Precession Analytics Engine v1.0
              </p>
              <p>
                Generado el {currentDate} · ID Análisis: {analysis.id}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .print\\:hidden {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}
