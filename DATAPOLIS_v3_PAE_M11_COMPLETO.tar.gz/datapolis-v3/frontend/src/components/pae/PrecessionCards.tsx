/**
 * =========================================================
 * PAE M11 - Componentes Reutilizables
 * =========================================================
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import {
  AlertSeverity,
  AlertStatus,
  PrecessionAngle,
  PRECESSION_ANGLES,
  SEVERITY_COLORS,
  STATUS_COLORS,
} from '@/types/pae.types';

// =========================================================
// PRECESSION SCORE CARD
// =========================================================

interface PrecessionScoreCardProps {
  title: string;
  value: number;
  maxValue?: number;
  subtitle?: string;
  trend?: number;
  icon?: React.ReactNode;
  color?: 'blue' | 'green' | 'red' | 'amber' | 'purple' | 'emerald';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const colorClasses = {
  blue: {
    gradient: 'from-blue-500 to-blue-600',
    text: 'text-blue-600',
    bg: 'bg-blue-50',
    ring: 'ring-blue-200',
  },
  green: {
    gradient: 'from-green-500 to-green-600',
    text: 'text-green-600',
    bg: 'bg-green-50',
    ring: 'ring-green-200',
  },
  red: {
    gradient: 'from-red-500 to-red-600',
    text: 'text-red-600',
    bg: 'bg-red-50',
    ring: 'ring-red-200',
  },
  amber: {
    gradient: 'from-amber-500 to-amber-600',
    text: 'text-amber-600',
    bg: 'bg-amber-50',
    ring: 'ring-amber-200',
  },
  purple: {
    gradient: 'from-purple-500 to-purple-600',
    text: 'text-purple-600',
    bg: 'bg-purple-50',
    ring: 'ring-purple-200',
  },
  emerald: {
    gradient: 'from-emerald-500 to-emerald-600',
    text: 'text-emerald-600',
    bg: 'bg-emerald-50',
    ring: 'ring-emerald-200',
  },
};

export function PrecessionScoreCard({
  title,
  value,
  maxValue = 100,
  subtitle,
  trend,
  icon,
  color = 'purple',
  size = 'md',
  className,
}: PrecessionScoreCardProps) {
  const percentage = Math.min((value / maxValue) * 100, 100);
  const colors = colorClasses[color];
  
  const sizeClasses = {
    sm: { padding: 'p-4', title: 'text-sm', value: 'text-2xl', ring: 'w-14 h-14' },
    md: { padding: 'p-5', title: 'text-base', value: 'text-3xl', ring: 'w-18 h-18' },
    lg: { padding: 'p-6', title: 'text-lg', value: 'text-4xl', ring: 'w-22 h-22' },
  };

  const sizes = sizeClasses[size];

  return (
    <div className={cn(
      'bg-white rounded-xl shadow-lg overflow-hidden transition-all hover:shadow-xl',
      className
    )}>
      {/* Header */}
      <div className={cn('bg-gradient-to-r text-white p-3', colors.gradient)}>
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-semibold">{title}</span>
        </div>
      </div>
      
      {/* Content */}
      <div className={cn(sizes.padding)}>
        <div className="flex items-center justify-between">
          <div>
            <div className={cn(sizes.value, 'font-bold', colors.text)}>
              {value.toFixed(1)}
            </div>
            {subtitle && (
              <p className="text-gray-500 text-sm mt-1">{subtitle}</p>
            )}
            {trend !== undefined && (
              <div className="flex items-center gap-1 mt-2">
                <span className={cn(
                  'text-sm font-medium flex items-center gap-1',
                  trend > 0 ? 'text-green-600' : trend < 0 ? 'text-red-600' : 'text-gray-500'
                )}>
                  {trend > 0 ? (
                    <TrendUpIcon className="w-4 h-4" />
                  ) : trend < 0 ? (
                    <TrendDownIcon className="w-4 h-4" />
                  ) : (
                    <TrendNeutralIcon className="w-4 h-4" />
                  )}
                  {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
                </span>
              </div>
            )}
          </div>
          
          {/* Progress Ring */}
          <div className={cn('relative', sizes.ring)} style={{ width: 72, height: 72 }}>
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <circle
                cx="18"
                cy="18"
                r="16"
                fill="none"
                stroke="#e5e7eb"
                strokeWidth="3"
              />
              <circle
                cx="18"
                cy="18"
                r="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={`${percentage} 100`}
                className={colors.text}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className={cn('text-sm font-bold', colors.text)}>
                {Math.round(percentage)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================
// ALERT BADGE
// =========================================================

interface PrecessionAlertBadgeProps {
  severity: AlertSeverity;
  count?: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const severityIcons: Record<AlertSeverity, string> = {
  [AlertSeverity.LOW]: 'ℹ️',
  [AlertSeverity.MEDIUM]: '⚠️',
  [AlertSeverity.HIGH]: '🔶',
  [AlertSeverity.CRITICAL]: '🚨',
};

const severityLabels: Record<AlertSeverity, string> = {
  [AlertSeverity.LOW]: 'Baja',
  [AlertSeverity.MEDIUM]: 'Media',
  [AlertSeverity.HIGH]: 'Alta',
  [AlertSeverity.CRITICAL]: 'Crítica',
};

export function PrecessionAlertBadge({
  severity,
  count,
  showLabel = false,
  size = 'md',
  className,
}: PrecessionAlertBadgeProps) {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-1.5 text-base',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full font-medium border',
        SEVERITY_COLORS[severity],
        sizeClasses[size],
        className
      )}
    >
      <span>{severityIcons[severity]}</span>
      {showLabel && <span>{severityLabels[severity]}</span>}
      {count !== undefined && count > 0 && (
        <span className="font-bold ml-1">{count}</span>
      )}
    </span>
  );
}

// =========================================================
// STATUS BADGE
// =========================================================

interface StatusBadgeProps {
  status: AlertStatus;
  className?: string;
}

const statusLabels: Record<AlertStatus, string> = {
  [AlertStatus.ACTIVE]: 'Activa',
  [AlertStatus.ACKNOWLEDGED]: 'Reconocida',
  [AlertStatus.RESOLVED]: 'Resuelta',
  [AlertStatus.EXPIRED]: 'Expirada',
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium text-white',
        STATUS_COLORS[status],
        className
      )}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-white/80 animate-pulse" />
      {statusLabels[status]}
    </span>
  );
}

// =========================================================
// ANGLE BADGE
// =========================================================

interface AngleBadgeProps {
  angle: PrecessionAngle;
  showDegrees?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

export function AngleBadge({
  angle,
  showDegrees = true,
  size = 'md',
  className,
}: AngleBadgeProps) {
  const angleInfo = PRECESSION_ANGLES.find(a => a.key === angle);
  if (!angleInfo) return null;

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded font-medium text-white',
        sizeClasses[size],
        className
      )}
      style={{ backgroundColor: angleInfo.color }}
    >
      {angleInfo.name}
      {showDegrees && <span className="opacity-75">({angleInfo.degrees}°)</span>}
    </span>
  );
}

// =========================================================
// KPI CARD
// =========================================================

interface KPICardProps {
  label: string;
  value: string | number;
  subValue?: string;
  icon?: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  className?: string;
}

export function KPICard({
  label,
  value,
  subValue,
  icon,
  trend,
  trendValue,
  className,
}: KPICardProps) {
  return (
    <div className={cn(
      'bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow',
      className
    )}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">
            {typeof value === 'number' ? value.toLocaleString() : value}
          </p>
          {subValue && (
            <p className="text-xs text-gray-400 mt-1">{subValue}</p>
          )}
        </div>
        {icon && (
          <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
            {icon}
          </div>
        )}
      </div>
      {trend && trendValue && (
        <div className="mt-3 flex items-center gap-1">
          {trend === 'up' && <TrendUpIcon className="w-4 h-4 text-green-500" />}
          {trend === 'down' && <TrendDownIcon className="w-4 h-4 text-red-500" />}
          {trend === 'neutral' && <TrendNeutralIcon className="w-4 h-4 text-gray-500" />}
          <span className={cn(
            'text-sm',
            trend === 'up' ? 'text-green-600' : 
            trend === 'down' ? 'text-red-600' : 'text-gray-500'
          )}>
            {trendValue}
          </span>
        </div>
      )}
    </div>
  );
}

// =========================================================
// ICONS
// =========================================================

function TrendUpIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
    </svg>
  );
}

function TrendDownIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1V9a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
    </svg>
  );
}

function TrendNeutralIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M4 10a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" clipRule="evenodd" />
    </svg>
  );
}

// =========================================================
// LOADING SKELETON
// =========================================================

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('animate-pulse bg-gray-200 rounded', className)} />
  );
}

export function CardSkeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('bg-white rounded-xl shadow p-6', className)}>
      <Skeleton className="h-4 w-24 mb-4" />
      <Skeleton className="h-8 w-32 mb-2" />
      <Skeleton className="h-3 w-20" />
    </div>
  );
}

export function ChartSkeleton({ className }: SkeletonProps) {
  return (
    <div className={cn('bg-white rounded-xl shadow p-6', className)}>
      <Skeleton className="h-6 w-48 mb-6" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}
