/**
 * =========================================================
 * PAE M11 - Heatmap y Gráficos Adicionales
 * =========================================================
 */

'use client';

import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
  Legend,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { cn } from '@/lib/utils';
import { PrecessionAnalysis, MLPrediction, PRECESSION_ANGLES } from '@/types/pae.types';

// =========================================================
// HEATMAP MINI (Placeholder for map integration)
// =========================================================

interface PrecessionHeatmapMiniProps {
  center: { lat: number; lng: number };
  intensity?: number;
  radius?: number;
  className?: string;
}

export function PrecessionHeatmapMini({
  center,
  intensity = 0.6,
  radius = 1000,
  className,
}: PrecessionHeatmapMiniProps) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 border border-gray-200',
        className
      )}
      style={{ minHeight: 200 }}
    >
      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `
            linear-gradient(rgba(139, 92, 246, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(139, 92, 246, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '24px 24px',
        }}
      />
      
      {/* Radial gradient representing influence zone */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div
          className="rounded-full transition-all duration-500"
          style={{
            width: '60%',
            height: '60%',
            background: `radial-gradient(circle, 
              rgba(139, 92, 246, ${intensity * 0.6}) 0%, 
              rgba(139, 92, 246, ${intensity * 0.3}) 35%, 
              rgba(139, 92, 246, ${intensity * 0.1}) 60%, 
              transparent 80%
            )`,
          }}
        />
      </div>
      
      {/* Center marker */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative">
          <div className="w-4 h-4 bg-purple-600 rounded-full border-2 border-white shadow-lg" />
          <div className="absolute -inset-2 bg-purple-400/30 rounded-full animate-ping" />
        </div>
      </div>
      
      {/* Info badges */}
      <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm">
        <span className="text-xs font-medium text-gray-700">
          Radio: {radius}m
        </span>
      </div>
      
      <div className="absolute top-3 right-3 bg-purple-100 text-purple-700 rounded-lg px-3 py-1.5 text-xs font-medium">
        🗺️ Mapa próximamente
      </div>
      
      {/* Coordinates */}
      <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm">
        <span className="text-xs font-mono text-gray-600">
          {center.lat.toFixed(4)}, {center.lng.toFixed(4)}
        </span>
      </div>
      
      {/* Intensity indicator */}
      <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm">
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-600">Intensidad:</span>
          <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-400 to-purple-600 rounded-full transition-all"
              style={{ width: `${intensity * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================
// VALUES BY ANGLE BAR CHART
// =========================================================

interface ValuesByAngleChartProps {
  analysis: PrecessionAnalysis;
  height?: number;
  orientation?: 'horizontal' | 'vertical';
  className?: string;
}

export function ValuesByAngleChart({
  analysis,
  height = 300,
  orientation = 'vertical',
  className,
}: ValuesByAngleChartProps) {
  const data = useMemo(() => {
    return [
      { name: 'Directo', value: analysis.directValueUf, color: '#3B82F6' },
      { name: 'Inducido', value: analysis.inducedValueUf, color: '#10B981' },
      { name: 'Precesión', value: analysis.precessionValueUf, color: '#8B5CF6' },
      { name: 'Sistémico', value: analysis.systemicValueUf, color: '#F59E0B' },
      { name: 'Contra', value: analysis.counterValueUf, color: '#EF4444' },
    ];
  }, [analysis]);

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toFixed(0);
  };

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout={orientation === 'horizontal' ? 'vertical' : 'horizontal'}
          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          {orientation === 'horizontal' ? (
            <>
              <XAxis type="number" tickFormatter={formatValue} />
              <YAxis type="category" dataKey="name" width={80} />
            </>
          ) : (
            <>
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatValue} />
            </>
          )}
          <Tooltip
            formatter={(value: number) => [`${value.toLocaleString()} UF`, 'Valor']}
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
            }}
          />
          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// ML PREDICTIONS CHART
// =========================================================

interface MLPredictionsChartProps {
  predictions: Record<string, MLPrediction>;
  height?: number;
  showConfidence?: boolean;
  className?: string;
}

export function MLPredictionsChart({
  predictions,
  height = 280,
  showConfidence = true,
  className,
}: MLPredictionsChartProps) {
  const data = useMemo(() => {
    return Object.entries(predictions)
      .map(([key, pred]) => ({
        horizon: `${pred.horizon}m`,
        value: pred.value * 100,
        lower: pred.lowerBound * 100,
        upper: pred.upperBound * 100,
        confidence: pred.confidence * 100,
      }))
      .sort((a, b) => parseInt(a.horizon) - parseInt(b.horizon));
  }, [predictions]);

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <defs>
            <linearGradient id="colorConfidence" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="horizon" tick={{ fill: '#6b7280', fontSize: 12 }} />
          <YAxis
            tickFormatter={(v) => `${v.toFixed(0)}%`}
            tick={{ fill: '#6b7280', fontSize: 12 }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
            }}
            formatter={(value: number, name: string) => {
              const labels: Record<string, string> = {
                value: 'Predicción',
                lower: 'Límite inferior',
                upper: 'Límite superior',
                confidence: 'Confianza',
              };
              return [`${value.toFixed(1)}%`, labels[name] || name];
            }}
          />
          {showConfidence && (
            <>
              <Area
                type="monotone"
                dataKey="upper"
                stroke="none"
                fill="#8B5CF6"
                fillOpacity={0.1}
              />
              <Area
                type="monotone"
                dataKey="lower"
                stroke="none"
                fill="white"
                fillOpacity={1}
              />
            </>
          )}
          <Line
            type="monotone"
            dataKey="value"
            stroke="#8B5CF6"
            strokeWidth={3}
            dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: '#8B5CF6', strokeWidth: 2 }}
          />
          <Legend />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// EFFECTS DISTRIBUTION PIE
// =========================================================

interface EffectsDistributionProps {
  positive: number;
  negative: number;
  neutral: number;
  size?: number;
  className?: string;
}

export function EffectsDistributionPie({
  positive,
  negative,
  neutral,
  size = 200,
  className,
}: EffectsDistributionProps) {
  const data = [
    { name: 'Positivos', value: positive, color: '#10B981' },
    { name: 'Negativos', value: negative, color: '#EF4444' },
    { name: 'Neutrales', value: neutral, color: '#6B7280' },
  ].filter(d => d.value > 0);

  const total = positive + negative + neutral;

  return (
    <div className={cn('flex items-center gap-4', className)}>
      <div style={{ width: size, height: size }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={size * 0.3}
              outerRadius={size * 0.4}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number) => [value, 'Efectos']}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      <div className="space-y-2">
        {data.map(item => (
          <div key={item.name} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: item.color }}
            />
            <span className="text-sm text-gray-600">{item.name}</span>
            <span className="text-sm font-semibold">
              {item.value} ({((item.value / total) * 100).toFixed(0)}%)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================
// COMPARISON BAR CHART
// =========================================================

interface ComparisonItem {
  copropiedadId: number;
  nombre: string;
  precessionScore: number;
  riskScore: number;
  opportunityScore: number;
  totalValueUf: number;
}

interface ComparisonBarChartProps {
  items: ComparisonItem[];
  metric: 'precessionScore' | 'riskScore' | 'opportunityScore' | 'totalValueUf';
  height?: number;
  className?: string;
}

const metricConfig = {
  precessionScore: { label: 'Precession Score', color: '#8B5CF6', format: (v: number) => v.toFixed(1) },
  riskScore: { label: 'Risk Score', color: '#EF4444', format: (v: number) => `${(v * 100).toFixed(0)}%` },
  opportunityScore: { label: 'Opportunity Score', color: '#10B981', format: (v: number) => `${(v * 100).toFixed(0)}%` },
  totalValueUf: { label: 'Valor Total (UF)', color: '#F59E0B', format: (v: number) => v.toLocaleString() },
};

export function ComparisonBarChart({
  items,
  metric,
  height = 300,
  className,
}: ComparisonBarChartProps) {
  const config = metricConfig[metric];
  
  const data = items.map(item => ({
    name: item.nombre.length > 20 ? item.nombre.slice(0, 20) + '...' : item.nombre,
    value: item[metric],
  }));

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 20, right: 30, left: 100, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis type="number" />
          <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12 }} />
          <Tooltip
            formatter={(value: number) => [config.format(value), config.label]}
          />
          <Bar dataKey="value" fill={config.color} radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// SCORE GAUGE
// =========================================================

interface ScoreGaugeProps {
  value: number;
  maxValue?: number;
  label: string;
  size?: number;
  color?: string;
  className?: string;
}

export function ScoreGauge({
  value,
  maxValue = 100,
  label,
  size = 120,
  color = '#8B5CF6',
  className,
}: ScoreGaugeProps) {
  const percentage = Math.min((value / maxValue) * 100, 100);
  const strokeWidth = size * 0.08;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference * 0.75;

  return (
    <div className={cn('relative inline-flex flex-col items-center', className)}>
      <svg
        width={size}
        height={size * 0.75}
        className="transform -rotate-90"
        style={{ overflow: 'visible' }}
      >
        {/* Background arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#e5e7eb"
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference * 0.75} ${circumference}`}
          strokeLinecap="round"
          transform={`rotate(135 ${size / 2} ${size / 2})`}
        />
        {/* Value arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference * 0.75} ${circumference}`}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          transform={`rotate(135 ${size / 2} ${size / 2})`}
          className="transition-all duration-500"
        />
      </svg>
      
      <div 
        className="absolute flex flex-col items-center justify-center"
        style={{ top: size * 0.25 }}
      >
        <span className="text-2xl font-bold" style={{ color }}>
          {value.toFixed(1)}
        </span>
        <span className="text-xs text-gray-500">{label}</span>
      </div>
    </div>
  );
}
