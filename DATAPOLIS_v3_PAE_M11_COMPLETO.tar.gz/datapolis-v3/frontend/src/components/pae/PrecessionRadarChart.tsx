/**
 * =========================================================
 * PAE M11 - Precession Radar Chart
 * =========================================================
 * 
 * Gráfico radar para visualizar efectos por ángulo precesional.
 */

'use client';

import React, { useMemo } from 'react';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts';
import { cn } from '@/lib/utils';
import { PrecessionAngle, PRECESSION_ANGLES } from '@/types/pae.types';

// =========================================================
// SINGLE RADAR CHART
// =========================================================

interface RadarData {
  direct_0: number;
  induced_45: number;
  precession_90: number;
  systemic_135: number;
  counter_180: number;
}

interface PrecessionRadarChartProps {
  data: RadarData;
  height?: number;
  showLegend?: boolean;
  fillOpacity?: number;
  className?: string;
}

export function PrecessionRadarChart({
  data,
  height = 350,
  showLegend = false,
  fillOpacity = 0.4,
  className,
}: PrecessionRadarChartProps) {
  const chartData = useMemo(() => {
    return PRECESSION_ANGLES.map(angle => ({
      angle: `${angle.name} (${angle.degrees}°)`,
      value: data[angle.key as keyof RadarData] ?? 0,
      fullMark: 100,
    }));
  }, [data]);

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="75%" data={chartData}>
          <PolarGrid stroke="#e5e7eb" />
          <PolarAngleAxis
            dataKey="angle"
            tick={{ fill: '#6b7280', fontSize: 11 }}
            tickLine={false}
          />
          <PolarRadiusAxis
            angle={90}
            domain={[0, 100]}
            tick={{ fill: '#9ca3af', fontSize: 10 }}
            tickCount={5}
          />
          <Radar
            name="Valor Precesional"
            dataKey="value"
            stroke="#8B5CF6"
            fill="#8B5CF6"
            fillOpacity={fillOpacity}
            strokeWidth={2}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
            }}
            formatter={(value: number) => [`${value.toFixed(1)}%`, 'Valor']}
          />
          {showLegend && <Legend />}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// COMPARISON RADAR CHART (Multiple series)
// =========================================================

interface ComparisonRadarData {
  copropiedadId: number;
  nombre: string;
  color: string;
  data: RadarData;
}

interface PrecessionComparisonRadarProps {
  items: ComparisonRadarData[];
  height?: number;
  showLegend?: boolean;
  className?: string;
}

export function PrecessionComparisonRadar({
  items,
  height = 400,
  showLegend = true,
  className,
}: PrecessionComparisonRadarProps) {
  const chartData = useMemo(() => {
    return PRECESSION_ANGLES.map(angle => {
      const point: Record<string, any> = {
        angle: `${angle.name} (${angle.degrees}°)`,
        fullMark: 100,
      };
      
      items.forEach(item => {
        point[item.nombre] = item.data[angle.key as keyof RadarData] ?? 0;
      });
      
      return point;
    });
  }, [items]);

  const colors = ['#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#3B82F6'];

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
          <PolarGrid stroke="#e5e7eb" />
          <PolarAngleAxis
            dataKey="angle"
            tick={{ fill: '#6b7280', fontSize: 11 }}
            tickLine={false}
          />
          <PolarRadiusAxis
            angle={90}
            domain={[0, 100]}
            tick={{ fill: '#9ca3af', fontSize: 10 }}
            tickCount={5}
          />
          {items.map((item, index) => (
            <Radar
              key={item.copropiedadId}
              name={item.nombre}
              dataKey={item.nombre}
              stroke={item.color || colors[index % colors.length]}
              fill={item.color || colors[index % colors.length]}
              fillOpacity={0.2}
              strokeWidth={2}
            />
          ))}
          <Tooltip
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
            }}
            formatter={(value: number) => [`${value.toFixed(1)}%`, '']}
          />
          {showLegend && <Legend wrapperStyle={{ paddingTop: 20 }} />}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// ANGLE DETAILS TABLE
// =========================================================

interface AngleDetailsTableProps {
  data: RadarData;
  showProgress?: boolean;
  className?: string;
}

export function AngleDetailsTable({
  data,
  showProgress = true,
  className,
}: AngleDetailsTableProps) {
  const rows = PRECESSION_ANGLES.map(angle => ({
    ...angle,
    value: data[angle.key as keyof RadarData] ?? 0,
  }));

  const getStatusColor = (value: number) => {
    if (value >= 70) return 'text-green-600';
    if (value >= 40) return 'text-amber-600';
    return 'text-red-600';
  };

  const getProgressColor = (value: number) => {
    if (value >= 70) return 'bg-green-500';
    if (value >= 40) return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <div className={cn('overflow-hidden rounded-lg border border-gray-200', className)}>
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Ángulo
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Descripción
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Horizonte
            </th>
            <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Valor
            </th>
            {showProgress && (
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                Impacto
              </th>
            )}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {rows.map(row => (
            <tr key={row.key} className="hover:bg-gray-50">
              <td className="px-4 py-3 whitespace-nowrap">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: row.color }}
                  />
                  <span className="font-medium text-gray-900">
                    {row.name}
                  </span>
                  <span className="text-gray-500 text-sm">
                    ({row.degrees}°)
                  </span>
                </div>
              </td>
              <td className="px-4 py-3 text-sm text-gray-600">
                {row.description}
              </td>
              <td className="px-4 py-3 text-sm text-gray-500">
                {row.lagMonths[0]}-{row.lagMonths[1]} meses
              </td>
              <td className={cn(
                'px-4 py-3 text-right font-semibold',
                getStatusColor(row.value)
              )}>
                {row.value.toFixed(1)}%
              </td>
              {showProgress && (
                <td className="px-4 py-3">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={cn('h-2 rounded-full transition-all', getProgressColor(row.value))}
                      style={{ width: `${Math.min(row.value, 100)}%` }}
                    />
                  </div>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// =========================================================
// MINI RADAR (for cards/previews)
// =========================================================

interface MiniRadarProps {
  data: RadarData;
  size?: number;
  className?: string;
}

export function MiniRadar({ data, size = 120, className }: MiniRadarProps) {
  const chartData = useMemo(() => {
    return PRECESSION_ANGLES.map(angle => ({
      angle: angle.name,
      value: data[angle.key as keyof RadarData] ?? 0,
    }));
  }, [data]);

  return (
    <div className={cn('', className)} style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
          <PolarGrid stroke="#e5e7eb" />
          <Radar
            dataKey="value"
            stroke="#8B5CF6"
            fill="#8B5CF6"
            fillOpacity={0.4}
            strokeWidth={2}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
