/**
 * =========================================================
 * PAE M11 - Precession Timeline
 * =========================================================
 * 
 * Timeline para visualizar efectos ordenados por horizonte temporal.
 */

'use client';

import React, { useMemo } from 'react';
import { cn } from '@/lib/utils';
import { PrecessionAngle, PrecessionEffect, PRECESSION_ANGLES } from '@/types/pae.types';
import { AngleBadge } from './PrecessionCards';

// =========================================================
// TIMELINE ITEM
// =========================================================

interface TimelineItemProps {
  effect: PrecessionEffect;
  isLast?: boolean;
}

function TimelineItem({ effect, isLast = false }: TimelineItemProps) {
  const angleInfo = PRECESSION_ANGLES.find(a => a.key === effect.angle);
  
  const impactColor = {
    positive: 'text-green-600',
    negative: 'text-red-600',
    neutral: 'text-gray-600',
  };

  const impactBg = {
    positive: 'bg-green-50 border-green-200',
    negative: 'bg-red-50 border-red-200',
    neutral: 'bg-gray-50 border-gray-200',
  };

  const formatValue = (value: number) => {
    if (Math.abs(value) >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (Math.abs(value) >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toFixed(0);
  };

  return (
    <div className="relative flex gap-4 pb-6">
      {/* Connecting line */}
      {!isLast && (
        <div 
          className="absolute left-[18px] top-10 bottom-0 w-0.5"
          style={{ backgroundColor: angleInfo?.color || '#e5e7eb' }}
        />
      )}
      
      {/* Timeline dot */}
      <div className="relative z-10 flex flex-col items-center">
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md"
          style={{ backgroundColor: angleInfo?.color || '#8B5CF6' }}
        >
          {effect.temporalLag}m
        </div>
      </div>
      
      {/* Content card */}
      <div className={cn(
        'flex-1 rounded-lg border p-4 transition-all hover:shadow-md',
        impactBg[effect.impact]
      )}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <AngleBadge angle={effect.angle} size="sm" />
              <span className="text-xs text-gray-500">
                Probabilidad: {(effect.probability * 100).toFixed(0)}%
              </span>
            </div>
            
            <h4 className="font-medium text-gray-900 mb-1">
              {effect.nodeFrom} → {effect.nodeTo}
            </h4>
            
            <p className="text-sm text-gray-600">
              {effect.description}
            </p>
          </div>
          
          <div className={cn('text-right', impactColor[effect.impact])}>
            <div className="text-lg font-bold">
              {effect.impact === 'positive' ? '+' : effect.impact === 'negative' ? '-' : ''}
              {formatValue(Math.abs(effect.valueUf))} UF
            </div>
            <div className="text-xs text-gray-500">
              Peso: {effect.weight.toFixed(2)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================
// MAIN TIMELINE
// =========================================================

interface PrecessionTimelineProps {
  effects: PrecessionEffect[];
  maxItems?: number;
  sortBy?: 'temporal' | 'value' | 'probability';
  filterAngle?: PrecessionAngle;
  className?: string;
}

export function PrecessionTimeline({
  effects,
  maxItems = 10,
  sortBy = 'temporal',
  filterAngle,
  className,
}: PrecessionTimelineProps) {
  const sortedEffects = useMemo(() => {
    let filtered = filterAngle 
      ? effects.filter(e => e.angle === filterAngle)
      : effects;
    
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'value':
          return Math.abs(b.valueUf) - Math.abs(a.valueUf);
        case 'probability':
          return b.probability - a.probability;
        case 'temporal':
        default:
          return a.temporalLag - b.temporalLag;
      }
    });
    
    return sorted.slice(0, maxItems);
  }, [effects, sortBy, filterAngle, maxItems]);

  if (sortedEffects.length === 0) {
    return (
      <div className={cn('text-center py-8 text-gray-500', className)}>
        <p>No hay efectos para mostrar</p>
      </div>
    );
  }

  return (
    <div className={cn('', className)}>
      {sortedEffects.map((effect, index) => (
        <TimelineItem
          key={effect.id}
          effect={effect}
          isLast={index === sortedEffects.length - 1}
        />
      ))}
      
      {effects.length > maxItems && (
        <div className="text-center py-4">
          <span className="text-sm text-gray-500">
            Mostrando {maxItems} de {effects.length} efectos
          </span>
        </div>
      )}
    </div>
  );
}

// =========================================================
// TIMELINE HEADER WITH FILTERS
// =========================================================

interface TimelineHeaderProps {
  totalEffects: number;
  sortBy: 'temporal' | 'value' | 'probability';
  onSortChange: (sort: 'temporal' | 'value' | 'probability') => void;
  filterAngle?: PrecessionAngle;
  onFilterChange: (angle?: PrecessionAngle) => void;
}

export function TimelineHeader({
  totalEffects,
  sortBy,
  onSortChange,
  filterAngle,
  onFilterChange,
}: TimelineHeaderProps) {
  const sortOptions = [
    { value: 'temporal', label: 'Por horizonte' },
    { value: 'value', label: 'Por valor' },
    { value: 'probability', label: 'Por probabilidad' },
  ];

  return (
    <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-500">
          {totalEffects} efectos detectados
        </span>
      </div>
      
      <div className="flex items-center gap-4">
        {/* Sort dropdown */}
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value as any)}
          className="text-sm border border-gray-300 rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          {sortOptions.map(opt => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        
        {/* Angle filter */}
        <select
          value={filterAngle || ''}
          onChange={(e) => onFilterChange(e.target.value as PrecessionAngle || undefined)}
          className="text-sm border border-gray-300 rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          <option value="">Todos los ángulos</option>
          {PRECESSION_ANGLES.map(angle => (
            <option key={angle.key} value={angle.key}>
              {angle.name} ({angle.degrees}°)
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

// =========================================================
// GROUPED TIMELINE (by angle)
// =========================================================

interface GroupedTimelineProps {
  effects: PrecessionEffect[];
  className?: string;
}

export function GroupedTimeline({ effects, className }: GroupedTimelineProps) {
  const grouped = useMemo(() => {
    const groups: Record<PrecessionAngle, PrecessionEffect[]> = {
      [PrecessionAngle.DIRECT_0]: [],
      [PrecessionAngle.INDUCED_45]: [],
      [PrecessionAngle.PRECESSION_90]: [],
      [PrecessionAngle.SYSTEMIC_135]: [],
      [PrecessionAngle.COUNTER_180]: [],
    };
    
    effects.forEach(effect => {
      groups[effect.angle].push(effect);
    });
    
    return groups;
  }, [effects]);

  return (
    <div className={cn('space-y-8', className)}>
      {PRECESSION_ANGLES.map(angle => {
        const angleEffects = grouped[angle.key];
        if (angleEffects.length === 0) return null;
        
        return (
          <div key={angle.key}>
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: angle.color }}
              />
              <h3 className="font-semibold text-gray-900">
                {angle.name} ({angle.degrees}°)
              </h3>
              <span className="text-sm text-gray-500">
                {angleEffects.length} efectos
              </span>
            </div>
            
            <div className="ml-6 border-l-2 pl-6" style={{ borderColor: angle.color }}>
              {angleEffects
                .sort((a, b) => a.temporalLag - b.temporalLag)
                .slice(0, 3)
                .map((effect, index) => (
                  <TimelineItem
                    key={effect.id}
                    effect={effect}
                    isLast={index === Math.min(angleEffects.length, 3) - 1}
                  />
                ))}
              
              {angleEffects.length > 3 && (
                <div className="text-sm text-gray-500 py-2">
                  +{angleEffects.length - 3} efectos más
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// =========================================================
// MINI TIMELINE (for cards)
// =========================================================

interface MiniTimelineProps {
  effects: PrecessionEffect[];
  maxItems?: number;
  className?: string;
}

export function MiniTimeline({ effects, maxItems = 3, className }: MiniTimelineProps) {
  const topEffects = effects
    .sort((a, b) => Math.abs(b.valueUf) - Math.abs(a.valueUf))
    .slice(0, maxItems);

  return (
    <div className={cn('space-y-2', className)}>
      {topEffects.map(effect => {
        const angleInfo = PRECESSION_ANGLES.find(a => a.key === effect.angle);
        
        return (
          <div key={effect.id} className="flex items-center gap-2 text-sm">
            <div
              className="w-2 h-2 rounded-full shrink-0"
              style={{ backgroundColor: angleInfo?.color }}
            />
            <span className="text-gray-600 truncate flex-1">
              {effect.description.slice(0, 40)}...
            </span>
            <span className={cn(
              'font-medium shrink-0',
              effect.impact === 'positive' ? 'text-green-600' :
              effect.impact === 'negative' ? 'text-red-600' : 'text-gray-600'
            )}>
              {effect.temporalLag}m
            </span>
          </div>
        );
      })}
    </div>
  );
}
