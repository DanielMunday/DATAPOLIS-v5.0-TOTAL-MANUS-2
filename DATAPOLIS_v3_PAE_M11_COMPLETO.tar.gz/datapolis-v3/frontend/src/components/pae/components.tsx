/**
 * =========================================================
 * PAE M11 - Componentes Reutilizables
 * =========================================================
 */

'use client';

import React, { useMemo } from 'react';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  Area,
  AreaChart,
} from 'recharts';
import { cn } from '@/lib/utils';
import { 
  PrecessionAngle, 
  AlertSeverity, 
  PrecessionAlert,
  TimelineItem,
  PrecessionAnalysis,
} from '@/types/pae.types';

// =========================================================
// CONSTANTS
// =========================================================

export const ANGLE_CONFIG: Record<PrecessionAngle, {
  label: string;
  degrees: number;
  color: string;
  bgColor: string;
  description: string;
}> = {
  [PrecessionAngle.DIRECT_0]: {
    label: 'Directo',
    degrees: 0,
    color: '#3B82F6',
    bgColor: 'bg-blue-500',
    description: 'Efecto lineal causa-efecto',
  },
  [PrecessionAngle.INDUCED_45]: {
    label: 'Inducido',
    degrees: 45,
    color: '#8B5CF6',
    bgColor: 'bg-violet-500',
    description: 'Efectos secundarios',
  },
  [PrecessionAngle.PRECESSION_90]: {
    label: 'Precesión',
    degrees: 90,
    color: '#10B981',
    bgColor: 'bg-emerald-500',
    description: 'Efecto perpendicular (Fuller)',
  },
  [PrecessionAngle.SYSTEMIC_135]: {
    label: 'Sistémico',
    degrees: 135,
    color: '#F59E0B',
    bgColor: 'bg-amber-500',
    description: 'Efectos de segundo orden',
  },
  [PrecessionAngle.COUNTER_180]: {
    label: 'Contra',
    degrees: 180,
    color: '#EF4444',
    bgColor: 'bg-red-500',
    description: 'Retroalimentación inversa',
  },
};

export const SEVERITY_CONFIG: Record<AlertSeverity, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
}> = {
  [AlertSeverity.LOW]: {
    label: 'Baja',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    icon: 'ℹ️',
  },
  [AlertSeverity.MEDIUM]: {
    label: 'Media',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-200',
    icon: '⚠️',
  },
  [AlertSeverity.HIGH]: {
    label: 'Alta',
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200',
    icon: '🔶',
  },
  [AlertSeverity.CRITICAL]: {
    label: 'Crítica',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    icon: '🚨',
  },
};

// =========================================================
// PRECESSION SCORE CARD
// =========================================================

interface PrecessionScoreCardProps {
  title: string;
  value: number;
  maxValue?: number;
  subtitle?: string;
  trend?: 'up' | 'down' | 'stable';
  trendValue?: number;
  color?: 'blue' | 'green' | 'red' | 'amber' | 'purple';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function PrecessionScoreCard({
  title,
  value,
  maxValue = 100,
  subtitle,
  trend,
  trendValue,
  color = 'blue',
  size = 'md',
  className,
}: PrecessionScoreCardProps) {
  const percentage = Math.min((value / maxValue) * 100, 100);
  
  const colorConfig = {
    blue: {
      bg: 'from-blue-500 to-blue-600',
      light: 'bg-blue-100',
      text: 'text-blue-600',
    },
    green: {
      bg: 'from-emerald-500 to-emerald-600',
      light: 'bg-emerald-100',
      text: 'text-emerald-600',
    },
    red: {
      bg: 'from-red-500 to-red-600',
      light: 'bg-red-100',
      text: 'text-red-600',
    },
    amber: {
      bg: 'from-amber-500 to-amber-600',
      light: 'bg-amber-100',
      text: 'text-amber-600',
    },
    purple: {
      bg: 'from-purple-500 to-purple-600',
      light: 'bg-purple-100',
      text: 'text-purple-600',
    },
  };

  const sizeConfig = {
    sm: { card: 'p-4', title: 'text-sm', value: 'text-2xl', ring: 'w-16 h-16' },
    md: { card: 'p-6', title: 'text-base', value: 'text-3xl', ring: 'w-20 h-20' },
    lg: { card: 'p-8', title: 'text-lg', value: 'text-4xl', ring: 'w-24 h-24' },
  };

  const colors = colorConfig[color];
  const sizes = sizeConfig[size];

  return (
    <div className={cn(
      'bg-white rounded-xl shadow-lg overflow-hidden',
      className
    )}>
      <div className={cn('bg-gradient-to-r', colors.bg, 'p-4')}>
        <h3 className="text-white font-semibold flex items-center gap-2">
          {title}
        </h3>
      </div>
      
      <div className={cn(sizes.card)}>
        <div className="flex items-center justify-between">
          <div>
            <div className={cn(sizes.value, 'font-bold', colors.text)}>
              {typeof value === 'number' ? value.toFixed(1) : value}
            </div>
            {subtitle && (
              <p className="text-gray-500 text-sm mt-1">{subtitle}</p>
            )}
            {trend && trendValue !== undefined && (
              <div className="flex items-center gap-1 mt-2">
                <span className={cn(
                  'text-sm font-medium',
                  trend === 'up' ? 'text-green-600' : 
                  trend === 'down' ? 'text-red-600' : 'text-gray-600'
                )}>
                  {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}
                  {trendValue > 0 ? '+' : ''}{trendValue.toFixed(1)}%
                </span>
              </div>
            )}
          </div>
          
          {/* Circular Progress */}
          <div className={cn('relative', sizes.ring)}>
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="45%"
                fill="none"
                strokeWidth="8"
                className="stroke-gray-200"
              />
              <circle
                cx="50%"
                cy="50%"
                r="45%"
                fill="none"
                strokeWidth="8"
                strokeLinecap="round"
                className={cn('transition-all duration-500', `stroke-current`, colors.text)}
                style={{
                  strokeDasharray: `${percentage * 2.83} 283`,
                }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className={cn('font-bold', colors.text)}>
                {Math.round(percentage)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================================================
// PRECESSION RADAR CHART
// =========================================================

interface RadarChartData {
  angle: string;
  value: number;
  fullMark: number;
}

interface PrecessionRadarChartProps {
  data: {
    direct_0: number;
    induced_45: number;
    precession_90: number;
    systemic_135: number;
    counter_180: number;
  };
  height?: number;
  showLegend?: boolean;
  className?: string;
}

export function PrecessionRadarChart({
  data,
  height = 300,
  showLegend = true,
  className,
}: PrecessionRadarChartProps) {
  const chartData: RadarChartData[] = useMemo(() => [
    { angle: 'Directo (0°)', value: data.direct_0, fullMark: 100 },
    { angle: 'Inducido (45°)', value: data.induced_45, fullMark: 100 },
    { angle: 'Precesión (90°)', value: data.precession_90, fullMark: 100 },
    { angle: 'Sistémico (135°)', value: data.systemic_135, fullMark: 100 },
    { angle: 'Contra (180°)', value: data.counter_180, fullMark: 100 },
  ], [data]);

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={chartData} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
          <PolarGrid 
            gridType="polygon" 
            stroke="#e5e7eb"
          />
          <PolarAngleAxis 
            dataKey="angle" 
            tick={{ fill: '#6b7280', fontSize: 12 }}
          />
          <PolarRadiusAxis 
            angle={90} 
            domain={[0, 100]}
            tick={{ fill: '#9ca3af', fontSize: 10 }}
          />
          <Radar
            name="Valor Precesional"
            dataKey="value"
            stroke="#8B5CF6"
            fill="#8B5CF6"
            fillOpacity={0.5}
            strokeWidth={2}
          />
          <Tooltip 
            formatter={(value: number) => [`${value.toFixed(1)}%`, 'Valor']}
            contentStyle={{ 
              backgroundColor: 'white', 
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
            }}
          />
          {showLegend && <Legend />}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// PRECESSION TIMELINE
// =========================================================

interface PrecessionTimelineProps {
  items: TimelineItem[];
  className?: string;
}

export function PrecessionTimeline({ items, className }: PrecessionTimelineProps) {
  const sortedItems = useMemo(() => 
    [...items].sort((a, b) => a.horizon_months - b.horizon_months),
    [items]
  );

  const formatValue = (value: number) => {
    if (Math.abs(value) >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (Math.abs(value) >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toFixed(0);
  };

  return (
    <div className={cn('space-y-4', className)}>
      {sortedItems.map((item, index) => {
        const angleConfig = ANGLE_CONFIG[item.angle];
        
        return (
          <div
            key={item.id}
            className="relative flex gap-4 pb-4"
          >
            {/* Timeline line */}
            {index < sortedItems.length - 1 && (
              <div className="absolute left-[15px] top-8 bottom-0 w-0.5 bg-gray-200" />
            )}
            
            {/* Dot */}
            <div 
              className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0 z-10',
                angleConfig.bgColor
              )}
            >
              {item.horizon_months}m
            </div>
            
            {/* Content */}
            <div className="flex-1 bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-semibold text-gray-800">
                    {item.title}
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">
                    {item.description}
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    <span 
                      className="text-xs px-2 py-0.5 rounded-full text-white"
                      style={{ backgroundColor: angleConfig.color }}
                    >
                      {angleConfig.label}
                    </span>
                    <span className="text-xs text-gray-500">
                      {item.date}
                    </span>
                  </div>
                </div>
                
                <div className={cn(
                  'text-right',
                  item.type === 'positive' ? 'text-green-600' :
                  item.type === 'negative' ? 'text-red-600' : 'text-gray-600'
                )}>
                  <div className="text-lg font-bold">
                    {item.type === 'positive' ? '+' : item.type === 'negative' ? '-' : ''}
                    {formatValue(Math.abs(item.value_uf))} UF
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// =========================================================
// PRECESSION ALERT BADGE
// =========================================================

interface PrecessionAlertBadgeProps {
  severity: AlertSeverity;
  count?: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function PrecessionAlertBadge({
  severity,
  count,
  showLabel = false,
  size = 'md',
  className,
}: PrecessionAlertBadgeProps) {
  const config = SEVERITY_CONFIG[severity];
  
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-1.5 text-base',
  };

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-medium',
        config.bgColor,
        config.color,
        sizeClasses[size],
        className
      )}
    >
      <span>{config.icon}</span>
      {showLabel && <span>{config.label}</span>}
      {count !== undefined && (
        <span className="font-bold">{count}</span>
      )}
    </span>
  );
}

// =========================================================
// PRECESSION ALERT CARD
// =========================================================

interface PrecessionAlertCardProps {
  alert: PrecessionAlert;
  onAcknowledge?: (id: string) => void;
  onResolve?: (id: string) => void;
  onViewDetails?: (id: string) => void;
  className?: string;
}

export function PrecessionAlertCard({
  alert,
  onAcknowledge,
  onResolve,
  onViewDetails,
  className,
}: PrecessionAlertCardProps) {
  const severityConfig = SEVERITY_CONFIG[alert.severity];
  const angleConfig = ANGLE_CONFIG[alert.precession_angle];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-CL', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div
      className={cn(
        'rounded-lg border-l-4 p-4 shadow-sm',
        severityConfig.bgColor,
        severityConfig.borderColor,
        className
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <PrecessionAlertBadge severity={alert.severity} showLabel />
            <span 
              className="text-xs px-2 py-0.5 rounded text-white"
              style={{ backgroundColor: angleConfig.color }}
            >
              {angleConfig.label}
            </span>
          </div>
          
          <h4 className="font-semibold text-gray-800 mb-1">
            {alert.title}
          </h4>
          
          <p className="text-sm text-gray-600 mb-2">
            {alert.description}
          </p>
          
          <div className="flex flex-wrap gap-4 text-xs text-gray-500">
            <span>
              📍 {alert.copropiedad?.nombre || `ID: ${alert.copropiedad_id}`}
            </span>
            <span>
              📅 {formatDate(alert.created_at)}
            </span>
            {alert.potential_impact_uf > 0 && (
              <span>
                💰 Impacto: {alert.potential_impact_uf.toLocaleString()} UF
              </span>
            )}
            <span>
              ⏱️ Horizonte: {alert.expected_months} meses
            </span>
          </div>
          
          {alert.recommendation && (
            <div className="mt-3 p-2 bg-white/50 rounded text-sm">
              <strong>Recomendación:</strong> {alert.recommendation}
            </div>
          )}
        </div>
        
        <div className="flex flex-col gap-2">
          {onViewDetails && (
            <button
              onClick={() => onViewDetails(alert.id)}
              className="px-3 py-1.5 text-xs bg-white border border-gray-300 rounded hover:bg-gray-50 transition-colors"
            >
              Ver Detalles
            </button>
          )}
          {alert.status === 'active' && onAcknowledge && (
            <button
              onClick={() => onAcknowledge(alert.id)}
              className="px-3 py-1.5 text-xs bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
            >
              Reconocer
            </button>
          )}
          {alert.status === 'acknowledged' && onResolve && (
            <button
              onClick={() => onResolve(alert.id)}
              className="px-3 py-1.5 text-xs bg-green-500 text-white rounded hover:bg-green-600 transition-colors"
            >
              Resolver
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// =========================================================
// PRECESSION HEATMAP MINI (Placeholder)
// =========================================================

interface PrecessionHeatmapMiniProps {
  center: { lat: number; lng: number };
  intensity?: number;
  className?: string;
}

export function PrecessionHeatmapMini({
  center,
  intensity = 0.5,
  className,
}: PrecessionHeatmapMiniProps) {
  // Placeholder component - will be replaced with actual map integration
  return (
    <div 
      className={cn(
        'relative overflow-hidden rounded-lg bg-gradient-to-br from-gray-100 to-gray-200',
        className
      )}
      style={{ minHeight: 200 }}
    >
      {/* Grid pattern */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'linear-gradient(#9ca3af 1px, transparent 1px), linear-gradient(90deg, #9ca3af 1px, transparent 1px)',
          backgroundSize: '20px 20px',
        }}
      />
      
      {/* Center indicator */}
      <div 
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
      >
        <div 
          className="w-32 h-32 rounded-full opacity-40"
          style={{
            background: `radial-gradient(circle, 
              rgba(139, 92, 246, ${intensity}) 0%, 
              rgba(139, 92, 246, ${intensity * 0.5}) 40%, 
              transparent 70%
            )`,
          }}
        />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="w-3 h-3 bg-purple-600 rounded-full border-2 border-white shadow-lg" />
        </div>
      </div>
      
      {/* Coordinates label */}
      <div className="absolute bottom-2 left-2 bg-white/80 px-2 py-1 rounded text-xs font-mono">
        {center.lat.toFixed(4)}, {center.lng.toFixed(4)}
      </div>
      
      {/* Coming soon badge */}
      <div className="absolute top-2 right-2 bg-purple-100 text-purple-600 px-2 py-1 rounded text-xs font-medium">
        🗺️ Mapa interactivo próximamente
      </div>
    </div>
  );
}

// =========================================================
// PRECESSION VALUES CHART
// =========================================================

interface PrecessionValuesChartProps {
  analysis: PrecessionAnalysis;
  type?: 'bar' | 'area';
  height?: number;
  className?: string;
}

export function PrecessionValuesChart({
  analysis,
  type = 'bar',
  height = 300,
  className,
}: PrecessionValuesChartProps) {
  const data = useMemo(() => [
    { 
      name: 'Directo', 
      value: analysis.direct_value_uf,
      color: ANGLE_CONFIG[PrecessionAngle.DIRECT_0].color,
    },
    { 
      name: 'Inducido', 
      value: analysis.induced_value_uf,
      color: ANGLE_CONFIG[PrecessionAngle.INDUCED_45].color,
    },
    { 
      name: 'Precesión', 
      value: analysis.precession_value_uf,
      color: ANGLE_CONFIG[PrecessionAngle.PRECESSION_90].color,
    },
    { 
      name: 'Sistémico', 
      value: analysis.systemic_value_uf,
      color: ANGLE_CONFIG[PrecessionAngle.SYSTEMIC_135].color,
    },
    { 
      name: 'Contra', 
      value: analysis.counter_value_uf,
      color: ANGLE_CONFIG[PrecessionAngle.COUNTER_180].color,
    },
  ], [analysis]);

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        {type === 'bar' ? (
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 12 }} />
            <YAxis 
              tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
              tick={{ fill: '#6b7280', fontSize: 12 }}
            />
            <Tooltip 
              formatter={(value: number) => [`${value.toLocaleString()} UF`, 'Valor']}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
              }}
            />
            <Bar 
              dataKey="value" 
              radius={[4, 4, 0, 0]}
              fill="#8B5CF6"
            >
              {data.map((entry, index) => (
                <rect key={`bar-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        ) : (
          <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 12 }} />
            <YAxis 
              tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
              tick={{ fill: '#6b7280', fontSize: 12 }}
            />
            <Tooltip 
              formatter={(value: number) => [`${value.toLocaleString()} UF`, 'Valor']}
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke="#8B5CF6"
              fill="url(#colorValue)"
              strokeWidth={2}
            />
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
              </linearGradient>
            </defs>
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// ML PREDICTIONS CHART
// =========================================================

interface MLPredictionsChartProps {
  predictions: Record<string, number>;
  confidenceIntervals?: Record<string, [number, number]>;
  height?: number;
  className?: string;
}

export function MLPredictionsChart({
  predictions,
  confidenceIntervals,
  height = 250,
  className,
}: MLPredictionsChartProps) {
  const data = useMemo(() => {
    return Object.entries(predictions).map(([horizon, value]) => {
      const interval = confidenceIntervals?.[horizon];
      return {
        horizon,
        value: value * 100,
        lower: interval ? interval[0] * 100 : undefined,
        upper: interval ? interval[1] * 100 : undefined,
      };
    });
  }, [predictions, confidenceIntervals]);

  return (
    <div className={cn('w-full', className)} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="horizon" 
            tick={{ fill: '#6b7280', fontSize: 12 }}
          />
          <YAxis 
            tickFormatter={(value) => `${value.toFixed(0)}%`}
            tick={{ fill: '#6b7280', fontSize: 12 }}
          />
          <Tooltip 
            formatter={(value: number) => [`${value.toFixed(1)}%`, 'Predicción']}
            contentStyle={{ 
              backgroundColor: 'white', 
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
            }}
          />
          {confidenceIntervals && (
            <Area
              type="monotone"
              dataKey="upper"
              stroke="none"
              fill="#8B5CF6"
              fillOpacity={0.1}
            />
          )}
          <Line
            type="monotone"
            dataKey="value"
            stroke="#8B5CF6"
            strokeWidth={3}
            dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: '#8B5CF6', strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// =========================================================
// LOADING SKELETON
// =========================================================

interface PrecessionSkeletonProps {
  type?: 'card' | 'chart' | 'list';
  className?: string;
}

export function PrecessionSkeleton({ type = 'card', className }: PrecessionSkeletonProps) {
  if (type === 'chart') {
    return (
      <div className={cn('animate-pulse', className)}>
        <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
        <div className="h-64 bg-gray-200 rounded"></div>
      </div>
    );
  }

  if (type === 'list') {
    return (
      <div className={cn('space-y-4', className)}>
        {[1, 2, 3].map((i) => (
          <div key={i} className="animate-pulse flex gap-4">
            <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
            <div className="flex-1">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className={cn('animate-pulse bg-white rounded-xl shadow-lg p-6', className)}>
      <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
      <div className="h-12 bg-gray-200 rounded w-1/2 mb-2"></div>
      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
    </div>
  );
}

// =========================================================
// EXPORTS
// =========================================================

export {
  ANGLE_CONFIG,
  SEVERITY_CONFIG,
};
