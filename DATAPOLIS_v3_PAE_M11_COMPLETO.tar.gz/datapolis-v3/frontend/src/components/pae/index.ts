/**
 * =========================================================
 * PAE M11 - Componentes Index
 * =========================================================
 * 
 * Exporta todos los componentes del módulo PAE.
 */

// Core Components
export {
  PrecessionScoreCard,
  PrecessionRadarChart,
  PrecessionTimeline,
  PrecessionAlertBadge,
  PrecessionAlertCard,
  PrecessionValuesChart,
  MLPredictionsChart,
  PrecessionHeatmapMini,
  PrecessionSkeleton,
  ANGLE_CONFIG,
  SEVERITY_CONFIG,
} from './components';

// Re-export types
export type {
  PrecessionAngle,
  AlertSeverity,
  AlertStatus,
  AlertType,
  PrecessionAnalysis,
  PrecessionAlert,
  PrecessionEffect,
  MLPredictions,
  AnalysisParameters,
  Copropiedad,
  CopropiedadMetrics,
  DashboardData,
  SystemStats,
  TimelineItem,
  InvestorReport,
} from '@/types/pae.types';

// Re-export service
export { paeApi, default as paeService } from '@/services/pae.service';

// Re-export utils
export {
  formatNumber,
  formatPercent,
  formatUF,
  formatCLP,
  formatDate,
  formatDateTime,
  formatRelativeTime,
  getScoreColor,
  getScoreBgColor,
  getTrendColor,
  getTrendIcon,
  ANGLE_LABELS,
  ANGLE_COLORS,
  ANGLE_DESCRIPTIONS,
  SEVERITY_LABELS,
  SEVERITY_COLORS,
  SEVERITY_ICONS,
  STATUS_LABELS,
  STATUS_COLORS,
  ALERT_TYPE_LABELS,
} from '@/lib/pae-utils';
