/**
 * =========================================================
 * PAE M11 - Utilidades
 * =========================================================
 */

import { 
  PrecessionAngle, 
  AlertSeverity, 
  AlertStatus,
  AlertType,
} from '@/types/pae.types';

// =========================================================
// FORMATTERS
// =========================================================

/**
 * Formatea un número con separadores de miles
 */
export function formatNumber(value: number | null | undefined, decimals = 0): string {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('es-CL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

/**
 * Formatea un valor como porcentaje
 */
export function formatPercent(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined) return 'N/A';
  return `${(value * 100).toFixed(decimals)}%`;
}

/**
 * Formatea un valor en UF
 */
export function formatUF(value: number | null | undefined): string {
  if (value === null || value === undefined) return 'N/A';
  return `${formatNumber(value)} UF`;
}

/**
 * Formatea un valor en CLP
 */
export function formatCLP(value: number | null | undefined): string {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

/**
 * Formatea una fecha
 */
export function formatDate(
  date: string | Date | null | undefined,
  options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  }
): string {
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('es-CL', options);
}

/**
 * Formatea una fecha con hora
 */
export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return 'N/A';
  return new Date(date).toLocaleString('es-CL', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Formatea tiempo relativo
 */
export function formatRelativeTime(date: string | Date): string {
  const now = new Date();
  const past = new Date(date);
  const diffMs = now.getTime() - past.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffDays > 30) return formatDate(date);
  if (diffDays > 0) return `hace ${diffDays} día${diffDays > 1 ? 's' : ''}`;
  if (diffHours > 0) return `hace ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
  if (diffMins > 0) return `hace ${diffMins} minuto${diffMins > 1 ? 's' : ''}`;
  return 'hace un momento';
}

// =========================================================
// COLORS & STYLING
// =========================================================

/**
 * Obtiene el color para un score
 */
export function getScoreColor(score: number, maxScore = 100): string {
  const percentage = (score / maxScore) * 100;
  if (percentage >= 80) return 'text-green-600';
  if (percentage >= 60) return 'text-yellow-600';
  if (percentage >= 40) return 'text-orange-600';
  return 'text-red-600';
}

/**
 * Obtiene el color de fondo para un score
 */
export function getScoreBgColor(score: number, maxScore = 100): string {
  const percentage = (score / maxScore) * 100;
  if (percentage >= 80) return 'bg-green-50';
  if (percentage >= 60) return 'bg-yellow-50';
  if (percentage >= 40) return 'bg-orange-50';
  return 'bg-red-50';
}

/**
 * Obtiene el color para una tendencia
 */
export function getTrendColor(trend: number): string {
  if (trend > 5) return 'text-red-600';
  if (trend > 0) return 'text-orange-600';
  if (trend < -5) return 'text-green-600';
  if (trend < 0) return 'text-blue-600';
  return 'text-gray-600';
}

/**
 * Obtiene el icono para una tendencia
 */
export function getTrendIcon(direction: string | number): string {
  if (typeof direction === 'number') {
    if (direction > 0) return '↑';
    if (direction < 0) return '↓';
    return '→';
  }
  if (direction === 'creciente') return '↑';
  if (direction === 'decreciente') return '↓';
  return '→';
}

// =========================================================
// ANGLE HELPERS
// =========================================================

export const ANGLE_LABELS: Record<PrecessionAngle, string> = {
  [PrecessionAngle.DIRECT_0]: 'Directo (0°)',
  [PrecessionAngle.INDUCED_45]: 'Inducido (45°)',
  [PrecessionAngle.PRECESSION_90]: 'Precesión (90°)',
  [PrecessionAngle.SYSTEMIC_135]: 'Sistémico (135°)',
  [PrecessionAngle.COUNTER_180]: 'Contra (180°)',
};

export const ANGLE_COLORS: Record<PrecessionAngle, string> = {
  [PrecessionAngle.DIRECT_0]: '#3B82F6',
  [PrecessionAngle.INDUCED_45]: '#8B5CF6',
  [PrecessionAngle.PRECESSION_90]: '#10B981',
  [PrecessionAngle.SYSTEMIC_135]: '#F59E0B',
  [PrecessionAngle.COUNTER_180]: '#EF4444',
};

export const ANGLE_DESCRIPTIONS: Record<PrecessionAngle, string> = {
  [PrecessionAngle.DIRECT_0]: 'Efecto lineal causa-efecto inmediato',
  [PrecessionAngle.INDUCED_45]: 'Efectos secundarios correlacionados',
  [PrecessionAngle.PRECESSION_90]: 'Efecto perpendicular (core de Fuller)',
  [PrecessionAngle.SYSTEMIC_135]: 'Efectos de segundo orden en el sistema',
  [PrecessionAngle.COUNTER_180]: 'Efectos inversos y de retroalimentación',
};

// =========================================================
// SEVERITY HELPERS
// =========================================================

export const SEVERITY_LABELS: Record<AlertSeverity, string> = {
  [AlertSeverity.LOW]: 'Baja',
  [AlertSeverity.MEDIUM]: 'Media',
  [AlertSeverity.HIGH]: 'Alta',
  [AlertSeverity.CRITICAL]: 'Crítica',
};

export const SEVERITY_COLORS: Record<AlertSeverity, { text: string; bg: string; border: string }> = {
  [AlertSeverity.LOW]: { text: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
  [AlertSeverity.MEDIUM]: { text: 'text-yellow-600', bg: 'bg-yellow-50', border: 'border-yellow-200' },
  [AlertSeverity.HIGH]: { text: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200' },
  [AlertSeverity.CRITICAL]: { text: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
};

export const SEVERITY_ICONS: Record<AlertSeverity, string> = {
  [AlertSeverity.LOW]: 'ℹ️',
  [AlertSeverity.MEDIUM]: '⚠️',
  [AlertSeverity.HIGH]: '🔶',
  [AlertSeverity.CRITICAL]: '🚨',
};

// =========================================================
// STATUS HELPERS
// =========================================================

export const STATUS_LABELS: Record<AlertStatus, string> = {
  [AlertStatus.ACTIVE]: 'Activa',
  [AlertStatus.ACKNOWLEDGED]: 'Reconocida',
  [AlertStatus.RESOLVED]: 'Resuelta',
  [AlertStatus.EXPIRED]: 'Expirada',
};

export const STATUS_COLORS: Record<AlertStatus, { text: string; bg: string }> = {
  [AlertStatus.ACTIVE]: { text: 'text-red-700', bg: 'bg-red-100' },
  [AlertStatus.ACKNOWLEDGED]: { text: 'text-yellow-700', bg: 'bg-yellow-100' },
  [AlertStatus.RESOLVED]: { text: 'text-green-700', bg: 'bg-green-100' },
  [AlertStatus.EXPIRED]: { text: 'text-gray-700', bg: 'bg-gray-100' },
};

// =========================================================
// TYPE HELPERS
// =========================================================

export const ALERT_TYPE_LABELS: Record<AlertType, string> = {
  [AlertType.RISK_THRESHOLD]: 'Umbral de Riesgo',
  [AlertType.OPPORTUNITY_DETECTED]: 'Oportunidad Detectada',
  [AlertType.TREND_CHANGE]: 'Cambio de Tendencia',
  [AlertType.ANOMALY_DETECTED]: 'Anomalía Detectada',
  [AlertType.DEADLINE_APPROACHING]: 'Fecha Límite Próxima',
  [AlertType.REGULATORY_IMPACT]: 'Impacto Regulatorio',
  [AlertType.MARKET_SHIFT]: 'Cambio de Mercado',
};

// =========================================================
// CALCULATIONS
// =========================================================

/**
 * Calcula el color interpolado entre rojo y verde basado en un valor
 */
export function interpolateColor(value: number, min = 0, max = 100): string {
  const ratio = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const r = Math.round(255 * (1 - ratio));
  const g = Math.round(255 * ratio);
  return `rgb(${r}, ${g}, 50)`;
}

/**
 * Calcula el percentil de un valor en un array
 */
export function calculatePercentile(value: number, values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const index = sorted.findIndex((v) => v >= value);
  return ((index + 1) / sorted.length) * 100;
}

/**
 * Calcula estadísticas básicas de un array
 */
export function calculateStats(values: number[]): {
  min: number;
  max: number;
  avg: number;
  median: number;
  stdDev: number;
} {
  if (values.length === 0) {
    return { min: 0, max: 0, avg: 0, median: 0, stdDev: 0 };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const sum = values.reduce((a, b) => a + b, 0);
  const avg = sum / values.length;
  const median =
    sorted.length % 2 === 0
      ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
      : sorted[Math.floor(sorted.length / 2)];
  const variance =
    values.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / values.length;
  const stdDev = Math.sqrt(variance);

  return {
    min: sorted[0],
    max: sorted[sorted.length - 1],
    avg,
    median,
    stdDev,
  };
}

// =========================================================
// VALIDATION
// =========================================================

/**
 * Valida si un valor es un número válido
 */
export function isValidNumber(value: any): value is number {
  return typeof value === 'number' && !isNaN(value) && isFinite(value);
}

/**
 * Clamp un valor entre min y max
 */
export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

// =========================================================
// URL HELPERS
// =========================================================

/**
 * Construye URL con query params
 */
export function buildUrl(base: string, params: Record<string, any>): string {
  const url = new URL(base, window.location.origin);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value));
    }
  });
  return url.toString();
}

/**
 * Parsea query params de la URL actual
 */
export function parseQueryParams<T extends Record<string, string>>(): Partial<T> {
  if (typeof window === 'undefined') return {};
  const params = new URLSearchParams(window.location.search);
  const result: Record<string, string> = {};
  params.forEach((value, key) => {
    result[key] = value;
  });
  return result as Partial<T>;
}

// =========================================================
// EXPORTS
// =========================================================

export default {
  formatNumber,
  formatPercent,
  formatUF,
  formatCLP,
  formatDate,
  formatDateTime,
  formatRelativeTime,
  getScoreColor,
  getScoreBgColor,
  getTrendColor,
  getTrendIcon,
  interpolateColor,
  calculatePercentile,
  calculateStats,
  isValidNumber,
  clamp,
  buildUrl,
  parseQueryParams,
  ANGLE_LABELS,
  ANGLE_COLORS,
  ANGLE_DESCRIPTIONS,
  SEVERITY_LABELS,
  SEVERITY_COLORS,
  SEVERITY_ICONS,
  STATUS_LABELS,
  STATUS_COLORS,
  ALERT_TYPE_LABELS,
};
