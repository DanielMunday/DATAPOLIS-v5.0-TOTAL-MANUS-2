/**
 * =========================================================
 * PAE M11 - API Service
 * =========================================================
 * 
 * Servicio para interactuar con la API del PAE.
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import {
  PrecessionAnalysis,
  PrecessionAlert,
  PrecessionComparison,
  CopropiedadMetrics,
  DashboardData,
  SystemStats,
  InvestorReport,
  TaxContext,
  ExpenseContext,
  ComplianceContext,
  ValuationContext,
  RentalContext,
  Copropiedad,
  ApiResponse,
  AnalyzeFormData,
  CompareFormData,
  AlertFilterData,
  AlertSeverity,
} from '@/types/pae.types';

// =========================================================
// CLIENT CONFIGURATION
// =========================================================

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Request interceptor for auth
apiClient.interceptors.request.use(
  (config) => {
    const token = typeof window !== 'undefined' 
      ? localStorage.getItem('auth_token') 
      : null;
    
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Handle unauthorized
      if (typeof window !== 'undefined') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// =========================================================
// ANALYSIS ENDPOINTS
// =========================================================

export const paeApi = {
  /**
   * Ejecutar análisis precesional para una copropiedad
   */
  async analyzeCopropiedad(
    copropiedadId: number,
    params: Partial<AnalyzeFormData> = {}
  ): Promise<PrecessionAnalysis> {
    const response = await apiClient.post<ApiResponse<PrecessionAnalysis>>(
      `/v1/pae/analyze/copropiedad/${copropiedadId}`,
      {
        horizon: params.horizon || 36,
        radius: params.radius || 1000,
        max_depth: params.max_depth || 4,
        include_ml: params.include_ml ?? true,
        generate_heatmap: params.generate_heatmap ?? false,
        force_refresh: params.force_refresh ?? false,
      }
    );
    return response.data.data;
  },

  /**
   * Obtener lista de análisis
   */
  async getAnalyses(params: {
    copropiedad_id?: number;
    status?: string;
    page?: number;
    per_page?: number;
  } = {}): Promise<{ data: PrecessionAnalysis[]; meta: any }> {
    const response = await apiClient.get('/v1/pae/analyses', { params });
    return response.data;
  },

  /**
   * Obtener análisis específico
   */
  async getAnalysis(id: string): Promise<PrecessionAnalysis> {
    const response = await apiClient.get<ApiResponse<PrecessionAnalysis>>(
      `/v1/pae/analyses/${id}`
    );
    return response.data.data;
  },

  // =========================================================
  // DASHBOARD
  // =========================================================

  /**
   * Obtener datos del dashboard para una copropiedad
   */
  async getDashboard(copropiedadId: number): Promise<DashboardData> {
    const response = await apiClient.get<ApiResponse<DashboardData>>(
      `/v1/pae/dashboard/${copropiedadId}`
    );
    return response.data.data;
  },

  /**
   * Obtener estadísticas del sistema
   */
  async getSystemStats(days: number = 7): Promise<SystemStats> {
    const response = await apiClient.get<ApiResponse<SystemStats>>(
      '/v1/pae/stats',
      { params: { days } }
    );
    return response.data.data;
  },

  // =========================================================
  // METRICS
  // =========================================================

  /**
   * Obtener métricas consolidadas
   */
  async getConsolidatedMetrics(copropiedadId: number): Promise<CopropiedadMetrics> {
    const response = await apiClient.get<ApiResponse<CopropiedadMetrics>>(
      `/v1/pae/metrics/${copropiedadId}`
    );
    return response.data.data;
  },

  /**
   * Obtener contexto tributario
   */
  async getTaxContext(copropiedadId: number): Promise<TaxContext> {
    const response = await apiClient.get<ApiResponse<TaxContext>>(
      `/v1/pae/metrics/${copropiedadId}/tax`
    );
    return response.data.data;
  },

  /**
   * Obtener contexto de gastos
   */
  async getExpenseContext(copropiedadId: number): Promise<ExpenseContext> {
    const response = await apiClient.get<ApiResponse<ExpenseContext>>(
      `/v1/pae/metrics/${copropiedadId}/expenses`
    );
    return response.data.data;
  },

  /**
   * Obtener contexto de compliance
   */
  async getComplianceContext(copropiedadId: number): Promise<ComplianceContext> {
    const response = await apiClient.get<ApiResponse<ComplianceContext>>(
      `/v1/pae/metrics/${copropiedadId}/compliance`
    );
    return response.data.data;
  },

  /**
   * Obtener contexto de valorización
   */
  async getValuationContext(copropiedadId: number): Promise<ValuationContext> {
    const response = await apiClient.get<ApiResponse<ValuationContext>>(
      `/v1/pae/metrics/${copropiedadId}/valuation`
    );
    return response.data.data;
  },

  /**
   * Obtener contexto de arriendos
   */
  async getRentalContext(copropiedadId: number): Promise<RentalContext> {
    const response = await apiClient.get<ApiResponse<RentalContext>>(
      `/v1/pae/metrics/${copropiedadId}/rental`
    );
    return response.data.data;
  },

  // =========================================================
  // ALERTS
  // =========================================================

  /**
   * Obtener alertas
   */
  async getAlerts(filters: AlertFilterData = {}): Promise<PrecessionAlert[]> {
    const response = await apiClient.get<ApiResponse<PrecessionAlert[]>>(
      '/v1/pae/alerts',
      { params: filters }
    );
    return response.data.data;
  },

  /**
   * Reconocer alerta
   */
  async acknowledgeAlert(id: string): Promise<PrecessionAlert> {
    const response = await apiClient.post<ApiResponse<PrecessionAlert>>(
      `/v1/pae/alerts/${id}/acknowledge`
    );
    return response.data.data;
  },

  /**
   * Resolver alerta
   */
  async resolveAlert(
    id: string, 
    notes?: string
  ): Promise<PrecessionAlert> {
    const response = await apiClient.post<ApiResponse<PrecessionAlert>>(
      `/v1/pae/alerts/${id}/resolve`,
      { resolution_notes: notes }
    );
    return response.data.data;
  },

  // =========================================================
  // COMPARISON
  // =========================================================

  /**
   * Comparar copropiedades
   */
  async comparePrecession(
    copropiedadIds: number[]
  ): Promise<PrecessionComparison> {
    const response = await apiClient.post<ApiResponse<PrecessionComparison>>(
      '/v1/pae/compare',
      { copropiedad_ids: copropiedadIds }
    );
    return response.data.data;
  },

  /**
   * Comparar métricas
   */
  async compareMetrics(
    copropiedadIds: number[]
  ): Promise<{ copropiedades: any[]; averages: any; rankings: any }> {
    const response = await apiClient.post(
      '/v1/pae/compare-metrics',
      { copropiedad_ids: copropiedadIds }
    );
    return response.data.data;
  },

  // =========================================================
  // REPORTS
  // =========================================================

  /**
   * Generar reporte para inversor
   */
  async generateInvestorReport(
    copropiedadId: number,
    format: 'json' | 'pdf' = 'json'
  ): Promise<InvestorReport | Blob> {
    const response = await apiClient.get(
      `/v1/pae/report/${copropiedadId}`,
      { 
        params: { format },
        responseType: format === 'pdf' ? 'blob' : 'json',
      }
    );
    
    if (format === 'pdf') {
      return response.data as Blob;
    }
    
    return response.data.data as InvestorReport;
  },

  /**
   * Descargar reporte PDF
   */
  async downloadReportPDF(copropiedadId: number): Promise<void> {
    const blob = await this.generateInvestorReport(copropiedadId, 'pdf') as Blob;
    
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PAE_Report_${copropiedadId}_${new Date().toISOString().split('T')[0]}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  },

  // =========================================================
  // RANKINGS
  // =========================================================

  /**
   * Obtener rankings
   */
  async getRankings(params: {
    metric?: string;
    order?: 'asc' | 'desc';
    limit?: number;
  } = {}): Promise<{ metric: string; rankings: any[] }> {
    const response = await apiClient.get('/v1/pae/rankings', { params });
    return response.data.data;
  },

  /**
   * Obtener top riesgos
   */
  async getTopRisks(limit: number = 10): Promise<any[]> {
    const response = await apiClient.get('/v1/pae/stats/top-risks', { 
      params: { limit } 
    });
    return response.data.data;
  },

  /**
   * Obtener top oportunidades
   */
  async getTopOpportunities(limit: number = 10): Promise<any[]> {
    const response = await apiClient.get('/v1/pae/stats/top-opportunities', { 
      params: { limit } 
    });
    return response.data.data;
  },

  // =========================================================
  // HEATMAP
  // =========================================================

  /**
   * Obtener heatmap para un área
   */
  async getHeatmap(bounds: {
    minLat: number;
    maxLat: number;
    minLng: number;
    maxLng: number;
  }): Promise<any> {
    const response = await apiClient.get('/v1/pae/heatmap', { params: bounds });
    return response.data.data;
  },

  // =========================================================
  // COPROPIEDADES
  // =========================================================

  /**
   * Obtener lista de copropiedades
   */
  async getCopropiedades(params: {
    search?: string;
    comuna?: string;
    activa?: boolean;
    page?: number;
    per_page?: number;
  } = {}): Promise<{ data: Copropiedad[]; meta: any }> {
    const response = await apiClient.get('/v1/copropiedades', { params });
    return response.data;
  },

  /**
   * Obtener copropiedad por ID
   */
  async getCopropiedad(id: number): Promise<Copropiedad> {
    const response = await apiClient.get<ApiResponse<Copropiedad>>(
      `/v1/copropiedades/${id}`
    );
    return response.data.data;
  },

  // =========================================================
  // PROJECTIONS
  // =========================================================

  /**
   * Obtener proyecciones
   */
  async getProjections(copropiedadId: number): Promise<any> {
    const response = await apiClient.get(
      `/v1/pae/projections/${copropiedadId}`
    );
    return response.data.data;
  },
};

// Export individual functions for convenience
export const {
  analyzeCopropiedad,
  getAnalyses,
  getAnalysis,
  getDashboard,
  getSystemStats,
  getConsolidatedMetrics,
  getTaxContext,
  getExpenseContext,
  getComplianceContext,
  getValuationContext,
  getRentalContext,
  getAlerts,
  acknowledgeAlert,
  resolveAlert,
  comparePrecession,
  compareMetrics,
  generateInvestorReport,
  downloadReportPDF,
  getRankings,
  getTopRisks,
  getTopOpportunities,
  getHeatmap,
  getCopropiedades,
  getCopropiedad,
  getProjections,
} = paeApi;

export default paeApi;
