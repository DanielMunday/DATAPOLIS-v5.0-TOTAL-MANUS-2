/**
 * =========================================================
 * PAE M11 - TypeScript Types
 * =========================================================
 * 
 * Tipos para el módulo Precession Analytics Engine.
 * Basado en la teoría de precesión de R. Buckminster Fuller.
 */

// =========================================================
// ENUMS
// =========================================================

export enum PrecessionAngle {
  DIRECT_0 = 'direct_0',
  INDUCED_45 = 'induced_45',
  PRECESSION_90 = 'precession_90',
  SYSTEMIC_135 = 'systemic_135',
  COUNTER_180 = 'counter_180',
}

export enum AlertSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}

export enum AlertType {
  RISK_THRESHOLD = 'risk_threshold',
  OPPORTUNITY_DETECTED = 'opportunity_detected',
  TREND_CHANGE = 'trend_change',
  ANOMALY_DETECTED = 'anomaly_detected',
  DEADLINE_APPROACHING = 'deadline_approaching',
  REGULATORY_IMPACT = 'regulatory_impact',
  MARKET_SHIFT = 'market_shift',
}

export enum AlertStatus {
  ACTIVE = 'active',
  ACKNOWLEDGED = 'acknowledged',
  RESOLVED = 'resolved',
  EXPIRED = 'expired',
}

export enum AnalysisStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  EXPIRED = 'expired',
}

// =========================================================
// CORE TYPES
// =========================================================

export interface PrecessionAnalysis {
  id: string;
  copropiedad_id: number;
  copropiedad?: Copropiedad;
  tenant_id: number;
  analysis_type: string;
  status: AnalysisStatus;
  
  // Scores
  precession_score: number;
  risk_score: number;
  opportunity_score: number;
  confidence: number;
  
  // Values by angle (UF)
  total_precession_value_uf: number;
  direct_value_uf: number;
  induced_value_uf: number;
  precession_value_uf: number;
  systemic_value_uf: number;
  counter_value_uf: number;
  
  // Effects
  effects_summary: PrecessionEffectSummary;
  effects_count: number;
  
  // ML Predictions
  ml_predictions?: MLPredictions;
  
  // Spatial
  influence_zone_geojson?: GeoJSON.FeatureCollection;
  heatmap_data?: HeatmapData;
  
  // Parameters
  parameters: AnalysisParameters;
  
  // Timestamps
  created_at: string;
  updated_at: string;
  expires_at: string;
}

export interface PrecessionEffect {
  id: string;
  analysis_id: string;
  precession_angle: PrecessionAngle;
  source_node_id: string;
  target_node_id: string;
  effect_type: 'positive' | 'negative' | 'neutral';
  weight: number;
  temporal_lag_months: number;
  value_uf: number;
  confidence: number;
  description: string;
  evidence_sources: string[];
}

export interface PrecessionEffectSummary {
  by_angle: Record<PrecessionAngle, {
    count: number;
    total_value_uf: number;
    avg_confidence: number;
    positive_count: number;
    negative_count: number;
  }>;
  by_type: {
    positive: number;
    negative: number;
    neutral: number;
  };
  top_effects: PrecessionEffect[];
}

export interface MLPredictions {
  model_version: string;
  predictions: Record<string, number>; // horizon -> prediction
  confidence_intervals: Record<string, [number, number]>;
  feature_importance: Record<string, number>;
  updated_at: string;
}

export interface HeatmapData {
  bounds: {
    minLat: number;
    maxLat: number;
    minLng: number;
    maxLng: number;
  };
  resolution: number;
  cells: HeatmapCell[];
}

export interface HeatmapCell {
  lat: number;
  lng: number;
  value: number;
  intensity: number;
}

export interface AnalysisParameters {
  horizon_months: number;
  radius_meters: number;
  max_depth: number;
  include_ml: boolean;
  generate_heatmap: boolean;
}

// =========================================================
// ALERTS
// =========================================================

export interface PrecessionAlert {
  id: string;
  tenant_id: number;
  copropiedad_id: number;
  copropiedad?: Copropiedad;
  analysis_id?: string;
  
  alert_type: AlertType;
  severity: AlertSeverity;
  precession_angle: PrecessionAngle;
  status: AlertStatus;
  
  title: string;
  description: string;
  recommendation?: string;
  
  probability: number;
  potential_impact_uf: number;
  expected_months: number;
  
  acknowledged_at?: string;
  acknowledged_by?: number;
  resolved_at?: string;
  resolved_by?: number;
  resolution_notes?: string;
  
  created_at: string;
  expires_at: string;
}

// =========================================================
// COMPARISON
// =========================================================

export interface PrecessionComparison {
  id: string;
  tenant_id: number;
  copropiedad_ids: number[];
  copropiedades: Copropiedad[];
  
  comparison_data: ComparisonData;
  aggregates: ComparisonAggregates;
  rankings: ComparisonRankings;
  
  created_at: string;
}

export interface ComparisonData {
  analyses: PrecessionAnalysis[];
  metrics: Record<number, CopropiedadMetrics>;
}

export interface ComparisonAggregates {
  avg_precession_score: number;
  avg_risk_score: number;
  avg_opportunity_score: number;
  total_value_uf: number;
}

export interface ComparisonRankings {
  by_precession_score: number[];
  by_risk_score: number[];
  by_opportunity_score: number[];
  by_value_uf: number[];
}

// =========================================================
// METRICS
// =========================================================

export interface CopropiedadMetrics {
  copropiedad_id: number;
  
  // Tax (M04)
  tax_risk_score?: number;
  tax_projected_load_12m?: number;
  tax_compliance_rate?: number;
  
  // Expenses (M05)
  expense_avg_monthly?: number;
  expense_trend_direction?: 'creciente' | 'decreciente' | 'estable';
  expense_trend_percentage?: number;
  expense_volatility_level?: 'bajo' | 'medio' | 'alto';
  
  // Compliance (M06)
  compliance_score_global?: number;
  compliance_ds7_score?: number;
  compliance_ley21442_status?: 'cumple' | 'parcial' | 'incumple';
  compliance_gaps_count?: number;
  compliance_critical_gaps?: number;
  
  // Valuation (M08)
  valuation_current_uf?: number;
  valuation_12m_uf?: number;
  valuation_60m_uf?: number;
  valuation_appreciation_60m?: number;
  valuation_confidence?: number;
  
  // Rental (M16)
  rental_active_count?: number;
  rental_avg_monthly?: number;
  rental_vacancy_rate?: number;
  rental_gross_yield?: number;
  rental_net_yield?: number;
  
  // PAE
  pae_precession_score?: number;
  pae_risk_score?: number;
  pae_opportunity_score?: number;
  pae_last_analysis?: string;
  
  updated_at: string;
}

export interface TaxContext {
  dj_1879: {
    ultimo_periodo?: string;
    monto_informado: number;
    cantidad_informantes: number;
    cumplimiento: string;
    historico_3_anos: any[];
  };
  dj_1907: {
    ultimo_periodo?: string;
    rentas_informadas: number;
    retenciones: number;
    cumplimiento: string;
  };
  ppm: {
    tasa_vigente: number;
    base_imponible_mensual: number;
    pagos_acumulados_ano: number;
    tendencia_12m: number;
  };
  iva: {
    aplica: boolean;
    debito_fiscal_mensual: number;
    credito_fiscal_mensual: number;
    saldo_promedio: number;
  };
  metrics: {
    carga_anual_estimada: number;
    cumplimiento_global: number;
    riesgo_fiscalizacion: number;
    ahorro_potencial: number;
  };
  risk_score: number;
  projected_load_12m: number;
  projected_load_36m: number;
}

export interface ExpenseContext {
  historico: {
    meses_disponibles: number;
    promedio_mensual: number;
    minimo: number;
    maximo: number;
    ultimo_gasto: number;
    fecha_ultimo: string;
  };
  tendencia: {
    direccion: string;
    porcentaje_anual: number;
    pendiente: number;
    r_squared: number;
  };
  estacionalidad: {
    detectada: boolean;
    meses_altos: number[];
    meses_bajos: number[];
    amplitud: number;
    indices_mensuales: Record<number, number>;
  };
  volatilidad: {
    coeficiente_variacion: number;
    desviacion_estandar: number;
    nivel: string;
  };
  proyecciones: {
    '12_meses': {
      total: number;
      promedio_mensual: number;
      intervalo_confianza: { inferior: number; superior: number };
    };
    '36_meses': {
      total: number;
      promedio_mensual: number;
      intervalo_confianza: { inferior: number; superior: number };
    };
  };
}

export interface ComplianceContext {
  ds7_2025: {
    score: number;
    nivel: string;
    requisitos_cumplidos: number;
    requisitos_totales: number;
    detalle: Record<string, boolean>;
  };
  ley_21442: {
    estado: string;
    fecha_limite: string;
    dias_restantes: number;
    requisitos: Record<string, boolean>;
    multa_potencial: number;
  };
  brechas: {
    cantidad: number;
    criticas: any[];
    altas: any[];
    detalle: any[];
  };
  cambio_normativo: {
    probabilidad_12m: number;
    impacto_estimado: string;
    normativas_en_tramite: string[];
  };
  score_global: number;
  recomendaciones: any[];
}

export interface ValuationContext {
  avaluo_fiscal: {
    valor_uf: number;
    fecha: string;
    destino: string;
    superficie_m2: number;
    valor_m2_uf: number;
  };
  mercado_cbr: {
    transacciones_12m: number;
    valor_m2_promedio: number;
    tendencia: string;
    cap_rate_implicito: number;
  };
  arriendos_zona: {
    arriendo_m2_promedio: number;
    vacancia: number;
    tendencia_12m: string;
    comparables: number;
  };
  valorizacion_precesional: {
    horizonte_12m: number;
    horizonte_24m: number;
    horizonte_36m: number;
    horizonte_60m: number;
    factores_principales: string[];
    confianza: number;
  };
  indicadores: {
    ratio_avaluo_mercado: number;
    gross_yield: number;
  };
}

export interface RentalContext {
  arriendos_activos: {
    cantidad: number;
    ingreso_mensual_total: number;
    arriendo_promedio: number;
    duracion_promedio_meses: number;
  };
  precio_m2: {
    promedio: number;
    minimo: number;
    maximo: number;
    tendencia_12m: number;
    variacion_ipc: number;
  };
  vacancia: {
    tasa_actual: number;
    unidades_disponibles: number;
    dias_promedio_vacante: number;
    tendencia: string;
  };
  proyeccion_precesional: {
    arriendo_12m: number;
    arriendo_24m: number;
    arriendo_36m: number;
    factores_ajuste: {
      crecimiento_base: number;
      ajuste_precesional: number;
    };
    intervalo_confianza: { inferior: number; superior: number };
  };
  metricas_inversion: {
    gross_yield: number;
    net_yield: number;
    payback_anos: number;
  };
}

// =========================================================
// DASHBOARD
// =========================================================

export interface DashboardData {
  analysis: PrecessionAnalysis;
  metrics: CopropiedadMetrics;
  alerts: PrecessionAlert[];
  recentAnalyses: PrecessionAnalysis[];
}

export interface SystemStats {
  period_days: number;
  totals: {
    analyses_completed: number;
    analyses_failed: number;
    alerts_triggered: number;
    critical_alerts: number;
    alerts_resolved: number;
  };
  averages: {
    avg_precession_score: number;
    avg_risk_score: number;
    avg_opportunity_score: number;
    avg_execution_time: number;
  };
  active_alerts: Record<AlertSeverity, number>;
  success_rate: number;
}

// =========================================================
// COPROPIEDAD (simplified)
// =========================================================

export interface Copropiedad {
  id: number;
  tenant_id: number;
  nombre: string;
  direccion: string;
  comuna: string;
  region: string;
  latitud: number;
  longitud: number;
  tipo: string;
  unidades_count: number;
  superficie_total?: number;
  activa: boolean;
}

// =========================================================
// API RESPONSES
// =========================================================

export interface ApiResponse<T> {
  data: T;
  message?: string;
  meta?: {
    total?: number;
    page?: number;
    per_page?: number;
  };
}

export interface ApiError {
  error: string;
  message: string;
  status: number;
}

// =========================================================
// FORM TYPES
// =========================================================

export interface AnalyzeFormData {
  copropiedad_id: number;
  horizon: number;
  radius: number;
  max_depth: number;
  include_ml: boolean;
  generate_heatmap: boolean;
  force_refresh: boolean;
}

export interface CompareFormData {
  copropiedad_ids: number[];
}

export interface AlertFilterData {
  severity?: AlertSeverity;
  type?: AlertType;
  status?: AlertStatus;
  copropiedad_id?: number;
  from_date?: string;
  to_date?: string;
}

// =========================================================
// CHART DATA
// =========================================================

export interface RadarChartData {
  angle: string;
  label: string;
  value: number;
  fullMark: number;
}

export interface TimelineItem {
  id: string;
  title: string;
  description: string;
  date: string;
  horizon_months: number;
  type: 'positive' | 'negative' | 'neutral';
  value_uf: number;
  angle: PrecessionAngle;
}

export interface ComparisonChartData {
  name: string;
  [key: string]: number | string;
}

// =========================================================
// INVESTOR REPORT
// =========================================================

export interface InvestorReport {
  copropiedad: Copropiedad;
  analysis: PrecessionAnalysis;
  metrics: CopropiedadMetrics;
  executive_summary: string;
  risk_assessment: {
    level: 'low' | 'medium' | 'high';
    factors: string[];
    mitigation: string[];
  };
  opportunities: {
    type: string;
    description: string;
    potential_value_uf: number;
    timeframe_months: number;
  }[];
  recommendations: {
    priority: number;
    action: string;
    expected_impact: string;
  }[];
  comparables: {
    copropiedad_id: number;
    nombre: string;
    precession_score: number;
    value_uf: number;
  }[];
  generated_at: string;
}
