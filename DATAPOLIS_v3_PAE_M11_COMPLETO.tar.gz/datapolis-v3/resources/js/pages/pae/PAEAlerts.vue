<script setup>
/**
 * PAE Alerts - Gestión de Alertas Precesionales
 * 
 * Lista y gestiona alertas precesionales generadas por el sistema PAE.
 * Permite filtrar, reconocer y resolver alertas.
 */
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useToast } from 'primevue/usetoast';
import { FilterMatchMode } from 'primevue/api';
import api from '@/services/api';

const router = useRouter();
const toast = useToast();

// Estado
const alerts = ref([]);
const isLoading = ref(true);
const selectedAlerts = ref([]);
const showResolveDialog = ref(false);
const currentAlert = ref(null);
const resolutionNotes = ref('');

// Filtros
const filters = ref({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    severity: { value: null, matchMode: FilterMatchMode.EQUALS },
    alert_type: { value: null, matchMode: FilterMatchMode.EQUALS },
    status: { value: null, matchMode: FilterMatchMode.EQUALS },
});

// Opciones de filtro
const severityOptions = [
    { label: 'Crítica', value: 'critical' },
    { label: 'Alta', value: 'high' },
    { label: 'Media', value: 'medium' },
    { label: 'Baja', value: 'low' },
];

const typeOptions = [
    { label: 'Umbral de Riesgo', value: 'risk_threshold' },
    { label: 'Oportunidad', value: 'opportunity_detected' },
    { label: 'Cambio Tendencia', value: 'trend_change' },
    { label: 'Anomalía', value: 'anomaly_detected' },
    { label: 'Plazo Cercano', value: 'deadline_approaching' },
    { label: 'Impacto Regulatorio', value: 'regulatory_impact' },
    { label: 'Cambio Mercado', value: 'market_shift' },
];

const statusOptions = [
    { label: 'Activa', value: 'active' },
    { label: 'Reconocida', value: 'acknowledged' },
    { label: 'Resuelta', value: 'resolved' },
    { label: 'Descartada', value: 'dismissed' },
];

const angleLabels = {
    direct_0: 'Directo (0°)',
    induced_45: 'Inducido (45°)',
    precession_90: 'Precesional (90°)',
    systemic_135: 'Sistémico (135°)',
    counter_180: 'Contra-Precesión (180°)',
};

onMounted(async () => {
    await loadAlerts();
});

async function loadAlerts() {
    isLoading.value = true;
    try {
        const response = await api.get('/pae/alerts', {
            params: { limit: 100 },
        });
        alerts.value = response.data.data;
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudieron cargar las alertas',
            life: 5000,
        });
    } finally {
        isLoading.value = false;
    }
}

async function acknowledgeAlert(alert) {
    try {
        await api.post(`/pae/alerts/${alert.id}/acknowledge`);
        toast.add({
            severity: 'success',
            summary: 'Alerta reconocida',
            detail: 'La alerta ha sido marcada como reconocida',
            life: 3000,
        });
        await loadAlerts();
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudo reconocer la alerta',
            life: 5000,
        });
    }
}

function openResolveDialog(alert) {
    currentAlert.value = alert;
    resolutionNotes.value = '';
    showResolveDialog.value = true;
}

async function resolveAlert() {
    try {
        await api.post(`/pae/alerts/${currentAlert.value.id}/resolve`, {
            resolution_notes: resolutionNotes.value,
        });
        toast.add({
            severity: 'success',
            summary: 'Alerta resuelta',
            detail: 'La alerta ha sido marcada como resuelta',
            life: 3000,
        });
        showResolveDialog.value = false;
        await loadAlerts();
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudo resolver la alerta',
            life: 5000,
        });
    }
}

async function acknowledgeSelected() {
    for (const alert of selectedAlerts.value) {
        if (alert.status === 'active') {
            await api.post(`/pae/alerts/${alert.id}/acknowledge`);
        }
    }
    toast.add({
        severity: 'success',
        summary: 'Alertas reconocidas',
        detail: `${selectedAlerts.value.length} alertas han sido reconocidas`,
        life: 3000,
    });
    selectedAlerts.value = [];
    await loadAlerts();
}

// Computed
const activeCount = computed(() => 
    alerts.value.filter(a => a.status === 'active').length
);

const criticalCount = computed(() => 
    alerts.value.filter(a => a.severity === 'critical' && a.status === 'active').length
);

// Helpers
function getSeverityClass(severity) {
    return {
        critical: 'danger',
        high: 'warning',
        medium: 'info',
        low: 'secondary',
    }[severity] || 'secondary';
}

function getSeverityIcon(severity) {
    return {
        critical: 'pi-exclamation-circle',
        high: 'pi-exclamation-triangle',
        medium: 'pi-info-circle',
        low: 'pi-bell',
    }[severity] || 'pi-bell';
}

function getStatusClass(status) {
    return {
        active: 'danger',
        acknowledged: 'warning',
        resolved: 'success',
        dismissed: 'secondary',
    }[status] || 'secondary';
}

function getTypeLabel(type) {
    const option = typeOptions.find(t => t.value === type);
    return option?.label || type;
}

function formatDate(date) {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('es-CL', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}

function formatUf(value) {
    if (!value) return '-';
    return new Intl.NumberFormat('es-CL').format(value) + ' UF';
}
</script>

<template>
    <div class="pae-alerts">
        <!-- Header -->
        <div class="page-header">
            <div class="header-left">
                <Button 
                    icon="pi pi-arrow-left" 
                    class="p-button-text"
                    @click="router.back()"
                />
                <div class="header-info">
                    <h1>
                        <i class="pi pi-bell"></i>
                        Alertas Precesionales
                    </h1>
                    <p>Gestión de alertas generadas por el Precession Analytics Engine</p>
                </div>
            </div>
            <div class="header-stats">
                <div class="stat-badge active">
                    <span class="stat-value">{{ activeCount }}</span>
                    <span class="stat-label">Activas</span>
                </div>
                <div class="stat-badge critical" v-if="criticalCount > 0">
                    <span class="stat-value">{{ criticalCount }}</span>
                    <span class="stat-label">Críticas</span>
                </div>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="toolbar-left">
                <span class="p-input-icon-left">
                    <i class="pi pi-search" />
                    <InputText 
                        v-model="filters['global'].value" 
                        placeholder="Buscar alertas..."
                    />
                </span>
                <Dropdown 
                    v-model="filters['severity'].value"
                    :options="severityOptions"
                    optionLabel="label"
                    optionValue="value"
                    placeholder="Severidad"
                    :showClear="true"
                    class="w-10rem"
                />
                <Dropdown 
                    v-model="filters['alert_type'].value"
                    :options="typeOptions"
                    optionLabel="label"
                    optionValue="value"
                    placeholder="Tipo"
                    :showClear="true"
                    class="w-12rem"
                />
                <Dropdown 
                    v-model="filters['status'].value"
                    :options="statusOptions"
                    optionLabel="label"
                    optionValue="value"
                    placeholder="Estado"
                    :showClear="true"
                    class="w-10rem"
                />
            </div>
            <div class="toolbar-right">
                <Button 
                    label="Reconocer Seleccionadas"
                    icon="pi pi-check"
                    class="p-button-outlined"
                    :disabled="selectedAlerts.length === 0"
                    @click="acknowledgeSelected"
                />
                <Button 
                    icon="pi pi-refresh"
                    class="p-button-outlined"
                    @click="loadAlerts"
                    :loading="isLoading"
                    v-tooltip="'Actualizar'"
                />
            </div>
        </div>

        <!-- DataTable -->
        <Card>
            <template #content>
                <DataTable
                    v-model:selection="selectedAlerts"
                    v-model:filters="filters"
                    :value="alerts"
                    :loading="isLoading"
                    :paginator="true"
                    :rows="10"
                    :rowsPerPageOptions="[10, 25, 50]"
                    filterDisplay="menu"
                    responsiveLayout="scroll"
                    class="p-datatable-sm"
                >
                    <Column selectionMode="multiple" headerStyle="width: 3rem" />
                    
                    <Column field="severity" header="Severidad" :sortable="true" style="width: 120px">
                        <template #body="{ data }">
                            <Tag 
                                :value="data.severity"
                                :severity="getSeverityClass(data.severity)"
                                :icon="'pi ' + getSeverityIcon(data.severity)"
                            />
                        </template>
                    </Column>

                    <Column field="title" header="Alerta" :sortable="true">
                        <template #body="{ data }">
                            <div class="alert-cell">
                                <span class="alert-title">{{ data.title }}</span>
                                <span class="alert-description">{{ data.description }}</span>
                            </div>
                        </template>
                    </Column>

                    <Column field="alert_type" header="Tipo" :sortable="true" style="width: 150px">
                        <template #body="{ data }">
                            <span class="type-badge">{{ getTypeLabel(data.alert_type) }}</span>
                        </template>
                    </Column>

                    <Column field="precession_angle" header="Ángulo" style="width: 140px">
                        <template #body="{ data }">
                            <span v-if="data.precession_angle" class="angle-badge">
                                {{ angleLabels[data.precession_angle] || data.precession_angle }}
                            </span>
                            <span v-else class="text-muted">-</span>
                        </template>
                    </Column>

                    <Column field="potential_impact_uf" header="Impacto" :sortable="true" style="width: 120px">
                        <template #body="{ data }">
                            <span class="impact-value">{{ formatUf(data.potential_impact_uf) }}</span>
                        </template>
                    </Column>

                    <Column field="status" header="Estado" :sortable="true" style="width: 120px">
                        <template #body="{ data }">
                            <Tag 
                                :value="data.status"
                                :severity="getStatusClass(data.status)"
                            />
                        </template>
                    </Column>

                    <Column field="created_at" header="Fecha" :sortable="true" style="width: 150px">
                        <template #body="{ data }">
                            <span class="date-cell">{{ formatDate(data.created_at) }}</span>
                        </template>
                    </Column>

                    <Column header="Acciones" style="width: 150px">
                        <template #body="{ data }">
                            <div class="action-buttons">
                                <Button 
                                    v-if="data.status === 'active'"
                                    icon="pi pi-check"
                                    class="p-button-rounded p-button-text p-button-sm"
                                    v-tooltip="'Reconocer'"
                                    @click="acknowledgeAlert(data)"
                                />
                                <Button 
                                    v-if="data.status !== 'resolved'"
                                    icon="pi pi-check-circle"
                                    class="p-button-rounded p-button-text p-button-success p-button-sm"
                                    v-tooltip="'Resolver'"
                                    @click="openResolveDialog(data)"
                                />
                                <Button 
                                    v-if="data.copropiedad_id"
                                    icon="pi pi-external-link"
                                    class="p-button-rounded p-button-text p-button-sm"
                                    v-tooltip="'Ver Dashboard'"
                                    @click="router.push(`/pae/dashboard/${data.copropiedad_id}`)"
                                />
                            </div>
                        </template>
                    </Column>

                    <template #empty>
                        <div class="empty-state">
                            <i class="pi pi-check-circle"></i>
                            <p>No hay alertas que coincidan con los filtros</p>
                        </div>
                    </template>
                </DataTable>
            </template>
        </Card>

        <!-- Dialog Resolver Alerta -->
        <Dialog 
            v-model:visible="showResolveDialog"
            header="Resolver Alerta"
            :modal="true"
            :style="{ width: '500px' }"
        >
            <div v-if="currentAlert" class="resolve-form">
                <div class="alert-summary">
                    <Tag 
                        :value="currentAlert.severity"
                        :severity="getSeverityClass(currentAlert.severity)"
                    />
                    <h3>{{ currentAlert.title }}</h3>
                    <p>{{ currentAlert.description }}</p>
                </div>

                <Divider />

                <div class="form-group">
                    <label for="resolution_notes">Notas de Resolución</label>
                    <Textarea 
                        id="resolution_notes"
                        v-model="resolutionNotes"
                        rows="4"
                        class="w-full"
                        placeholder="Describa cómo se resolvió esta alerta..."
                    />
                </div>
            </div>

            <template #footer>
                <Button 
                    label="Cancelar" 
                    icon="pi pi-times" 
                    class="p-button-text" 
                    @click="showResolveDialog = false"
                />
                <Button 
                    label="Resolver Alerta" 
                    icon="pi pi-check-circle" 
                    @click="resolveAlert"
                />
            </template>
        </Dialog>
    </div>
</template>

<style scoped>
.pae-alerts {
    padding: 1.5rem;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1.5rem;
}

.header-left {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.header-info h1 {
    margin: 0;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.header-info h1 i {
    color: #f59e0b;
}

.header-info p {
    margin: 0.25rem 0 0;
    color: var(--text-muted);
}

.header-stats {
    display: flex;
    gap: 1rem;
}

.stat-badge {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0.75rem 1.25rem;
    border-radius: var(--border-radius);
    background: var(--bg-secondary);
}

.stat-badge.active {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
}

.stat-badge.critical {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 700;
}

.stat-label {
    font-size: 0.75rem;
    text-transform: uppercase;
}

.toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
    flex-wrap: wrap;
}

.toolbar-left,
.toolbar-right {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.alert-cell {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.alert-title {
    font-weight: 500;
}

.alert-description {
    font-size: 0.875rem;
    color: var(--text-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 300px;
}

.type-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);
}

.angle-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
    background: rgba(139, 92, 246, 0.1);
    color: #8b5cf6;
    border-radius: var(--border-radius);
}

.impact-value {
    font-weight: 500;
}

.date-cell {
    font-size: 0.875rem;
    color: var(--text-muted);
}

.action-buttons {
    display: flex;
    gap: 0.25rem;
}

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 3rem;
    color: var(--text-muted);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    color: #22c55e;
}

.resolve-form .alert-summary {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.resolve-form h3 {
    margin: 0.5rem 0 0;
}

.resolve-form p {
    color: var(--text-muted);
    margin: 0;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-group label {
    font-weight: 500;
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .toolbar {
        flex-direction: column;
        align-items: stretch;
    }
    
    .toolbar-left,
    .toolbar-right {
        flex-wrap: wrap;
    }
}
</style>
