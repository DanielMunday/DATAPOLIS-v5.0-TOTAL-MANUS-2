<script setup>
/**
 * PAE Compare - Comparación Precesional entre Copropiedades
 * 
 * Permite seleccionar múltiples copropiedades y comparar sus
 * análisis precesionales para toma de decisiones de inversión.
 */
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useToast } from 'primevue/usetoast';
import api from '@/services/api';

const router = useRouter();
const toast = useToast();

// Estado
const copropiedades = ref([]);
const selectedCopropiedades = ref([]);
const comparison = ref(null);
const isLoading = ref(false);
const isComparing = ref(false);

// Colores para gráficos
const chartColors = [
    '#8b5cf6', '#3b82f6', '#22c55e', '#f59e0b', '#ef4444',
    '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#6366f1',
];

onMounted(async () => {
    await loadCopropiedades();
});

async function loadCopropiedades() {
    isLoading.value = true;
    try {
        const response = await api.get('/proptech/copropiedades', {
            params: { per_page: 100 },
        });
        copropiedades.value = response.data.data;
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudieron cargar las copropiedades',
            life: 5000,
        });
    } finally {
        isLoading.value = false;
    }
}

async function runComparison() {
    if (selectedCopropiedades.value.length < 2) {
        toast.add({
            severity: 'warn',
            summary: 'Selección insuficiente',
            detail: 'Seleccione al menos 2 copropiedades para comparar',
            life: 3000,
        });
        return;
    }

    isComparing.value = true;
    try {
        const response = await api.post('/pae/compare', {
            copropiedad_ids: selectedCopropiedades.value.map(c => c.id),
        });
        comparison.value = response.data.data;
        
        toast.add({
            severity: 'success',
            summary: 'Comparación completada',
            detail: 'Los análisis precesionales han sido comparados',
            life: 3000,
        });
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: error.response?.data?.message || 'Error ejecutando comparación',
            life: 5000,
        });
    } finally {
        isComparing.value = false;
    }
}

function clearComparison() {
    comparison.value = null;
    selectedCopropiedades.value = [];
}

// Computed
const canCompare = computed(() => selectedCopropiedades.value.length >= 2);

const comparisonEntities = computed(() => {
    if (!comparison.value?.entities) return [];
    return Object.entries(comparison.value.entities).map(([id, data]) => {
        const copropiedad = selectedCopropiedades.value.find(c => c.id == id);
        return {
            ...data,
            nombre: copropiedad?.nombre || `Copropiedad ${id}`,
            direccion: copropiedad?.direccion || '',
        };
    });
});

const rankings = computed(() => comparison.value?.rankings || {});

const aggregates = computed(() => comparison.value?.aggregates || {});

// Datos para gráfico radar comparativo
const radarData = computed(() => {
    if (!comparison.value) return null;
    
    const datasets = comparisonEntities.value.map((entity, index) => ({
        label: entity.nombre,
        data: [
            (entity.precession_score || 0) / 100,
            entity.risk_score || 0,
            entity.opportunity_score || 0,
            entity.confidence || 0,
        ],
        backgroundColor: `${chartColors[index]}33`,
        borderColor: chartColors[index],
        pointBackgroundColor: chartColors[index],
    }));

    return {
        labels: ['Score Precesional', 'Riesgo', 'Oportunidad', 'Confianza'],
        datasets,
    };
});

const radarOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
        r: {
            beginAtZero: true,
            max: 1,
            grid: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
            angleLines: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
            pointLabels: {
                color: '#9ca3af',
            },
        },
    },
    plugins: {
        legend: {
            position: 'bottom',
        },
    },
};

// Datos para gráfico de barras de valores
const barData = computed(() => {
    if (!comparison.value) return null;

    return {
        labels: comparisonEntities.value.map(e => e.nombre.substring(0, 15) + '...'),
        datasets: [
            {
                label: 'Valor Total UF',
                data: comparisonEntities.value.map(e => e.total_value_uf || 0),
                backgroundColor: chartColors.slice(0, comparisonEntities.value.length),
            },
        ],
    };
});

const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            display: false,
        },
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
        },
        x: {
            grid: {
                display: false,
            },
        },
    },
};

// Helpers
function getCopropiedadName(id) {
    const copropiedad = selectedCopropiedades.value.find(c => c.id == id);
    return copropiedad?.nombre || `Copropiedad ${id}`;
}

function formatPercent(value) {
    if (!value && value !== 0) return '-';
    return (value * 100).toFixed(1) + '%';
}

function formatUf(value) {
    if (!value) return '0 UF';
    return new Intl.NumberFormat('es-CL').format(value) + ' UF';
}

function getRankingClass(entityId, rankingType) {
    if (rankings.value[rankingType] == entityId) {
        return rankingType.includes('risk') ? 'ranking-bad' : 'ranking-best';
    }
    return '';
}
</script>

<template>
    <div class="pae-compare">
        <!-- Header -->
        <div class="page-header">
            <div class="header-left">
                <Button 
                    icon="pi pi-arrow-left" 
                    class="p-button-text"
                    @click="router.back()"
                />
                <div class="header-info">
                    <h1>
                        <i class="pi pi-chart-bar"></i>
                        Comparación Precesional
                    </h1>
                    <p>Compare análisis precesionales entre múltiples copropiedades</p>
                </div>
            </div>
        </div>

        <div class="compare-layout">
            <!-- Sidebar Selección -->
            <Card class="selection-card">
                <template #title>
                    <i class="pi pi-building"></i>
                    Seleccionar Copropiedades
                </template>
                <template #subtitle>
                    {{ selectedCopropiedades.length }} de {{ copropiedades.length }} seleccionadas
                </template>
                <template #content>
                    <div class="selection-list">
                        <div class="search-box">
                            <span class="p-input-icon-left w-full">
                                <i class="pi pi-search" />
                                <InputText 
                                    placeholder="Buscar copropiedad..."
                                    class="w-full"
                                />
                            </span>
                        </div>

                        <div class="copropiedades-list">
                            <div 
                                v-for="copropiedad in copropiedades" 
                                :key="copropiedad.id"
                                class="copropiedad-item"
                                :class="{ selected: selectedCopropiedades.find(c => c.id === copropiedad.id) }"
                            >
                                <Checkbox 
                                    :inputId="'cop-' + copropiedad.id"
                                    :value="copropiedad"
                                    v-model="selectedCopropiedades"
                                    :disabled="selectedCopropiedades.length >= 10 && !selectedCopropiedades.find(c => c.id === copropiedad.id)"
                                />
                                <label :for="'cop-' + copropiedad.id" class="copropiedad-label">
                                    <span class="copropiedad-name">{{ copropiedad.nombre }}</span>
                                    <span class="copropiedad-comuna">{{ copropiedad.comuna }}</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="selection-actions">
                        <Button 
                            label="Comparar"
                            icon="pi pi-chart-bar"
                            :disabled="!canCompare"
                            :loading="isComparing"
                            @click="runComparison"
                            class="w-full"
                        />
                        <Button 
                            v-if="comparison"
                            label="Limpiar"
                            icon="pi pi-times"
                            class="p-button-outlined w-full"
                            @click="clearComparison"
                        />
                    </div>
                </template>
            </Card>

            <!-- Resultados -->
            <div class="results-area">
                <!-- Sin comparación -->
                <Card v-if="!comparison" class="empty-card">
                    <template #content>
                        <div class="empty-state">
                            <i class="pi pi-chart-bar"></i>
                            <h2>Seleccione Copropiedades</h2>
                            <p>
                                Seleccione al menos 2 copropiedades del panel izquierdo 
                                y haga clic en "Comparar" para ver el análisis comparativo.
                            </p>
                            <p class="hint">
                                Puede seleccionar hasta 10 copropiedades para una comparación.
                            </p>
                        </div>
                    </template>
                </Card>

                <!-- Resultados de comparación -->
                <template v-else>
                    <!-- Agregados -->
                    <div class="aggregates-grid">
                        <Card class="aggregate-card">
                            <template #content>
                                <div class="aggregate-content">
                                    <i class="pi pi-sitemap"></i>
                                    <div class="aggregate-info">
                                        <span class="aggregate-label">Promedio Precesional</span>
                                        <span class="aggregate-value">
                                            {{ (aggregates.avg_precession_score || 0).toFixed(1) }}
                                        </span>
                                    </div>
                                </div>
                            </template>
                        </Card>
                        <Card class="aggregate-card risk">
                            <template #content>
                                <div class="aggregate-content">
                                    <i class="pi pi-exclamation-triangle"></i>
                                    <div class="aggregate-info">
                                        <span class="aggregate-label">Promedio Riesgo</span>
                                        <span class="aggregate-value">
                                            {{ formatPercent(aggregates.avg_risk_score) }}
                                        </span>
                                    </div>
                                </div>
                            </template>
                        </Card>
                        <Card class="aggregate-card opportunity">
                            <template #content>
                                <div class="aggregate-content">
                                    <i class="pi pi-star"></i>
                                    <div class="aggregate-info">
                                        <span class="aggregate-label">Promedio Oportunidad</span>
                                        <span class="aggregate-value">
                                            {{ formatPercent(aggregates.avg_opportunity_score) }}
                                        </span>
                                    </div>
                                </div>
                            </template>
                        </Card>
                    </div>

                    <!-- Rankings -->
                    <Card class="rankings-card">
                        <template #title>
                            <i class="pi pi-trophy"></i>
                            Rankings
                        </template>
                        <template #content>
                            <div class="rankings-grid">
                                <div class="ranking-item best">
                                    <span class="ranking-label">Mejor Score Precesional</span>
                                    <span class="ranking-value">
                                        <i class="pi pi-star-fill"></i>
                                        {{ getCopropiedadName(rankings.best_precession) }}
                                    </span>
                                </div>
                                <div class="ranking-item best">
                                    <span class="ranking-label">Menor Riesgo</span>
                                    <span class="ranking-value">
                                        <i class="pi pi-shield"></i>
                                        {{ getCopropiedadName(rankings.lowest_risk) }}
                                    </span>
                                </div>
                                <div class="ranking-item best">
                                    <span class="ranking-label">Mejor Oportunidad</span>
                                    <span class="ranking-value">
                                        <i class="pi pi-bolt"></i>
                                        {{ getCopropiedadName(rankings.best_opportunity) }}
                                    </span>
                                </div>
                                <div class="ranking-item best">
                                    <span class="ranking-label">Mayor Valor</span>
                                    <span class="ranking-value">
                                        <i class="pi pi-dollar"></i>
                                        {{ getCopropiedadName(rankings.highest_value) }}
                                    </span>
                                </div>
                            </div>
                        </template>
                    </Card>

                    <!-- Gráficos -->
                    <div class="charts-grid">
                        <Card class="chart-card">
                            <template #title>
                                <i class="pi pi-chart-pie"></i>
                                Comparación de Scores
                            </template>
                            <template #content>
                                <div class="chart-container">
                                    <Chart 
                                        v-if="radarData"
                                        type="radar" 
                                        :data="radarData" 
                                        :options="radarOptions"
                                    />
                                </div>
                            </template>
                        </Card>

                        <Card class="chart-card">
                            <template #title>
                                <i class="pi pi-chart-bar"></i>
                                Valor Precesional Total
                            </template>
                            <template #content>
                                <div class="chart-container">
                                    <Chart 
                                        v-if="barData"
                                        type="bar" 
                                        :data="barData" 
                                        :options="barOptions"
                                    />
                                </div>
                            </template>
                        </Card>
                    </div>

                    <!-- Tabla detallada -->
                    <Card class="details-card">
                        <template #title>
                            <i class="pi pi-table"></i>
                            Detalle por Copropiedad
                        </template>
                        <template #content>
                            <DataTable 
                                :value="comparisonEntities"
                                responsiveLayout="scroll"
                                class="p-datatable-sm"
                            >
                                <Column field="nombre" header="Copropiedad">
                                    <template #body="{ data }">
                                        <div class="entity-cell">
                                            <span class="entity-name">{{ data.nombre }}</span>
                                            <span class="entity-address">{{ data.direccion }}</span>
                                        </div>
                                    </template>
                                </Column>
                                <Column field="precession_score" header="Score" :sortable="true">
                                    <template #body="{ data }">
                                        <span 
                                            class="score-cell"
                                            :class="getRankingClass(data.copropiedad_id, 'best_precession')"
                                        >
                                            {{ (data.precession_score || 0).toFixed(1) }}
                                        </span>
                                    </template>
                                </Column>
                                <Column field="risk_score" header="Riesgo" :sortable="true">
                                    <template #body="{ data }">
                                        <span 
                                            class="score-cell"
                                            :class="getRankingClass(data.copropiedad_id, 'lowest_risk')"
                                        >
                                            {{ formatPercent(data.risk_score) }}
                                        </span>
                                    </template>
                                </Column>
                                <Column field="opportunity_score" header="Oportunidad" :sortable="true">
                                    <template #body="{ data }">
                                        <span 
                                            class="score-cell"
                                            :class="getRankingClass(data.copropiedad_id, 'best_opportunity')"
                                        >
                                            {{ formatPercent(data.opportunity_score) }}
                                        </span>
                                    </template>
                                </Column>
                                <Column field="total_value_uf" header="Valor UF" :sortable="true">
                                    <template #body="{ data }">
                                        <span 
                                            class="value-cell"
                                            :class="getRankingClass(data.copropiedad_id, 'highest_value')"
                                        >
                                            {{ formatUf(data.total_value_uf) }}
                                        </span>
                                    </template>
                                </Column>
                                <Column field="confidence" header="Confianza" :sortable="true">
                                    <template #body="{ data }">
                                        <ProgressBar 
                                            :value="(data.confidence || 0) * 100" 
                                            :showValue="true"
                                            class="confidence-bar"
                                        />
                                    </template>
                                </Column>
                                <Column header="Acciones">
                                    <template #body="{ data }">
                                        <Button 
                                            icon="pi pi-external-link"
                                            class="p-button-rounded p-button-text p-button-sm"
                                            v-tooltip="'Ver Dashboard'"
                                            @click="router.push(`/pae/dashboard/${data.copropiedad_id}`)"
                                        />
                                    </template>
                                </Column>
                            </DataTable>
                        </template>
                    </Card>
                </template>
            </div>
        </div>
    </div>
</template>

<style scoped>
.pae-compare {
    padding: 1.5rem;
}

.page-header {
    margin-bottom: 1.5rem;
}

.header-left {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.header-info h1 {
    margin: 0;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.header-info h1 i {
    color: #8b5cf6;
}

.header-info p {
    margin: 0.25rem 0 0;
    color: var(--text-muted);
}

.compare-layout {
    display: grid;
    grid-template-columns: 320px 1fr;
    gap: 1.5rem;
}

.selection-card {
    position: sticky;
    top: 1rem;
    height: fit-content;
}

.selection-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.copropiedades-list {
    max-height: 400px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.copropiedad-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.5rem;
    border-radius: var(--border-radius);
    transition: background 0.2s;
}

.copropiedad-item:hover {
    background: var(--bg-secondary);
}

.copropiedad-item.selected {
    background: rgba(139, 92, 246, 0.1);
}

.copropiedad-label {
    display: flex;
    flex-direction: column;
    cursor: pointer;
    flex: 1;
}

.copropiedad-name {
    font-weight: 500;
}

.copropiedad-comuna {
    font-size: 0.75rem;
    color: var(--text-muted);
}

.selection-actions {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-top: 1rem;
}

.results-area {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.empty-card {
    min-height: 400px;
}

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 3rem;
    text-align: center;
}

.empty-state i {
    font-size: 4rem;
    color: var(--text-muted);
    margin-bottom: 1rem;
}

.empty-state h2 {
    margin: 0 0 0.5rem;
}

.empty-state p {
    color: var(--text-muted);
    max-width: 400px;
}

.empty-state .hint {
    font-size: 0.875rem;
    margin-top: 1rem;
}

/* Aggregates */
.aggregates-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
}

.aggregate-card {
    border-radius: var(--border-radius-lg);
}

.aggregate-content {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.aggregate-content i {
    font-size: 2rem;
    color: #8b5cf6;
}

.aggregate-card.risk i { color: #ef4444; }
.aggregate-card.opportunity i { color: #22c55e; }

.aggregate-info {
    display: flex;
    flex-direction: column;
}

.aggregate-label {
    font-size: 0.875rem;
    color: var(--text-muted);
}

.aggregate-value {
    font-size: 1.5rem;
    font-weight: 700;
}

/* Rankings */
.rankings-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
}

.ranking-item {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);
}

.ranking-label {
    font-size: 0.75rem;
    color: var(--text-muted);
    text-transform: uppercase;
}

.ranking-value {
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.ranking-item.best .ranking-value i {
    color: #f59e0b;
}

/* Charts */
.charts-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.chart-container {
    height: 300px;
}

/* Entity cell */
.entity-cell {
    display: flex;
    flex-direction: column;
}

.entity-name {
    font-weight: 500;
}

.entity-address {
    font-size: 0.75rem;
    color: var(--text-muted);
}

.score-cell,
.value-cell {
    font-weight: 500;
}

.ranking-best {
    color: #22c55e;
    font-weight: 700;
}

.ranking-bad {
    color: #ef4444;
}

.confidence-bar {
    height: 8px;
}

@media (max-width: 1200px) {
    .compare-layout {
        grid-template-columns: 1fr;
    }
    
    .selection-card {
        position: static;
    }
    
    .aggregates-grid,
    .rankings-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .charts-grid {
        grid-template-columns: 1fr;
    }
}
</style>
