<script setup>
/**
 * PAE Dashboard - Precession Analytics Engine
 * 
 * Dashboard de análisis precesional basado en la teoría de
 * precesión sistémica de R. Buckminster Fuller.
 * 
 * Muestra:
 * - Scores precesionales (riesgo, oportunidad, confianza)
 * - Valores UF por ángulo (0°, 45°, 90°, 135°, 180°)
 * - Gráfico radar de efectos
 * - Alertas activas
 * - Predicciones ML
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx
 */
import { ref, computed, onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useToast } from 'primevue/usetoast';
import api from '@/services/api';

const route = useRoute();
const router = useRouter();
const toast = useToast();

// Estado
const isLoading = ref(true);
const isAnalyzing = ref(false);
const dashboard = ref(null);
const copropiedadId = ref(null);
const showAnalyzeDialog = ref(false);

// Parámetros de análisis
const analyzeParams = ref({
    horizon: 36,
    radius: 1000,
    max_depth: 4,
    include_ml: true,
    generate_heatmap: true,
    force_refresh: false,
});

// Opciones
const horizonOptions = [
    { label: '12 meses', value: 12 },
    { label: '24 meses', value: 24 },
    { label: '36 meses', value: 36 },
    { label: '60 meses', value: 60 },
];

const radiusOptions = [
    { label: '500m', value: 500 },
    { label: '1km', value: 1000 },
    { label: '2km', value: 2000 },
    { label: '5km', value: 5000 },
];

// Colores por ángulo precesional
const angleColors = {
    direct_0: '#22c55e',      // Verde - Directo
    induced_45: '#3b82f6',    // Azul - Inducido
    precession_90: '#8b5cf6', // Violeta - Precesional
    systemic_135: '#f59e0b',  // Naranja - Sistémico
    counter_180: '#ef4444',   // Rojo - Contra-precesión
};

const angleLabels = {
    direct_0: 'Directo (0°)',
    induced_45: 'Inducido (45°)',
    precession_90: 'Precesional (90°)',
    systemic_135: 'Sistémico (135°)',
    counter_180: 'Contra-Precesión (180°)',
};

onMounted(async () => {
    copropiedadId.value = route.params.copropiedadId || route.query.copropiedadId;
    if (copropiedadId.value) {
        await loadDashboard();
    } else {
        isLoading.value = false;
    }
});

async function loadDashboard() {
    isLoading.value = true;
    try {
        const response = await api.get(`/pae/dashboard/${copropiedadId.value}`);
        dashboard.value = response.data.data;
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudo cargar el dashboard PAE',
            life: 5000,
        });
    } finally {
        isLoading.value = false;
    }
}

async function runAnalysis() {
    isAnalyzing.value = true;
    try {
        await api.post(`/pae/analyze/copropiedad/${copropiedadId.value}`, analyzeParams.value);
        
        toast.add({
            severity: 'success',
            summary: 'Análisis completado',
            detail: 'El análisis precesional se ha ejecutado correctamente',
            life: 3000,
        });
        
        showAnalyzeDialog.value = false;
        await loadDashboard();
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: error.response?.data?.message || 'Error ejecutando análisis',
            life: 5000,
        });
    } finally {
        isAnalyzing.value = false;
    }
}

// Computed
const hasAnalysis = computed(() => dashboard.value?.has_analysis);

const scores = computed(() => dashboard.value?.scores || {});

const valuesUf = computed(() => dashboard.value?.values_uf || {});

const alerts = computed(() => dashboard.value?.alerts || []);

const predictions = computed(() => dashboard.value?.ml_predictions || {});

// Datos para gráfico radar
const radarData = computed(() => {
    if (!hasAnalysis.value) return null;
    
    const effects = dashboard.value?.effects_summary || {};
    
    return {
        labels: Object.keys(effects).map(k => angleLabels[k] || k),
        datasets: [
            {
                label: 'Efectos por Ángulo',
                data: Object.values(effects).map(e => e.count || 0),
                backgroundColor: 'rgba(139, 92, 246, 0.2)',
                borderColor: '#8b5cf6',
                pointBackgroundColor: '#8b5cf6',
            },
        ],
    };
});

const radarOptions = {
    responsive: true,
    plugins: {
        legend: {
            display: false,
        },
    },
    scales: {
        r: {
            beginAtZero: true,
            grid: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
            angleLines: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
            pointLabels: {
                color: '#9ca3af',
            },
        },
    },
};

// Datos para gráfico de barras de valores
const valuesChartData = computed(() => {
    if (!hasAnalysis.value) return null;
    
    const values = dashboard.value?.values_uf || {};
    
    return {
        labels: ['Directo', 'Inducido', 'Precesional', 'Sistémico', 'Contra'],
        datasets: [
            {
                label: 'Valor UF',
                data: [
                    values.direct || 0,
                    values.induced || 0,
                    values.precession || 0,
                    values.systemic || 0,
                    values.counter || 0,
                ],
                backgroundColor: Object.values(angleColors),
            },
        ],
    };
});

const valuesChartOptions = {
    responsive: true,
    plugins: {
        legend: {
            display: false,
        },
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(255, 255, 255, 0.1)',
            },
        },
        x: {
            grid: {
                display: false,
            },
        },
    },
};

// Helpers
function getRiskClass(score) {
    if (score >= 0.8) return 'risk-critical';
    if (score >= 0.6) return 'risk-high';
    if (score >= 0.4) return 'risk-medium';
    return 'risk-low';
}

function getOpportunityClass(score) {
    if (score >= 0.8) return 'opportunity-exceptional';
    if (score >= 0.6) return 'opportunity-high';
    if (score >= 0.4) return 'opportunity-moderate';
    return 'opportunity-limited';
}

function getSeverityClass(severity) {
    return {
        'critical': 'danger',
        'high': 'warning',
        'medium': 'info',
        'low': 'secondary',
    }[severity] || 'secondary';
}

function formatUf(value) {
    if (!value) return '0 UF';
    return new Intl.NumberFormat('es-CL').format(value) + ' UF';
}

function formatPercent(value) {
    if (!value && value !== 0) return '-';
    return (value * 100).toFixed(1) + '%';
}

function formatDate(date) {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('es-CL', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}
</script>

<template>
    <div class="pae-dashboard">
        <!-- Header -->
        <div class="page-header">
            <div class="header-left">
                <Button 
                    icon="pi pi-arrow-left" 
                    class="p-button-text"
                    @click="router.back()"
                />
                <div class="header-info">
                    <h1>
                        <i class="pi pi-sitemap"></i>
                        PAE - Precession Analytics Engine
                    </h1>
                    <p v-if="dashboard?.copropiedad">
                        {{ dashboard.copropiedad.nombre }} • {{ dashboard.copropiedad.direccion }}
                    </p>
                </div>
            </div>
            <div class="header-actions">
                <Button 
                    label="Nuevo Análisis"
                    icon="pi pi-refresh"
                    @click="showAnalyzeDialog = true"
                    :disabled="!copropiedadId"
                />
            </div>
        </div>

        <!-- Loading -->
        <div v-if="isLoading" class="loading-container">
            <ProgressSpinner />
            <p>Cargando dashboard precesional...</p>
        </div>

        <!-- No Copropiedad Selected -->
        <div v-else-if="!copropiedadId" class="empty-state">
            <i class="pi pi-building"></i>
            <h2>Selecciona una Copropiedad</h2>
            <p>Para ver el análisis precesional, selecciona primero una copropiedad.</p>
            <Button 
                label="Ir a Copropiedades"
                icon="pi pi-arrow-right"
                @click="router.push('/proptech/copropiedades')"
            />
        </div>

        <!-- No Analysis -->
        <div v-else-if="!hasAnalysis" class="no-analysis">
            <Card>
                <template #content>
                    <div class="empty-state">
                        <i class="pi pi-chart-scatter"></i>
                        <h2>Sin Análisis Precesional</h2>
                        <p>No existe un análisis precesional válido para esta copropiedad.</p>
                        <p class="text-muted">
                            Ejecute un nuevo análisis para obtener insights sobre efectos 
                            precesionales basados en la teoría de R. Buckminster Fuller.
                        </p>
                        <Button 
                            label="Ejecutar Análisis"
                            icon="pi pi-play"
                            @click="showAnalyzeDialog = true"
                        />
                    </div>
                </template>
            </Card>
        </div>

        <!-- Dashboard Content -->
        <template v-else>
            <!-- Scores Grid -->
            <div class="scores-grid">
                <!-- Precession Score -->
                <Card class="score-card precession">
                    <template #content>
                        <div class="score-content">
                            <div class="score-icon">
                                <i class="pi pi-sitemap"></i>
                            </div>
                            <div class="score-info">
                                <span class="score-label">Score Precesional</span>
                                <span class="score-value">{{ scores.precession?.toFixed(1) || 0 }}</span>
                            </div>
                            <Knob 
                                v-model="scores.precession" 
                                :max="100"
                                :size="80"
                                readonly
                                valueColor="#8b5cf6"
                            />
                        </div>
                    </template>
                </Card>

                <!-- Risk Score -->
                <Card class="score-card" :class="getRiskClass(scores.risk)">
                    <template #content>
                        <div class="score-content">
                            <div class="score-icon risk">
                                <i class="pi pi-exclamation-triangle"></i>
                            </div>
                            <div class="score-info">
                                <span class="score-label">Riesgo</span>
                                <span class="score-value">{{ formatPercent(scores.risk) }}</span>
                            </div>
                            <ProgressBar 
                                :value="(scores.risk || 0) * 100" 
                                :showValue="false"
                                class="risk-bar"
                            />
                        </div>
                    </template>
                </Card>

                <!-- Opportunity Score -->
                <Card class="score-card" :class="getOpportunityClass(scores.opportunity)">
                    <template #content>
                        <div class="score-content">
                            <div class="score-icon opportunity">
                                <i class="pi pi-star"></i>
                            </div>
                            <div class="score-info">
                                <span class="score-label">Oportunidad</span>
                                <span class="score-value">{{ formatPercent(scores.opportunity) }}</span>
                            </div>
                            <ProgressBar 
                                :value="(scores.opportunity || 0) * 100" 
                                :showValue="false"
                                class="opportunity-bar"
                            />
                        </div>
                    </template>
                </Card>

                <!-- Confidence -->
                <Card class="score-card confidence">
                    <template #content>
                        <div class="score-content">
                            <div class="score-icon">
                                <i class="pi pi-verified"></i>
                            </div>
                            <div class="score-info">
                                <span class="score-label">Confianza</span>
                                <span class="score-value">{{ formatPercent(scores.confidence) }}</span>
                            </div>
                        </div>
                    </template>
                </Card>
            </div>

            <!-- Main Content Grid -->
            <div class="main-grid">
                <!-- Values by Angle -->
                <Card class="values-card">
                    <template #title>
                        <i class="pi pi-chart-bar"></i>
                        Valor Precesional por Ángulo
                    </template>
                    <template #subtitle>
                        Total: {{ formatUf(valuesUf.total) }}
                    </template>
                    <template #content>
                        <div class="values-grid">
                            <div 
                                v-for="(value, angle) in valuesUf" 
                                :key="angle"
                                v-if="angle !== 'total'"
                                class="value-item"
                            >
                                <div 
                                    class="value-indicator"
                                    :style="{ backgroundColor: angleColors[angle] }"
                                ></div>
                                <div class="value-info">
                                    <span class="value-label">{{ angleLabels[angle] || angle }}</span>
                                    <span class="value-amount">{{ formatUf(value) }}</span>
                                </div>
                            </div>
                        </div>
                        
                        <Chart 
                            v-if="valuesChartData"
                            type="bar" 
                            :data="valuesChartData" 
                            :options="valuesChartOptions"
                            class="values-chart"
                        />
                    </template>
                </Card>

                <!-- Radar Chart -->
                <Card class="radar-card">
                    <template #title>
                        <i class="pi pi-chart-pie"></i>
                        Distribución de Efectos
                    </template>
                    <template #content>
                        <Chart 
                            v-if="radarData"
                            type="radar" 
                            :data="radarData" 
                            :options="radarOptions"
                            class="radar-chart"
                        />
                    </template>
                </Card>

                <!-- Alerts -->
                <Card class="alerts-card">
                    <template #title>
                        <i class="pi pi-bell"></i>
                        Alertas Activas
                        <Badge 
                            v-if="alerts.length > 0"
                            :value="alerts.length"
                            severity="danger"
                        />
                    </template>
                    <template #content>
                        <div v-if="alerts.length === 0" class="no-alerts">
                            <i class="pi pi-check-circle"></i>
                            <p>Sin alertas activas</p>
                        </div>
                        <div v-else class="alerts-list">
                            <div 
                                v-for="alert in alerts.slice(0, 5)" 
                                :key="alert.id"
                                class="alert-item"
                            >
                                <Tag 
                                    :value="alert.severity"
                                    :severity="getSeverityClass(alert.severity)"
                                />
                                <div class="alert-content">
                                    <span class="alert-title">{{ alert.title }}</span>
                                    <span class="alert-type">{{ alert.alert_type }}</span>
                                </div>
                            </div>
                        </div>
                        <Button 
                            v-if="alerts.length > 5"
                            label="Ver todas"
                            class="p-button-text p-button-sm"
                            @click="router.push('/pae/alerts')"
                        />
                    </template>
                </Card>

                <!-- ML Predictions -->
                <Card class="predictions-card">
                    <template #title>
                        <i class="pi pi-chart-line"></i>
                        Predicciones ML
                    </template>
                    <template #content>
                        <div v-if="!predictions || Object.keys(predictions).length === 0" class="no-predictions">
                            <p>Sin predicciones disponibles</p>
                        </div>
                        <div v-else class="predictions-list">
                            <div 
                                v-for="(value, horizon) in predictions" 
                                :key="horizon"
                                class="prediction-item"
                            >
                                <span class="prediction-horizon">{{ horizon }}</span>
                                <ProgressBar 
                                    :value="Math.abs(value) * 100" 
                                    :showValue="false"
                                    :class="value >= 0 ? 'positive' : 'negative'"
                                />
                                <span 
                                    class="prediction-value"
                                    :class="value >= 0 ? 'positive' : 'negative'"
                                >
                                    {{ value >= 0 ? '+' : '' }}{{ (value * 100).toFixed(1) }}%
                                </span>
                            </div>
                        </div>
                    </template>
                </Card>
            </div>

            <!-- Meta Info -->
            <div class="meta-info">
                <span>
                    <i class="pi pi-calendar"></i>
                    Análisis: {{ formatDate(dashboard.analysis_date) }}
                </span>
                <span>
                    <i class="pi pi-clock"></i>
                    Expira: {{ formatDate(dashboard.expires_at) }}
                </span>
            </div>
        </template>

        <!-- Dialog Nuevo Análisis -->
        <Dialog 
            v-model:visible="showAnalyzeDialog"
            header="Ejecutar Análisis Precesional"
            :modal="true"
            :style="{ width: '500px' }"
        >
            <div class="analyze-form">
                <div class="form-group">
                    <label>Horizonte Temporal</label>
                    <Dropdown 
                        v-model="analyzeParams.horizon"
                        :options="horizonOptions"
                        optionLabel="label"
                        optionValue="value"
                        class="w-full"
                    />
                </div>

                <div class="form-group">
                    <label>Radio de Análisis</label>
                    <Dropdown 
                        v-model="analyzeParams.radius"
                        :options="radiusOptions"
                        optionLabel="label"
                        optionValue="value"
                        class="w-full"
                    />
                </div>

                <div class="form-group">
                    <label>Profundidad Máxima</label>
                    <Slider 
                        v-model="analyzeParams.max_depth"
                        :min="1"
                        :max="6"
                        :step="1"
                    />
                    <span class="slider-value">{{ analyzeParams.max_depth }} niveles</span>
                </div>

                <div class="form-row">
                    <div class="form-check">
                        <Checkbox 
                            v-model="analyzeParams.include_ml"
                            :binary="true"
                            inputId="include_ml"
                        />
                        <label for="include_ml">Incluir predicciones ML</label>
                    </div>
                    <div class="form-check">
                        <Checkbox 
                            v-model="analyzeParams.generate_heatmap"
                            :binary="true"
                            inputId="generate_heatmap"
                        />
                        <label for="generate_heatmap">Generar heatmap</label>
                    </div>
                </div>

                <div class="form-check">
                    <Checkbox 
                        v-model="analyzeParams.force_refresh"
                        :binary="true"
                        inputId="force_refresh"
                    />
                    <label for="force_refresh">Forzar nuevo análisis (ignorar cache)</label>
                </div>
            </div>

            <template #footer>
                <Button 
                    label="Cancelar" 
                    icon="pi pi-times" 
                    class="p-button-text" 
                    @click="showAnalyzeDialog = false"
                    :disabled="isAnalyzing"
                />
                <Button 
                    label="Ejecutar Análisis" 
                    icon="pi pi-play" 
                    @click="runAnalysis"
                    :loading="isAnalyzing"
                />
            </template>
        </Dialog>
    </div>
</template>

<style scoped>
.pae-dashboard {
    padding: 1.5rem;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1.5rem;
}

.header-left {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.header-info h1 {
    margin: 0;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.header-info h1 i {
    color: #8b5cf6;
}

.header-info p {
    margin: 0.25rem 0 0;
    color: var(--text-muted);
}

.loading-container,
.empty-state,
.no-analysis {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 3rem;
    text-align: center;
}

.empty-state i,
.no-analysis i {
    font-size: 4rem;
    color: var(--text-muted);
    margin-bottom: 1rem;
}

.empty-state h2 {
    margin: 0 0 0.5rem;
}

.empty-state p {
    color: var(--text-muted);
    margin-bottom: 1.5rem;
}

/* Scores Grid */
.scores-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.score-card {
    border-radius: var(--border-radius-lg);
}

.score-content {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.score-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(139, 92, 246, 0.1);
}

.score-icon i {
    font-size: 1.5rem;
    color: #8b5cf6;
}

.score-icon.risk { background: rgba(239, 68, 68, 0.1); }
.score-icon.risk i { color: #ef4444; }

.score-icon.opportunity { background: rgba(34, 197, 94, 0.1); }
.score-icon.opportunity i { color: #22c55e; }

.score-info {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.score-label {
    font-size: 0.875rem;
    color: var(--text-muted);
}

.score-value {
    font-size: 1.5rem;
    font-weight: 700;
}

/* Main Grid */
.main-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.values-card,
.radar-card,
.alerts-card,
.predictions-card {
    border-radius: var(--border-radius-lg);
}

.values-grid {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

.value-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.value-indicator {
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

.value-info {
    flex: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.value-label {
    font-size: 0.875rem;
}

.value-amount {
    font-weight: 600;
}

.values-chart,
.radar-chart {
    height: 200px;
}

/* Alerts */
.no-alerts {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 2rem;
    color: var(--success-color);
}

.no-alerts i {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}

.alerts-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.alert-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.5rem;
    background: var(--bg-secondary);
    border-radius: var(--border-radius);
}

.alert-content {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.alert-title {
    font-weight: 500;
}

.alert-type {
    font-size: 0.75rem;
    color: var(--text-muted);
}

/* Predictions */
.predictions-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.prediction-item {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.prediction-horizon {
    width: 60px;
    font-weight: 500;
}

.prediction-item .p-progressbar {
    flex: 1;
    height: 8px;
}

.prediction-value {
    width: 60px;
    text-align: right;
    font-weight: 600;
}

.prediction-value.positive { color: #22c55e; }
.prediction-value.negative { color: #ef4444; }

/* Meta Info */
.meta-info {
    display: flex;
    justify-content: center;
    gap: 2rem;
    color: var(--text-muted);
    font-size: 0.875rem;
}

.meta-info span {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* Form */
.analyze-form {
    display: flex;
    flex-direction: column;
    gap: 1.25rem;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-group label {
    font-weight: 500;
}

.slider-value {
    font-size: 0.875rem;
    color: var(--text-muted);
}

.form-row {
    display: flex;
    gap: 2rem;
}

.form-check {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* Risk/Opportunity Classes */
.risk-critical { --accent-color: #dc2626; }
.risk-high { --accent-color: #f59e0b; }
.risk-medium { --accent-color: #3b82f6; }
.risk-low { --accent-color: #22c55e; }

.opportunity-exceptional { --accent-color: #22c55e; }
.opportunity-high { --accent-color: #3b82f6; }
.opportunity-moderate { --accent-color: #f59e0b; }
.opportunity-limited { --accent-color: #6b7280; }

@media (max-width: 1200px) {
    .scores-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .main-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .scores-grid {
        grid-template-columns: 1fr;
    }
    
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }
}
</style>
