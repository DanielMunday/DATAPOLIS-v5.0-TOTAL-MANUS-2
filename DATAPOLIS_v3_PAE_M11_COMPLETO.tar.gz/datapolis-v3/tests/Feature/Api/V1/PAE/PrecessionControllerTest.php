<?php

namespace Tests\Feature\Api\V1\PAE;

use Tests\TestCase;
use App\Models\Core\Tenant;
use App\Models\Core\User;
use App\Models\PropTech\Copropiedad;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Services\PrecessionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Laravel\Sanctum\Sanctum;

class PrecessionControllerTest extends TestCase
{
    use RefreshDatabase;

    protected Tenant $tenant;
    protected User $user;
    protected Copropiedad $copropiedad;

    protected function setUp(): void
    {
        parent::setUp();

        $this->tenant = Tenant::factory()->create([
            'estado' => 'activo',
        ]);

        $this->user = User::factory()->create([
            'tenant_id' => $this->tenant->id,
        ]);

        $this->copropiedad = Copropiedad::factory()->create([
            'tenant_id' => $this->tenant->id,
            'latitud' => -33.4489,
            'longitud' => -70.6693,
            'comuna' => 'Santiago',
        ]);

        Sanctum::actingAs($this->user);
    }

    /** @test */
    public function puede_ejecutar_analisis_precesional()
    {
        // Mock del PAE Core API
        Http::fake([
            '*/pae/analyze' => Http::response([
                'total_precession_value' => 125.5,
                'risk_score' => 0.35,
                'opportunity_score' => 0.72,
                'confidence' => 0.85,
                'total_value_uf' => 15000,
                'direct_value_uf' => 5000,
                'induced_value_uf' => 3000,
                'precession_value_uf' => 4000,
                'systemic_value_uf' => 2000,
                'counter_value_uf' => 1000,
                'direct_effects' => [],
                'induced_effects' => [],
                'precession_effects' => [],
                'systemic_effects' => [],
                'counter_effects' => [],
                'ml_predictions' => ['12m' => 0.15, '24m' => 0.22],
            ], 200),
        ]);

        $response = $this->postJson("/api/v1/pae/analyze/copropiedad/{$this->copropiedad->id}", [
            'horizon' => 36,
            'radius' => 1000,
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'success',
                'data' => [
                    'id',
                    'copropiedad_id',
                    'analysis_type',
                    'status',
                    'scores' => [
                        'precession',
                        'risk',
                        'opportunity',
                    ],
                    'values_uf' => [
                        'total',
                        'direct_0',
                        'induced_45',
                        'precession_90',
                    ],
                ],
            ]);

        $this->assertDatabaseHas('precession_analyses', [
            'copropiedad_id' => $this->copropiedad->id,
            'status' => 'completed',
        ]);
    }

    /** @test */
    public function puede_obtener_dashboard_precesional()
    {
        // Crear análisis existente
        $analysis = PrecessionAnalysis::create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'analysis_type' => 'copropiedad_precession',
            'status' => 'completed',
            'precession_score' => 75.5,
            'risk_score' => 0.3,
            'opportunity_score' => 0.7,
            'confidence' => 0.85,
            'total_precession_value_uf' => 10000,
            'completed_at' => now(),
            'expires_at' => now()->addDays(1),
        ]);

        $response = $this->getJson("/api/v1/pae/dashboard/{$this->copropiedad->id}");

        $response->assertStatus(200)
            ->assertJsonPath('data.has_analysis', true)
            ->assertJsonPath('data.scores.precession', 75.5)
            ->assertJsonPath('data.scores.risk', 0.3)
            ->assertJsonPath('data.scores.opportunity', 0.7);
    }

    /** @test */
    public function retorna_mensaje_si_no_hay_analisis()
    {
        $response = $this->getJson("/api/v1/pae/dashboard/{$this->copropiedad->id}");

        $response->assertStatus(200)
            ->assertJsonPath('data.has_analysis', false);
    }

    /** @test */
    public function puede_obtener_alertas_activas()
    {
        // Crear alertas
        PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'alert_type' => 'risk_threshold',
            'severity' => 'high',
            'title' => 'Riesgo alto detectado',
            'description' => 'Descripción de la alerta',
            'status' => 'active',
        ]);

        PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'alert_type' => 'opportunity_detected',
            'severity' => 'medium',
            'title' => 'Oportunidad detectada',
            'description' => 'Descripción de oportunidad',
            'status' => 'active',
        ]);

        $response = $this->getJson('/api/v1/pae/alerts');

        $response->assertStatus(200)
            ->assertJsonCount(2, 'data');
    }

    /** @test */
    public function puede_filtrar_alertas_por_severidad()
    {
        PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'alert_type' => 'risk_threshold',
            'severity' => 'critical',
            'title' => 'Alerta crítica',
            'description' => 'Descripción',
            'status' => 'active',
        ]);

        PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'alert_type' => 'opportunity_detected',
            'severity' => 'low',
            'title' => 'Alerta baja',
            'description' => 'Descripción',
            'status' => 'active',
        ]);

        $response = $this->getJson('/api/v1/pae/alerts?severity=critical');

        $response->assertStatus(200)
            ->assertJsonCount(1, 'data');
    }

    /** @test */
    public function puede_reconocer_alerta()
    {
        $alert = PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'alert_type' => 'risk_threshold',
            'severity' => 'high',
            'title' => 'Alerta de prueba',
            'description' => 'Descripción',
            'status' => 'active',
        ]);

        $response = $this->postJson("/api/v1/pae/alerts/{$alert->id}/acknowledge");

        $response->assertStatus(200);

        $this->assertDatabaseHas('precession_alerts', [
            'id' => $alert->id,
            'status' => 'acknowledged',
            'acknowledged_by' => $this->user->id,
        ]);
    }

    /** @test */
    public function puede_resolver_alerta()
    {
        $alert = PrecessionAlert::create([
            'tenant_id' => $this->tenant->id,
            'alert_type' => 'risk_threshold',
            'severity' => 'high',
            'title' => 'Alerta de prueba',
            'description' => 'Descripción',
            'status' => 'acknowledged',
        ]);

        $response = $this->postJson("/api/v1/pae/alerts/{$alert->id}/resolve", [
            'resolution_notes' => 'Problema resuelto correctamente',
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('precession_alerts', [
            'id' => $alert->id,
            'status' => 'resolved',
            'resolution_notes' => 'Problema resuelto correctamente',
        ]);
    }

    /** @test */
    public function puede_calcular_investment_score()
    {
        // Crear análisis previo
        PrecessionAnalysis::create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'analysis_type' => 'copropiedad_precession',
            'status' => 'completed',
            'precession_score' => 75,
            'risk_score' => 0.3,
            'opportunity_score' => 0.7,
            'completed_at' => now(),
            'expires_at' => now()->addDays(1),
        ]);

        $response = $this->postJson('/api/v1/pae/investment-score', [
            'copropiedad_id' => $this->copropiedad->id,
            'cap_rate' => 6.5,
            'cash_on_cash' => 8.0,
            'ocupacion' => 95,
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'base_score',
                    'precession_adjustment',
                    'final_score',
                    'risk_level',
                    'opportunity_level',
                    'precession_effects',
                    'recommendations',
                ],
            ]);
    }

    /** @test */
    public function puede_comparar_copropiedades()
    {
        $copropiedad2 = Copropiedad::factory()->create([
            'tenant_id' => $this->tenant->id,
        ]);

        // Mock del PAE Core API
        Http::fake([
            '*/pae/analyze' => Http::response([
                'total_precession_value' => 100,
                'risk_score' => 0.4,
                'opportunity_score' => 0.6,
                'confidence' => 0.8,
            ], 200),
        ]);

        $response = $this->postJson('/api/v1/pae/compare', [
            'copropiedad_ids' => [
                $this->copropiedad->id,
                $copropiedad2->id,
            ],
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'entities',
                    'rankings',
                    'aggregates',
                ],
            ]);
    }

    /** @test */
    public function valida_minimo_2_copropiedades_para_comparar()
    {
        $response = $this->postJson('/api/v1/pae/compare', [
            'copropiedad_ids' => [$this->copropiedad->id],
        ]);

        $response->assertStatus(422)
            ->assertJsonValidationErrors(['copropiedad_ids']);
    }

    /** @test */
    public function puede_generar_reporte_inversionista()
    {
        $analysis = PrecessionAnalysis::create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'analysis_type' => 'copropiedad_precession',
            'status' => 'completed',
            'precession_score' => 80,
            'risk_score' => 0.25,
            'opportunity_score' => 0.75,
            'confidence' => 0.9,
            'total_precession_value_uf' => 20000,
            'ml_predictions' => ['12m' => 0.12, '24m' => 0.25],
            'completed_at' => now(),
            'expires_at' => now()->addDays(1),
        ]);

        $response = $this->getJson("/api/v1/pae/report/{$this->copropiedad->id}");

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'generated_at',
                    'copropiedad',
                    'executive_summary',
                    'scores',
                    'value_analysis',
                    'risk_assessment',
                    'opportunities',
                    'recommendations',
                ],
            ]);
    }

    /** @test */
    public function puede_obtener_heatmap()
    {
        // Crear varios análisis con ubicaciones
        for ($i = 0; $i < 5; $i++) {
            PrecessionAnalysis::create([
                'tenant_id' => $this->tenant->id,
                'analysis_type' => 'copropiedad_precession',
                'status' => 'completed',
                'latitud' => -33.44 + ($i * 0.01),
                'longitud' => -70.66 + ($i * 0.01),
                'precession_score' => rand(50, 100),
                'completed_at' => now(),
                'expires_at' => now()->addDays(1),
            ]);
        }

        $response = $this->getJson('/api/v1/pae/heatmap?' . http_build_query([
            'minLat' => -33.5,
            'minLng' => -70.8,
            'maxLat' => -33.3,
            'maxLng' => -70.5,
        ]));

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'points',
                    'total_analyses',
                    'bounds',
                ],
            ]);
    }
}

namespace Tests\Unit\Services;

use Tests\TestCase;
use App\Services\PrecessionService;
use App\Models\Core\Tenant;
use App\Models\PropTech\Copropiedad;
use App\Models\PAE\PrecessionAnalysis;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;

class PrecessionServiceTest extends TestCase
{
    use RefreshDatabase;

    protected PrecessionService $service;
    protected Tenant $tenant;
    protected Copropiedad $copropiedad;

    protected function setUp(): void
    {
        parent::setUp();

        $this->service = new PrecessionService();
        
        $this->tenant = Tenant::factory()->create();
        
        $this->copropiedad = Copropiedad::factory()->create([
            'tenant_id' => $this->tenant->id,
            'latitud' => -33.4489,
            'longitud' => -70.6693,
        ]);

        // Simular tenant context
        app()->instance('tenant', $this->tenant);
    }

    /** @test */
    public function calcula_investment_score_correctamente()
    {
        $result = $this->service->calculateInvestmentScore([
            'cap_rate' => 7.0,
            'cash_on_cash' => 10.0,
            'ocupacion' => 95,
        ]);

        $this->assertArrayHasKey('base_score', $result);
        $this->assertArrayHasKey('final_score', $result);
        $this->assertArrayHasKey('risk_level', $result);
        $this->assertArrayHasKey('opportunity_level', $result);

        // Verificar que el score está en rango válido
        $this->assertGreaterThanOrEqual(0, $result['base_score']);
        $this->assertLessThanOrEqual(100, $result['base_score']);
    }

    /** @test */
    public function categoriza_riesgo_correctamente()
    {
        $reflection = new \ReflectionClass($this->service);
        $method = $reflection->getMethod('categorizeRisk');
        $method->setAccessible(true);

        $this->assertEquals('critical', $method->invoke($this->service, 0.85));
        $this->assertEquals('high', $method->invoke($this->service, 0.65));
        $this->assertEquals('medium', $method->invoke($this->service, 0.45));
        $this->assertEquals('low', $method->invoke($this->service, 0.25));
        $this->assertEquals('minimal', $method->invoke($this->service, 0.1));
    }

    /** @test */
    public function categoriza_oportunidad_correctamente()
    {
        $reflection = new \ReflectionClass($this->service);
        $method = $reflection->getMethod('categorizeOpportunity');
        $method->setAccessible(true);

        $this->assertEquals('exceptional', $method->invoke($this->service, 0.85));
        $this->assertEquals('high', $method->invoke($this->service, 0.65));
        $this->assertEquals('moderate', $method->invoke($this->service, 0.45));
        $this->assertEquals('limited', $method->invoke($this->service, 0.25));
        $this->assertEquals('minimal', $method->invoke($this->service, 0.1));
    }

    /** @test */
    public function genera_recomendaciones_segun_analisis()
    {
        $analysis = new PrecessionAnalysis([
            'risk_score' => 0.75,
            'opportunity_score' => 0.8,
            'counter_value_uf' => -150000,
        ]);

        $reflection = new \ReflectionClass($this->service);
        $method = $reflection->getMethod('generateInvestmentRecommendations');
        $method->setAccessible(true);

        $recommendations = $method->invoke($this->service, $analysis, []);

        $this->assertNotEmpty($recommendations);
        $this->assertCount(3, $recommendations); // 3 condiciones cumplidas

        // Verificar que hay recomendaciones de warning y success
        $types = array_column($recommendations, 'type');
        $this->assertContains('warning', $types);
        $this->assertContains('success', $types);
        $this->assertContains('danger', $types);
    }
}
