from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
import logging

# Import routers
from app.routers import hedonic, ecosystem_services, natural_capital, valuation_advisor, env_hub

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="DATAPOLIS v4.0",
    description="Plataforma Integral PropTech + FinTech + RegTech + GovTech + ESG/Capital Natural",
    version="4.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers for v4.0 modules
app.include_router(hedonic.router, prefix="/api/v1", tags=["Hedonic Pricing"])
app.include_router(ecosystem_services.router, prefix="/api/v1", tags=["Ecosystem Services"])
app.include_router(natural_capital.router, prefix="/api/v1", tags=["Natural Capital"])
app.include_router(valuation_advisor.router, prefix="/api/v1", tags=["Valuation Advisor"])
app.include_router(env_hub.router, prefix="/api/v1", tags=["Environmental Data"])

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "version": "4.0.0",
        "modules": [
            "hedonic",
            "ecosystem_services",
            "natural_capital",
            "valuation_advisor",
            "env_hub"
        ]
    }

# Root endpoint
@app.get("/")
async def root():
    return {
        "name": "DATAPOLIS v4.0",
        "description": "Plataforma Integral PropTech + FinTech + RegTech + GovTech + ESG/Capital Natural",
        "version": "4.0.0",
        "docs": "/docs",
        "openapi": "/openapi.json"
    }

# Custom OpenAPI schema
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="DATAPOLIS v4.0 API",
        version="4.0.0",
        description="API completa para DATAPOLIS v4.0 con módulos de ESG y Capital Natural",
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "https://datapolis.io/logo.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
