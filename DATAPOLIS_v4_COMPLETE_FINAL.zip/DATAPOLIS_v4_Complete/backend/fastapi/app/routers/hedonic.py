from fastapi import APIRouter, HTTPException
from typing import Dict, List, Optional
from app.services.m_hedonic import hedonic_engine, HedonicModel
from app.schemas.hedonic import HedonicEstimateRequest, HedonicEstimateResponse
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/hedonic", tags=["Hedonic Pricing"])

@router.post("/estimate", response_model=HedonicEstimateResponse)
async def estimate_hedonic_model(request: HedonicEstimateRequest) -> Dict:
    """
    Estima un modelo hedónico de precios.
    
    - **prices**: Lista de precios observados
    - **features**: Diccionario con atributos y sus valores
    - **model_type**: Tipo de modelo (linear, log_linear, double_log, box_cox)
    - **spatial_weights**: Matriz de pesos espaciales (opcional)
    """
    try:
        results = hedonic_engine.estimate_hedonic_model(
            prices=request.prices,
            features=request.features,
            model_type=HedonicModel(request.model_type),
            spatial_weights=request.spatial_weights
        )
        return results
    except Exception as e:
        logger.error(f"Error en estimación hedónica: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/models")
async def get_available_models() -> Dict:
    """Retorna lista de modelos hedónicos disponibles"""
    return {
        "models": [model.value for model in HedonicModel],
        "descriptions": {
            "linear": "Modelo lineal simple",
            "log_linear": "Precio en log, atributos lineales",
            "double_log": "Precio y atributos en log (elasticidades)",
            "box_cox": "Transformación Box-Cox para optimalidad"
        }
    }

@router.post("/elasticities")
async def calculate_elasticities(request: HedonicEstimateRequest) -> Dict:
    """Calcula elasticidades de atributos"""
    try:
        results = hedonic_engine.estimate_hedonic_model(
            prices=request.prices,
            features=request.features,
            model_type=HedonicModel(request.model_type)
        )
        return {
            "elasticities": results['elasticities'],
            "interpretation": "Cambio porcentual en precio ante cambio 1% en atributo"
        }
    except Exception as e:
        logger.error(f"Error en cálculo de elasticidades: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
