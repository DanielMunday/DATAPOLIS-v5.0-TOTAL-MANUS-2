# DATAPOLIS v3.0

## Plataforma PropTech/FinTech/RegTech/GovTech para Chile

[![Build Status](https://github.com/datapolis/datapolis-v3/workflows/CI/badge.svg)](https://github.com/datapolis/datapolis-v3/actions)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-3.0.0-blue.svg)](VERSION)

---

## 🚀 Inicio Rápido

```bash
# 1. Clonar/Descomprimir
unzip DATAPOLIS_v3_Full.zip
cd DATAPOLIS_v3_Full

# 2. Validar completitud (100%)
bash scripts/validate_100_percent.sh

# 3. Desplegar
# Opción A: Local
bash scripts/deploy_local.sh

# Opción B: Docker
docker-compose up -d

# 4. Acceder
# Frontend: http://localhost:3000
# API Laravel: http://localhost:8000
# API FastAPI: http://localhost:8001
# Docs: http://localhost:8001/docs
```

---

## 📁 Estructura del Proyecto

```
DATAPOLIS_v3_Full/
├── backend/
│   ├── fastapi/                 # API ML/Analytics (Python)
│   │   ├── app/
│   │   │   ├── main.py
│   │   │   ├── config.py
│   │   │   ├── database.py
│   │   │   ├── routers/         # 29 módulos
│   │   │   ├── services/
│   │   │   └── schemas/
│   │   ├── openapi.yaml
│   │   └── requirements.txt
│   │
│   └── laravel/                 # API CRUD/PAE (PHP)
│       ├── app/
│       │   ├── Http/Controllers/Api/
│       │   ├── Models/
│       │   └── Services/
│       ├── database/migrations/
│       ├── routes/api.php
│       └── composer.json
│
├── frontend/                    # Vue.js 3 + TailwindCSS
│   ├── src/
│   │   ├── views/
│   │   ├── components/
│   │   └── router/
│   └── package.json
│
├── docs/                        # Documentación completa
│   ├── ARCHITECTURE.md
│   ├── API_REFERENCE.md
│   ├── DEPLOY_LOCAL.md
│   ├── DEPLOY_CPANEL.md
│   ├── INVERSORES_PRESENTACION.md
│   ├── CLIENTES_MANUAL_OPERATIVO.md
│   └── REGULADOR_CMF_514_CUMPLIMIENTO.md
│
├── tests/                       # Tests E2E y unitarios
│   └── test_e2e.py
│
├── ci/.github/workflows/        # CI/CD
│   └── ci.yml
│
├── scripts/                     # Automatización
│   ├── build_and_zip.sh
│   └── validate_100_percent.sh
│
├── docker-compose.yml
├── VERSION
└── README.md
```

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────────┐
│                         DATAPOLIS v3.0                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │ PROPTECH │  │ FINTECH  │  │ REGTECH  │  │ GOVTECH  │       │
│  │ M00-M09  │  │ M01-OF   │  │ M10-M16  │  │ M17,M22  │       │
│  │ MS       │  │ M03-M04  │  │ GT-PV    │  │ GIRES    │       │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘       │
│       │             │             │             │              │
│       └─────────────┴─────────────┴─────────────┘              │
│                           │                                     │
│  ┌────────────────────────┴────────────────────────┐           │
│  │              API Gateway (Kong/Nginx)           │           │
│  └────────────────────────┬────────────────────────┘           │
│                           │                                     │
│       ┌───────────────────┼───────────────────┐                │
│       │                   │                   │                │
│  ┌────┴────┐        ┌────┴────┐        ┌────┴────┐            │
│  │ FastAPI │        │ Laravel │        │  Vue.js │            │
│  │ ML/AI   │        │ CRUD/PAE│        │ Frontend│            │
│  └────┬────┘        └────┬────┘        └─────────┘            │
│       │                  │                                     │
│  ┌────┴──────────────────┴────┐                               │
│  │   PostgreSQL + PostGIS     │                               │
│  │   Redis (Cache/Sessions)   │                               │
│  └────────────────────────────┘                               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📦 Módulos

| Código | Nombre | Dominio | Descripción |
|--------|--------|---------|-------------|
| M00 | Expediente | PropTech | Gestión de expedientes inmobiliarios |
| M01 | Ficha Propiedad | PropTech | Fichas detalladas de propiedades |
| M02 | Copropiedad | PropTech | Gestión Ley 21.442 |
| M03 | Credit Scoring | FinTech | Scoring Basel IV (PD/LGD/EAD) |
| M04 | Valorización | FinTech | Avalúo ML |
| M05 | Arriendos | PropTech | Contratos y SCF |
| M06 | Mantenciones | PropTech | Gestión de mantenciones |
| M07 | Inversiones | FinTech | Análisis de inversión |
| M08 | Contabilidad | FinTech | IFRS y reportería |
| M01-OF | Open Finance | FinTech | NCG514 FAPI 2.0 |
| M11 | PAE | RegTech | Precession Analysis Engine |
| M13 | Garantías | FinTech | Colaterales Basel IV |
| M16 | Basel IV | RegTech | Motor regulatorio |
| M17 | GIRES | GovTech | Riesgos naturales |
| M22 | ÁGORA | GovTech | GeoViewer territorial |
| GT-PV | Plusvalías | RegTech | Ley 21.713 |
| IE | Indicadores | DataTech | UF, UTM, IPC, TPM |

---

## ⚙️ Requisitos

### Sistema
- Ubuntu 22.04+ / macOS 12+ / Windows 11 (WSL2)
- 8GB RAM mínimo (16GB recomendado)
- 20GB espacio en disco

### Software
- Python 3.11+
- PHP 8.2+
- Node.js 20+
- PostgreSQL 15+ con PostGIS 3.3
- Redis 7+

---

## 📖 Documentación

| Documento | Descripción |
|-----------|-------------|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Arquitectura técnica detallada |
| [API_REFERENCE.md](docs/API_REFERENCE.md) | Referencia de 450+ endpoints |
| [DEPLOY_LOCAL.md](docs/DEPLOY_LOCAL.md) | Guía de instalación local |
| [DEPLOY_CPANEL.md](docs/DEPLOY_CPANEL.md) | Guía para hosting cPanel |
| [INVERSORES_PRESENTACION.md](docs/INVERSORES_PRESENTACION.md) | Pitch para inversores |
| [CLIENTES_MANUAL_OPERATIVO.md](docs/CLIENTES_MANUAL_OPERATIVO.md) | Manual de usuario |
| [REGULADOR_CMF_514_CUMPLIMIENTO.md](docs/REGULADOR_CMF_514_CUMPLIMIENTO.md) | Compliance NCG514/Basel IV |

---

## 🧪 Tests

```bash
# Tests E2E
pytest tests/test_e2e.py -v

# Tests unitarios FastAPI
pytest backend/fastapi/tests/ -v

# Tests Laravel
cd backend/laravel && php artisan test

# Validación completa
bash scripts/validate_100_percent.sh
```

---

## 🚢 Despliegue

### Local (Desarrollo)
```bash
# Ver guía completa
cat docs/DEPLOY_LOCAL.md
```

### cPanel (Producción)
```bash
# Ver guía completa
cat docs/DEPLOY_CPANEL.md
```

### Docker
```bash
docker-compose up -d
```

---

## 📜 Licencia

Proprietary - DATAPOLIS SpA © 2026

---

## 📞 Contacto

- **Email**: info@datapolis.cl
- **Web**: https://datapolis.cl
- **Soporte**: soporte@datapolis.cl
