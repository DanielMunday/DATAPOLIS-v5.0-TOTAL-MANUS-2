"""
DATAPOLIS v3.0 - FastAPI Main Application
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(
    title="DATAPOLIS v3.0 API",
    description="PropTech/FinTech/RegTech/GovTech Platform",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "healthy", "version": "3.0.0"}

@app.get("/api/v1/health")
async def api_health():
    return {"status": "healthy", "version": "3.0.0"}

# Import routers (when available)
# from app.routers import expedientes, copropiedades, ...
