<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Copropiedad;
use App\Services\PAE\PaeService;
use Illuminate\Http\Request;

class CopropiedadController extends Controller
{
    protected PaeService $paeService;

    public function __construct(PaeService $paeService)
    {
        $this->paeService = $paeService;
    }

    /**
     * Lista paginada de copropiedades
     */
    public function index(Request $request)
    {
        $query = Copropiedad::query()
            ->where('tenant_id', $request->user()->tenant_id);

        if ($request->has('search')) {
            $query->where('nombre', 'like', '%' . $request->search . '%');
        }

        if ($request->has('comuna')) {
            $query->where('comuna', $request->comuna);
        }

        $copropiedades = $query->with(['unidades', 'antenas'])
            ->withCount('unidades')
            ->paginate($request->get('per_page', 15));

        return response()->json($copropiedades);
    }

    /**
     * Crear copropiedad
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'rut' => 'required|string|unique:copropiedades,rut',
            'direccion' => 'required|string|max:500',
            'comuna' => 'required|string|max:100',
            'region' => 'sometimes|string|max:100',
            'total_unidades' => 'sometimes|integer|min:1',
            'prorrateo_type' => 'sometimes|in:metros,alicuota,igual',
            'administrador_nombre' => 'sometimes|string',
            'administrador_email' => 'sometimes|email',
            'administrador_telefono' => 'sometimes|string',
        ]);

        $validated['tenant_id'] = $request->user()->tenant_id;
        $validated['created_by'] = $request->user()->id;

        $copropiedad = Copropiedad::create($validated);

        return response()->json($copropiedad, 201);
    }

    /**
     * Obtener copropiedad
     */
    public function show(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->with(['unidades', 'antenas', 'gastosComunes' => function($q) {
                $q->orderBy('created_at', 'desc')->limit(12);
            }])
            ->findOrFail($id);

        return response()->json($copropiedad);
    }

    /**
     * Actualizar copropiedad
     */
    public function update(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        $validated = $request->validate([
            'nombre' => 'sometimes|string|max:255',
            'direccion' => 'sometimes|string|max:500',
            'comuna' => 'sometimes|string|max:100',
            'region' => 'sometimes|string|max:100',
            'prorrateo_type' => 'sometimes|in:metros,alicuota,igual',
            'administrador_nombre' => 'sometimes|string',
            'administrador_email' => 'sometimes|email',
            'administrador_telefono' => 'sometimes|string',
        ]);

        $copropiedad->update($validated);

        return response()->json($copropiedad);
    }

    /**
     * Eliminar copropiedad
     */
    public function destroy(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        $copropiedad->delete();

        return response()->json(null, 204);
    }

    /**
     * Dashboard de copropiedad
     */
    public function dashboard(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->with(['unidades', 'antenas', 'gastosComunes'])
            ->findOrFail($id);

        // Calcular métricas
        $totalUnidades = $copropiedad->unidades->count();
        $unidadesAlDia = $copropiedad->unidades->where('estado_pago', 'al_dia')->count();
        $unidadesMorosas = $copropiedad->unidades->where('estado_pago', 'moroso')->count();
        $tasaMorosidad = $totalUnidades > 0 ? ($unidadesMorosas / $totalUnidades) * 100 : 0;

        // Ingresos del mes
        $ingresosMes = $copropiedad->gastosComunes()
            ->whereMonth('fecha', now()->month)
            ->whereYear('fecha', now()->year)
            ->sum('monto_recaudado');

        // PAE Score
        $paeScore = $this->paeService->quickScore($copropiedad);

        return response()->json([
            'copropiedad' => $copropiedad,
            'metricas' => [
                'total_unidades' => $totalUnidades,
                'unidades_al_dia' => $unidadesAlDia,
                'unidades_morosas' => $unidadesMorosas,
                'tasa_morosidad' => round($tasaMorosidad, 2),
                'ingresos_mes' => $ingresosMes,
                'antenas_activas' => $copropiedad->antenas->where('estado', 'activo')->count(),
                'pae_score' => $paeScore,
            ],
            'alertas' => $this->paeService->getActiveAlerts($copropiedad),
        ]);
    }

    /**
     * Morosidad de la copropiedad
     */
    public function morosidad(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->with(['unidades' => function($q) {
                $q->where('estado_pago', 'moroso')
                    ->with('propietario');
            }])
            ->findOrFail($id);

        $detalles = $copropiedad->unidades->map(function($unidad) {
            return [
                'unidad_id' => $unidad->id,
                'numero' => $unidad->numero,
                'propietario' => $unidad->propietario?->nombre ?? 'Sin propietario',
                'meses_morosos' => $unidad->meses_morosos ?? 0,
                'deuda_total' => $unidad->deuda_total ?? 0,
                'ultima_gestion' => $unidad->ultima_gestion_cobranza,
            ];
        });

        return response()->json([
            'copropiedad_id' => $id,
            'total_morosos' => $detalles->count(),
            'deuda_total' => $detalles->sum('deuda_total'),
            'detalle' => $detalles,
        ]);
    }

    /**
     * Cobranza
     */
    public function cobranza(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        // TODO: Implementar lógica de cobranza
        return response()->json([
            'copropiedad_id' => $id,
            'gestiones_pendientes' => [],
            'gestiones_realizadas' => [],
        ]);
    }

    /**
     * Generar gestión de cobranza
     */
    public function generarCobranza(Request $request, $id)
    {
        $request->validate([
            'unidad_ids' => 'required|array',
            'tipo_gestion' => 'required|in:carta,email,llamada,visita',
        ]);

        // TODO: Implementar generación de cobranza
        return response()->json(['message' => 'Gestión de cobranza generada'], 201);
    }

    /**
     * Fondo de reserva
     */
    public function fondoReserva(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        return response()->json([
            'copropiedad_id' => $id,
            'saldo_actual' => $copropiedad->fondo_reserva_saldo ?? 0,
            'porcentaje_objetivo' => $copropiedad->fondo_reserva_objetivo ?? 5,
            'movimientos' => [], // TODO: Cargar movimientos
        ]);
    }

    /**
     * Movimiento de fondo de reserva
     */
    public function movimientoFondo(Request $request, $id)
    {
        $request->validate([
            'tipo' => 'required|in:ingreso,egreso',
            'monto' => 'required|numeric|min:0',
            'descripcion' => 'required|string',
        ]);

        // TODO: Implementar movimiento
        return response()->json(['message' => 'Movimiento registrado'], 201);
    }

    /**
     * Estadísticas
     */
    public function estadisticas(Request $request, $id)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        return response()->json([
            'copropiedad_id' => $id,
            'recaudacion_mensual' => [],
            'morosidad_historica' => [],
            'gastos_por_categoria' => [],
        ]);
    }

    /**
     * Lista de reportes disponibles
     */
    public function reportes(Request $request, $id)
    {
        return response()->json([
            'reportes' => [
                ['id' => 'balance', 'nombre' => 'Balance Mensual'],
                ['id' => 'morosidad', 'nombre' => 'Reporte de Morosidad'],
                ['id' => 'gastos', 'nombre' => 'Detalle de Gastos'],
                ['id' => 'ingresos', 'nombre' => 'Detalle de Ingresos'],
                ['id' => 'antenas', 'nombre' => 'Reporte de Antenas'],
                ['id' => 'pae', 'nombre' => 'Análisis PAE'],
            ]
        ]);
    }

    /**
     * Generar reporte específico
     */
    public function generarReporte(Request $request, $id, $tipo)
    {
        $copropiedad = Copropiedad::where('tenant_id', $request->user()->tenant_id)
            ->findOrFail($id);

        // TODO: Generar reporte según tipo
        return response()->json([
            'tipo' => $tipo,
            'copropiedad_id' => $id,
            'generado_at' => now()->toISOString(),
            'data' => [],
        ]);
    }
}
