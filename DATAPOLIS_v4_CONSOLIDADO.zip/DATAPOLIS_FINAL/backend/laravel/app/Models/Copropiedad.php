<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Copropiedad extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'copropiedades';

    protected $fillable = [
        'tenant_id',
        'nombre',
        'rut',
        'direccion',
        'comuna',
        'region',
        'total_unidades',
        'prorrateo_type',
        'administrador_nombre',
        'administrador_email',
        'administrador_telefono',
        'fondo_reserva_saldo',
        'fondo_reserva_objetivo',
        'created_by',
    ];

    protected $casts = [
        'fondo_reserva_saldo' => 'decimal:2',
        'fondo_reserva_objetivo' => 'decimal:2',
    ];

    // Relationships
    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function unidades()
    {
        return $this->hasMany(Unidad::class);
    }

    public function antenas()
    {
        return $this->hasMany(Antena::class);
    }

    public function gastosComunes()
    {
        return $this->hasMany(GastoComun::class);
    }

    public function paeAnalyses()
    {
        return $this->hasMany(PaeAnalysis::class);
    }

    public function paeAlerts()
    {
        return $this->hasMany(PaeAlert::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Accessors
    public function getTasaMorosidadAttribute()
    {
        $total = $this->unidades()->count();
        if ($total === 0) return 0;
        
        $morosos = $this->unidades()->where('estado_pago', 'moroso')->count();
        return round(($morosos / $total) * 100, 2);
    }

    // Scopes
    public function scopeByTenant($query, $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }

    public function scopeConMorosidad($query)
    {
        return $query->whereHas('unidades', function($q) {
            $q->where('estado_pago', 'moroso');
        });
    }
}
