<?php

namespace App\Services\PAE;

use App\Models\Copropiedad;
use App\Models\PaeAnalysis;
use App\Models\PaeAlert;
use Illuminate\Support\Facades\Log;

/**
 * PAE - Precession Analysis Engine
 * 
 * Motor propietario de análisis multidimensional para copropiedades.
 * Implementa análisis de grafos, scoring y alertas predictivas.
 */
class PaeService
{
    // Dimensiones de análisis
    const DIMENSION_FINANCIAL = 'financial';
    const DIMENSION_COMPLIANCE = 'compliance';
    const DIMENSION_OPERATIONAL = 'operational';
    const DIMENSION_RISK = 'risk';
    const DIMENSION_GOVERNANCE = 'governance';

    // Umbrales de alerta
    const THRESHOLD_CRITICAL = 30;
    const THRESHOLD_HIGH = 50;
    const THRESHOLD_MEDIUM = 70;

    /**
     * Ejecutar análisis PAE completo
     */
    public function analyze(Copropiedad $copropiedad, array $options = []): PaeAnalysis
    {
        Log::info("PAE: Iniciando análisis para copropiedad {$copropiedad->id}");

        // 1. Recopilar datos
        $data = $this->collectData($copropiedad);

        // 2. Calcular scores por dimensión
        $scores = [
            self::DIMENSION_FINANCIAL => $this->calculateFinancialScore($data),
            self::DIMENSION_COMPLIANCE => $this->calculateComplianceScore($data),
            self::DIMENSION_OPERATIONAL => $this->calculateOperationalScore($data),
            self::DIMENSION_RISK => $this->calculateRiskScore($data),
            self::DIMENSION_GOVERNANCE => $this->calculateGovernanceScore($data),
        ];

        // 3. Calcular score total ponderado
        $weights = [
            self::DIMENSION_FINANCIAL => 0.30,
            self::DIMENSION_COMPLIANCE => 0.20,
            self::DIMENSION_OPERATIONAL => 0.20,
            self::DIMENSION_RISK => 0.15,
            self::DIMENSION_GOVERNANCE => 0.15,
        ];

        $scoreTotal = 0;
        foreach ($scores as $dimension => $score) {
            $scoreTotal += $score * $weights[$dimension];
        }

        // 4. Generar alertas
        $alerts = $this->generateAlerts($copropiedad, $scores, $data);

        // 5. Generar proyecciones (opcional)
        $projections = [];
        if ($options['include_projections'] ?? true) {
            $projections = $this->generateProjections($copropiedad, $scores, $data);
        }

        // 6. Guardar análisis
        $analysis = PaeAnalysis::create([
            'copropiedad_id' => $copropiedad->id,
            'score_total' => round($scoreTotal, 2),
            'scores' => $scores,
            'data_snapshot' => $data,
            'projections' => $projections,
            'alerts_generated' => count($alerts),
            'analyzed_at' => now(),
        ]);

        // 7. Guardar alertas
        foreach ($alerts as $alert) {
            PaeAlert::create([
                'copropiedad_id' => $copropiedad->id,
                'pae_analysis_id' => $analysis->id,
                'severity' => $alert['severity'],
                'type' => $alert['type'],
                'dimension' => $alert['dimension'],
                'message' => $alert['message'],
                'recommendations' => $alert['recommendations'] ?? [],
                'status' => 'active',
            ]);
        }

        Log::info("PAE: Análisis completado. Score: {$scoreTotal}");

        return $analysis;
    }

    /**
     * Obtener score rápido (sin guardar)
     */
    public function quickScore(Copropiedad $copropiedad): float
    {
        $data = $this->collectData($copropiedad);
        
        $financialScore = $this->calculateFinancialScore($data);
        $complianceScore = $this->calculateComplianceScore($data);
        
        // Score simplificado basado en las dos dimensiones principales
        return round(($financialScore * 0.6 + $complianceScore * 0.4), 2);
    }

    /**
     * Obtener alertas activas
     */
    public function getActiveAlerts(Copropiedad $copropiedad): array
    {
        return PaeAlert::where('copropiedad_id', $copropiedad->id)
            ->where('status', 'active')
            ->orderBy('severity_order')
            ->get()
            ->toArray();
    }

    /**
     * Recopilar datos para análisis
     */
    protected function collectData(Copropiedad $copropiedad): array
    {
        $unidades = $copropiedad->unidades;
        $antenas = $copropiedad->antenas;
        $gastos = $copropiedad->gastosComunes()->latest()->take(12)->get();

        return [
            'total_unidades' => $unidades->count(),
            'unidades_morosas' => $unidades->where('estado_pago', 'moroso')->count(),
            'tasa_morosidad' => $copropiedad->tasa_morosidad,
            'deuda_total' => $unidades->sum('deuda_total'),
            'fondo_reserva' => $copropiedad->fondo_reserva_saldo ?? 0,
            'fondo_reserva_objetivo' => $copropiedad->fondo_reserva_objetivo ?? 5,
            'antenas_activas' => $antenas->where('estado', 'activo')->count(),
            'ingresos_antenas' => $antenas->sum('monto_mensual'),
            'gastos_promedio' => $gastos->avg('monto_total') ?? 0,
            'recaudacion_promedio' => $gastos->avg('monto_recaudado') ?? 0,
            'tiene_administrador' => !empty($copropiedad->administrador_nombre),
            'tiene_reglamento' => $copropiedad->tiene_reglamento ?? false,
            'ultima_asamblea' => $copropiedad->ultima_asamblea ?? null,
            'certificados_vigentes' => $copropiedad->certificados_vigentes ?? 0,
        ];
    }

    /**
     * Calcular score financiero
     */
    protected function calculateFinancialScore(array $data): float
    {
        $score = 100;

        // Penalización por morosidad
        $tasaMorosidad = $data['tasa_morosidad'] ?? 0;
        if ($tasaMorosidad > 30) {
            $score -= 40;
        } elseif ($tasaMorosidad > 20) {
            $score -= 25;
        } elseif ($tasaMorosidad > 10) {
            $score -= 15;
        } elseif ($tasaMorosidad > 5) {
            $score -= 5;
        }

        // Penalización por fondo de reserva bajo
        $fondoReserva = $data['fondo_reserva'] ?? 0;
        $fondoObjetivo = $data['fondo_reserva_objetivo'] ?? 5;
        if ($fondoReserva < $fondoObjetivo * 0.5) {
            $score -= 20;
        } elseif ($fondoReserva < $fondoObjetivo) {
            $score -= 10;
        }

        // Bonificación por ingresos de antenas
        if (($data['ingresos_antenas'] ?? 0) > 0) {
            $score += 5;
        }

        return max(0, min(100, $score));
    }

    /**
     * Calcular score de cumplimiento
     */
    protected function calculateComplianceScore(array $data): float
    {
        $score = 100;

        // Penalización sin administrador registrado
        if (!($data['tiene_administrador'] ?? false)) {
            $score -= 20;
        }

        // Penalización sin reglamento
        if (!($data['tiene_reglamento'] ?? false)) {
            $score -= 15;
        }

        // Penalización por asamblea desactualizada
        $ultimaAsamblea = $data['ultima_asamblea'] ?? null;
        if (!$ultimaAsamblea || $ultimaAsamblea < now()->subYear()) {
            $score -= 25;
        }

        // Certificados vigentes
        $certificados = $data['certificados_vigentes'] ?? 0;
        if ($certificados < 3) {
            $score -= 10;
        }

        return max(0, min(100, $score));
    }

    /**
     * Calcular score operacional
     */
    protected function calculateOperationalScore(array $data): float
    {
        $score = 100;

        // Eficiencia de recaudación
        $gastos = $data['gastos_promedio'] ?? 0;
        $recaudacion = $data['recaudacion_promedio'] ?? 0;
        
        if ($gastos > 0) {
            $eficiencia = ($recaudacion / $gastos) * 100;
            if ($eficiencia < 70) {
                $score -= 30;
            } elseif ($eficiencia < 85) {
                $score -= 15;
            } elseif ($eficiencia < 95) {
                $score -= 5;
            }
        }

        return max(0, min(100, $score));
    }

    /**
     * Calcular score de riesgo
     */
    protected function calculateRiskScore(array $data): float
    {
        $score = 100;

        // Riesgo por alta morosidad
        $tasaMorosidad = $data['tasa_morosidad'] ?? 0;
        if ($tasaMorosidad > 25) {
            $score -= 35;
        } elseif ($tasaMorosidad > 15) {
            $score -= 20;
        }

        // Riesgo por deuda acumulada alta
        $deudaTotal = $data['deuda_total'] ?? 0;
        $gastosPromedio = $data['gastos_promedio'] ?? 1;
        $mesesDeuda = $gastosPromedio > 0 ? $deudaTotal / $gastosPromedio : 0;
        
        if ($mesesDeuda > 6) {
            $score -= 25;
        } elseif ($mesesDeuda > 3) {
            $score -= 15;
        }

        return max(0, min(100, $score));
    }

    /**
     * Calcular score de gobernanza
     */
    protected function calculateGovernanceScore(array $data): float
    {
        $score = 100;

        if (!($data['tiene_administrador'] ?? false)) {
            $score -= 30;
        }

        if (!($data['tiene_reglamento'] ?? false)) {
            $score -= 20;
        }

        $ultimaAsamblea = $data['ultima_asamblea'] ?? null;
        if (!$ultimaAsamblea) {
            $score -= 25;
        } elseif ($ultimaAsamblea < now()->subMonths(18)) {
            $score -= 15;
        }

        return max(0, min(100, $score));
    }

    /**
     * Generar alertas basadas en análisis
     */
    protected function generateAlerts(Copropiedad $copropiedad, array $scores, array $data): array
    {
        $alerts = [];

        // Alerta por score financiero crítico
        if ($scores[self::DIMENSION_FINANCIAL] < self::THRESHOLD_CRITICAL) {
            $alerts[] = [
                'severity' => 'critical',
                'type' => 'financial_critical',
                'dimension' => self::DIMENSION_FINANCIAL,
                'message' => 'Score financiero en nivel crítico. Requiere atención inmediata.',
                'recommendations' => [
                    'Implementar plan de cobranza urgente',
                    'Revisar estructura de gastos',
                    'Convocar asamblea extraordinaria',
                ],
            ];
        }

        // Alerta por morosidad alta
        if (($data['tasa_morosidad'] ?? 0) > 20) {
            $alerts[] = [
                'severity' => 'high',
                'type' => 'high_delinquency',
                'dimension' => self::DIMENSION_FINANCIAL,
                'message' => "Tasa de morosidad elevada: {$data['tasa_morosidad']}%",
                'recommendations' => [
                    'Activar gestión de cobranza preventiva',
                    'Ofrecer convenios de pago',
                ],
            ];
        }

        // Alerta por compliance
        if ($scores[self::DIMENSION_COMPLIANCE] < self::THRESHOLD_MEDIUM) {
            $alerts[] = [
                'severity' => 'medium',
                'type' => 'compliance_issues',
                'dimension' => self::DIMENSION_COMPLIANCE,
                'message' => 'Existen aspectos de cumplimiento que requieren atención.',
                'recommendations' => [
                    'Actualizar documentación legal',
                    'Programar asamblea ordinaria',
                ],
            ];
        }

        return $alerts;
    }

    /**
     * Generar proyecciones
     */
    protected function generateProjections(Copropiedad $copropiedad, array $scores, array $data): array
    {
        // Proyección simplificada a 12 meses
        $projections = [];
        $currentScore = array_sum($scores) / count($scores);

        for ($month = 1; $month <= 12; $month++) {
            // Modelo simplificado: tendencia basada en morosidad
            $trend = $data['tasa_morosidad'] > 15 ? -0.5 : 0.2;
            $projectedScore = $currentScore + ($trend * $month);
            $projectedScore = max(0, min(100, $projectedScore));

            $projections[] = [
                'month' => $month,
                'date' => now()->addMonths($month)->format('Y-m'),
                'projected_score' => round($projectedScore, 2),
                'confidence' => max(0.5, 1 - ($month * 0.03)),
            ];
        }

        return $projections;
    }
}
