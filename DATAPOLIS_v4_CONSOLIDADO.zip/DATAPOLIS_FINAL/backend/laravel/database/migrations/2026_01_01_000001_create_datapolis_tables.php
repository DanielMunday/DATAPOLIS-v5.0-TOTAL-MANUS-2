<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Tenants (Multi-tenancy)
        Schema::create('tenants', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('rut')->unique()->nullable();
            $table->json('settings')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        // Users
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });

        // Copropiedades
        Schema::create('copropiedades', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('nombre');
            $table->string('rut')->unique();
            $table->string('direccion');
            $table->string('comuna');
            $table->string('region')->nullable();
            $table->integer('total_unidades')->default(0);
            $table->enum('prorrateo_type', ['metros', 'alicuota', 'igual'])->default('metros');
            $table->string('administrador_nombre')->nullable();
            $table->string('administrador_email')->nullable();
            $table->string('administrador_telefono')->nullable();
            $table->decimal('fondo_reserva_saldo', 15, 2)->default(0);
            $table->decimal('fondo_reserva_objetivo', 5, 2)->default(5);
            $table->boolean('tiene_reglamento')->default(false);
            $table->date('ultima_asamblea')->nullable();
            $table->integer('certificados_vigentes')->default(0);
            $table->foreignId('created_by')->nullable()->constrained('users');
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'comuna']);
        });

        // Unidades
        Schema::create('unidades', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->onDelete('cascade');
            $table->string('numero');
            $table->enum('tipo', ['departamento', 'estacionamiento', 'bodega', 'local', 'oficina']);
            $table->decimal('superficie_m2', 10, 2)->nullable();
            $table->decimal('alicuota', 8, 4)->nullable();
            $table->string('propietario_nombre')->nullable();
            $table->string('propietario_rut')->nullable();
            $table->string('propietario_email')->nullable();
            $table->string('propietario_telefono')->nullable();
            $table->enum('estado_pago', ['al_dia', 'moroso', 'convenio'])->default('al_dia');
            $table->integer('meses_morosos')->default(0);
            $table->decimal('deuda_total', 15, 2)->default(0);
            $table->date('ultima_gestion_cobranza')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            $table->unique(['copropiedad_id', 'numero']);
        });

        // Antenas (Contratos de telecomunicaciones)
        Schema::create('antenas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->onDelete('cascade');
            $table->string('empresa');
            $table->string('tipo_antena')->nullable();
            $table->date('fecha_inicio');
            $table->date('fecha_termino')->nullable();
            $table->decimal('monto_mensual', 15, 2);
            $table->enum('moneda', ['CLP', 'UF', 'USD'])->default('UF');
            $table->enum('estado', ['activo', 'terminado', 'en_negociacion'])->default('activo');
            $table->text('ubicacion_tecnica')->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // Gastos Comunes
        Schema::create('gastos_comunes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->onDelete('cascade');
            $table->date('fecha');
            $table->string('periodo'); // YYYY-MM
            $table->decimal('monto_total', 15, 2);
            $table->decimal('monto_recaudado', 15, 2)->default(0);
            $table->json('detalle')->nullable();
            $table->timestamps();
            
            $table->unique(['copropiedad_id', 'periodo']);
        });

        // PAE Analysis
        Schema::create('pae_analyses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->onDelete('cascade');
            $table->decimal('score_total', 5, 2);
            $table->json('scores');
            $table->json('data_snapshot')->nullable();
            $table->json('projections')->nullable();
            $table->integer('alerts_generated')->default(0);
            $table->timestamp('analyzed_at');
            $table->timestamps();
            
            $table->index(['copropiedad_id', 'analyzed_at']);
        });

        // PAE Alerts
        Schema::create('pae_alerts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->onDelete('cascade');
            $table->foreignId('pae_analysis_id')->constrained()->onDelete('cascade');
            $table->enum('severity', ['critical', 'high', 'medium', 'low']);
            $table->string('type');
            $table->string('dimension');
            $table->text('message');
            $table->json('recommendations')->nullable();
            $table->enum('status', ['active', 'acknowledged', 'resolved'])->default('active');
            $table->timestamp('acknowledged_at')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            
            $table->index(['copropiedad_id', 'status', 'severity']);
        });

        // Expedientes
        Schema::create('expedientes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('titulo');
            $table->enum('tipo', ['compraventa', 'arriendo', 'tasacion', 'due_diligence', 'hipoteca', 'otro']);
            $table->text('descripcion')->nullable();
            $table->enum('estado', ['activo', 'cerrado', 'pendiente', 'cancelado'])->default('activo');
            $table->date('fecha_inicio')->nullable();
            $table->date('fecha_cierre')->nullable();
            $table->foreignId('propiedad_id')->nullable();
            $table->foreignId('created_by')->constrained('users');
            $table->timestamps();
            $table->softDeletes();
        });

        // Propiedades (Fichas)
        Schema::create('propiedades', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('rol')->unique();
            $table->string('direccion');
            $table->string('comuna');
            $table->string('region')->nullable();
            $table->enum('tipo', ['departamento', 'casa', 'terreno', 'local', 'bodega', 'oficina', 'otro']);
            $table->decimal('superficie_total', 10, 2)->nullable();
            $table->decimal('superficie_util', 10, 2)->nullable();
            $table->integer('dormitorios')->nullable();
            $table->integer('banos')->nullable();
            $table->integer('estacionamientos')->nullable();
            $table->integer('ano_construccion')->nullable();
            $table->decimal('latitud', 10, 8)->nullable();
            $table->decimal('longitud', 11, 8)->nullable();
            $table->decimal('valor_fiscal_uf', 15, 2)->nullable();
            $table->decimal('ultimo_avaluo_uf', 15, 2)->nullable();
            $table->date('fecha_ultimo_avaluo')->nullable();
            $table->json('caracteristicas')->nullable();
            $table->foreignId('created_by')->constrained('users');
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'comuna']);
        });

        // Garantías
        Schema::create('garantias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('propiedad_id')->constrained()->onDelete('cascade');
            $table->enum('tipo', ['hipoteca', 'prenda', 'aval', 'fianza']);
            $table->decimal('valor_uf', 15, 2);
            $table->decimal('ltv', 5, 2)->nullable();
            $table->enum('estado', ['vigente', 'liberada', 'ejecutada'])->default('vigente');
            $table->string('institucion')->nullable();
            $table->date('fecha_constitucion')->nullable();
            $table->date('fecha_liberacion')->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // Plusvalías
        Schema::create('plusvalias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('propiedad_id')->constrained()->onDelete('cascade');
            $table->decimal('valor_inicial_uf', 15, 2);
            $table->decimal('valor_final_uf', 15, 2);
            $table->decimal('plusvalia_bruta_uf', 15, 2);
            $table->decimal('deducciones_uf', 15, 2)->default(0);
            $table->decimal('plusvalia_neta_uf', 15, 2);
            $table->decimal('tasa_aplicada', 5, 4);
            $table->decimal('impuesto_uf', 15, 2);
            $table->boolean('exento')->default(false);
            $table->string('motivo_exencion')->nullable();
            $table->date('fecha_calculo');
            $table->json('obras_contribuyentes')->nullable();
            $table->json('calculo_detalle')->nullable();
            $table->timestamps();
        });

        // Indicadores Económicos
        Schema::create('indicadores_economicos', function (Blueprint $table) {
            $table->id();
            $table->string('tipo'); // uf, utm, ipc, dolar, euro, tpm
            $table->decimal('valor', 15, 4);
            $table->date('fecha');
            $table->string('fuente')->nullable();
            $table->timestamps();
            
            $table->unique(['tipo', 'fecha']);
            $table->index(['tipo', 'fecha']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('indicadores_economicos');
        Schema::dropIfExists('plusvalias');
        Schema::dropIfExists('garantias');
        Schema::dropIfExists('propiedades');
        Schema::dropIfExists('expedientes');
        Schema::dropIfExists('pae_alerts');
        Schema::dropIfExists('pae_analyses');
        Schema::dropIfExists('gastos_comunes');
        Schema::dropIfExists('antenas');
        Schema::dropIfExists('unidades');
        Schema::dropIfExists('copropiedades');
        Schema::dropIfExists('users');
        Schema::dropIfExists('tenants');
    }
};
