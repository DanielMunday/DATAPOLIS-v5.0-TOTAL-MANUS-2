<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ExpedienteController;
use App\Http\Controllers\Api\PropiedadController;
use App\Http\Controllers\Api\CopropiedadController;
use App\Http\Controllers\Api\UnidadController;
use App\Http\Controllers\Api\AntenaController;
use App\Http\Controllers\Api\GastoController;
use App\Http\Controllers\Api\PaeController;
use App\Http\Controllers\Api\CreditScoreController;
use App\Http\Controllers\Api\GarantiaController;
use App\Http\Controllers\Api\BaselController;
use App\Http\Controllers\Api\PlusvaliaController;
use App\Http\Controllers\Api\GiresController;
use App\Http\Controllers\Api\AgoraController;
use App\Http\Controllers\Api\IndicadorController;
use App\Http\Controllers\Api\OpenFinanceController;
use App\Http\Controllers\Api\ContabilidadController;
use App\Http\Controllers\Api\ArriendoController;
use App\Http\Controllers\Api\MantencionController;

/*
|--------------------------------------------------------------------------
| DATAPOLIS v3.0 - API Routes
|--------------------------------------------------------------------------
| Total: 186 endpoints
| Auth: JWT via Laravel Sanctum
*/

// Health Check
Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'version' => '3.0.0',
        'timestamp' => now()->toISOString(),
        'services' => [
            'database' => 'connected',
            'cache' => 'connected',
            'queue' => 'running'
        ]
    ]);
});

// ============================================================================
// AUTH (Public)
// ============================================================================
Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
});

// ============================================================================
// PROTECTED ROUTES (Require Authentication)
// ============================================================================
Route::middleware(['auth:sanctum'])->group(function () {
    
    // Auth
    Route::prefix('auth')->group(function () {
        Route::get('/me', [AuthController::class, 'me']);
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::put('/profile', [AuthController::class, 'updateProfile']);
        Route::put('/password', [AuthController::class, 'updatePassword']);
    });

    // ========================================================================
    // M00 - EXPEDIENTES
    // ========================================================================
    Route::prefix('expedientes')->group(function () {
        Route::get('/', [ExpedienteController::class, 'index']);
        Route::post('/', [ExpedienteController::class, 'store']);
        Route::get('/{id}', [ExpedienteController::class, 'show']);
        Route::put('/{id}', [ExpedienteController::class, 'update']);
        Route::delete('/{id}', [ExpedienteController::class, 'destroy']);
        Route::get('/{id}/timeline', [ExpedienteController::class, 'timeline']);
        Route::post('/{id}/documentos', [ExpedienteController::class, 'addDocumento']);
        Route::get('/{id}/documentos', [ExpedienteController::class, 'documentos']);
        Route::post('/{id}/notas', [ExpedienteController::class, 'addNota']);
        Route::post('/{id}/participantes', [ExpedienteController::class, 'addParticipante']);
        Route::put('/{id}/estado', [ExpedienteController::class, 'cambiarEstado']);
        Route::get('/{id}/historial', [ExpedienteController::class, 'historial']);
        Route::post('/{id}/vincular', [ExpedienteController::class, 'vincularPropiedad']);
        Route::get('/estadisticas', [ExpedienteController::class, 'estadisticas']);
    });

    // ========================================================================
    // M01 - FICHAS DE PROPIEDAD
    // ========================================================================
    Route::prefix('fichas')->group(function () {
        Route::get('/', [PropiedadController::class, 'index']);
        Route::post('/', [PropiedadController::class, 'store']);
        Route::get('/{id}', [PropiedadController::class, 'show']);
        Route::put('/{id}', [PropiedadController::class, 'update']);
        Route::delete('/{id}', [PropiedadController::class, 'destroy']);
        Route::get('/{id}/ficha-completa', [PropiedadController::class, 'fichaCompleta']);
        Route::get('/{id}/avaluo', [PropiedadController::class, 'avaluo']);
        Route::post('/{id}/documentos', [PropiedadController::class, 'addDocumento']);
        Route::get('/{id}/historial-precios', [PropiedadController::class, 'historialPrecios']);
        Route::get('/{id}/comparables', [PropiedadController::class, 'comparables']);
        Route::get('/{id}/riesgos', [PropiedadController::class, 'riesgos']);
        Route::get('/{id}/certificados', [PropiedadController::class, 'certificados']);
        Route::post('/buscar', [PropiedadController::class, 'buscar']);
        Route::get('/mapa', [PropiedadController::class, 'mapa']);
        Route::post('/importar', [PropiedadController::class, 'importar']);
        Route::get('/exportar', [PropiedadController::class, 'exportar']);
    });

    // ========================================================================
    // M02 - COPROPIEDADES
    // ========================================================================
    Route::prefix('copropiedades')->group(function () {
        Route::get('/', [CopropiedadController::class, 'index']);
        Route::post('/', [CopropiedadController::class, 'store']);
        Route::get('/{id}', [CopropiedadController::class, 'show']);
        Route::put('/{id}', [CopropiedadController::class, 'update']);
        Route::delete('/{id}', [CopropiedadController::class, 'destroy']);
        Route::get('/{id}/dashboard', [CopropiedadController::class, 'dashboard']);
        
        // Unidades
        Route::get('/{id}/unidades', [UnidadController::class, 'index']);
        Route::post('/{id}/unidades', [UnidadController::class, 'store']);
        Route::get('/{id}/unidades/{unidadId}', [UnidadController::class, 'show']);
        Route::put('/{id}/unidades/{unidadId}', [UnidadController::class, 'update']);
        
        // Antenas
        Route::get('/{id}/antenas', [AntenaController::class, 'index']);
        Route::post('/{id}/antenas', [AntenaController::class, 'store']);
        Route::get('/{id}/antenas/{antenaId}', [AntenaController::class, 'show']);
        Route::put('/{id}/antenas/{antenaId}', [AntenaController::class, 'update']);
        Route::get('/{id}/antenas/{antenaId}/facturacion', [AntenaController::class, 'facturacion']);
        
        // Gastos Comunes
        Route::get('/{id}/gastos', [GastoController::class, 'index']);
        Route::post('/{id}/gastos', [GastoController::class, 'store']);
        Route::get('/{id}/gastos/prorrateo', [GastoController::class, 'prorrateo']);
        
        // Morosidad
        Route::get('/{id}/morosidad', [CopropiedadController::class, 'morosidad']);
        Route::get('/{id}/cobranza', [CopropiedadController::class, 'cobranza']);
        Route::post('/{id}/cobranza/generar', [CopropiedadController::class, 'generarCobranza']);
        
        // Fondo de Reserva
        Route::get('/{id}/fondo-reserva', [CopropiedadController::class, 'fondoReserva']);
        Route::post('/{id}/fondo-reserva/movimiento', [CopropiedadController::class, 'movimientoFondo']);
        
        // Estadísticas y Reportes
        Route::get('/{id}/estadisticas', [CopropiedadController::class, 'estadisticas']);
        Route::get('/{id}/reportes', [CopropiedadController::class, 'reportes']);
        Route::get('/{id}/reportes/{tipo}', [CopropiedadController::class, 'generarReporte']);
        
        // PAE (Precession Analysis Engine)
        Route::post('/{id}/pae/analyze', [PaeController::class, 'analyze']);
        Route::get('/{id}/pae/quick', [PaeController::class, 'quickAnalysis']);
        Route::get('/{id}/pae/score', [PaeController::class, 'getScore']);
        Route::get('/{id}/pae/history', [PaeController::class, 'history']);
        Route::get('/{id}/pae/alerts', [PaeController::class, 'alerts']);
        Route::put('/{id}/pae/alerts/{alertId}', [PaeController::class, 'updateAlert']);
        Route::get('/{id}/pae/effects', [PaeController::class, 'effects']);
        Route::get('/{id}/pae/graph', [PaeController::class, 'graph']);
        Route::post('/{id}/pae/simulate', [PaeController::class, 'simulate']);
        Route::get('/{id}/pae/projections', [PaeController::class, 'projections']);
        Route::get('/{id}/pae/recommendations', [PaeController::class, 'recommendations']);
        Route::get('/{id}/pae/trends', [PaeController::class, 'trends']);
        Route::get('/{id}/pae/benchmarks', [PaeController::class, 'benchmarks']);
    });

    // ========================================================================
    // M03 - CREDIT SCORING BASEL IV
    // ========================================================================
    Route::prefix('credit-scoring')->group(function () {
        Route::post('/calculate', [CreditScoreController::class, 'calculate']);
        Route::get('/pd/{entityId}', [CreditScoreController::class, 'getPD']);
        Route::get('/lgd/{entityId}', [CreditScoreController::class, 'getLGD']);
        Route::get('/ead/{entityId}', [CreditScoreController::class, 'getEAD']);
        Route::get('/rwa/{entityId}', [CreditScoreController::class, 'getRWA']);
        Route::get('/history/{entityId}', [CreditScoreController::class, 'history']);
        Route::post('/batch', [CreditScoreController::class, 'batchCalculate']);
        Route::get('/factors', [CreditScoreController::class, 'factors']);
        Route::post('/simulate', [CreditScoreController::class, 'simulate']);
        Route::get('/models', [CreditScoreController::class, 'models']);
        Route::get('/thresholds', [CreditScoreController::class, 'thresholds']);
    });

    // ========================================================================
    // M13 - GARANTÍAS
    // ========================================================================
    Route::prefix('garantias')->group(function () {
        Route::get('/', [GarantiaController::class, 'index']);
        Route::post('/', [GarantiaController::class, 'store']);
        Route::get('/{id}', [GarantiaController::class, 'show']);
        Route::put('/{id}', [GarantiaController::class, 'update']);
        Route::delete('/{id}', [GarantiaController::class, 'destroy']);
        Route::get('/{id}/valuacion', [GarantiaController::class, 'valuacion']);
        Route::get('/{id}/ltv', [GarantiaController::class, 'ltv']);
        Route::post('/{id}/liberar', [GarantiaController::class, 'liberar']);
    });

    // ========================================================================
    // M16 - BASEL IV
    // ========================================================================
    Route::prefix('basel')->group(function () {
        Route::post('/validate', [BaselController::class, 'validate']);
        Route::get('/cr-sa/{entityId}', [BaselController::class, 'crSA']);
        Route::post('/capital-requirements', [BaselController::class, 'capitalRequirements']);
        Route::get('/output-floor', [BaselController::class, 'outputFloor']);
        Route::get('/report/{entityId}', [BaselController::class, 'report']);
    });

    // ========================================================================
    // GT-PV - PLUSVALÍAS (Ley 21.713)
    // ========================================================================
    Route::prefix('plusvalias')->group(function () {
        Route::post('/calcular', [PlusvaliaController::class, 'calcular']);
        Route::get('/{id}', [PlusvaliaController::class, 'show']);
        Route::get('/propiedad/{propiedadId}', [PlusvaliaController::class, 'byPropiedad']);
        Route::post('/simular', [PlusvaliaController::class, 'simular']);
        Route::get('/historial/{propiedadId}', [PlusvaliaController::class, 'historial']);
        Route::post('/declaracion', [PlusvaliaController::class, 'generarDeclaracion']);
        Route::get('/declaracion/{id}/pdf', [PlusvaliaController::class, 'descargarDeclaracion']);
        Route::post('/pago', [PlusvaliaController::class, 'registrarPago']);
        Route::get('/deuda/{propiedadId}', [PlusvaliaController::class, 'deuda']);
        Route::post('/convenio-pago', [PlusvaliaController::class, 'convenioPago']);
        Route::get('/tasas', [PlusvaliaController::class, 'tasas']);
        Route::get('/exenciones', [PlusvaliaController::class, 'exenciones']);
        Route::get('/obras-publicas', [PlusvaliaController::class, 'obrasPublicas']);
        Route::get('/zonas-afectas', [PlusvaliaController::class, 'zonasAfectas']);
        Route::get('/estadisticas', [PlusvaliaController::class, 'estadisticas']);
    });

    // ========================================================================
    // M17 - GIRES (Riesgos Naturales)
    // ========================================================================
    Route::prefix('gires')->group(function () {
        Route::get('/riesgos/{ubicacionId}', [GiresController::class, 'riesgos']);
        Route::post('/analisis', [GiresController::class, 'analisis']);
        Route::get('/alertas', [GiresController::class, 'alertas']);
        Route::get('/zonas', [GiresController::class, 'zonas']);
        Route::get('/mapas/{tipo}', [GiresController::class, 'mapas']);
        Route::post('/batch-query', [GiresController::class, 'batchQuery']);
        Route::get('/estadisticas', [GiresController::class, 'estadisticas']);
        Route::get('/historial/{ubicacionId}', [GiresController::class, 'historial']);
        Route::get('/reportes/{tipo}', [GiresController::class, 'reportes']);
        Route::get('/fuentes', [GiresController::class, 'fuentes']);
    });

    // ========================================================================
    // M22 - ÁGORA GeoViewer
    // ========================================================================
    Route::prefix('agora')->group(function () {
        Route::get('/capas', [AgoraController::class, 'capas']);
        Route::post('/capas', [AgoraController::class, 'crearCapa']);
        Route::get('/capas/{id}', [AgoraController::class, 'getCapa']);
        Route::put('/capas/{id}', [AgoraController::class, 'updateCapa']);
        Route::delete('/capas/{id}', [AgoraController::class, 'deleteCapa']);
        Route::get('/tiles/{z}/{x}/{y}', [AgoraController::class, 'tiles']);
        Route::get('/features', [AgoraController::class, 'features']);
        Route::post('/query', [AgoraController::class, 'spatialQuery']);
        Route::post('/intersect', [AgoraController::class, 'intersect']);
        Route::post('/buffer', [AgoraController::class, 'buffer']);
        Route::get('/prc/{comuna}', [AgoraController::class, 'prc']);
        Route::get('/zonificacion', [AgoraController::class, 'zonificacion']);
        Route::get('/normativa/{zonaId}', [AgoraController::class, 'normativa']);
        Route::post('/analisis-territorial', [AgoraController::class, 'analisisTerritorial']);
        Route::get('/indicadores/{zonaId}', [AgoraController::class, 'indicadores']);
        Route::get('/reportes/{tipo}', [AgoraController::class, 'reportes']);
        Route::get('/proyectos', [AgoraController::class, 'proyectos']);
        Route::post('/geocoding', [AgoraController::class, 'geocoding']);
    });

    // ========================================================================
    // M01-OF - OPEN FINANCE (NCG 514)
    // ========================================================================
    Route::prefix('open-finance')->group(function () {
        Route::post('/consent', [OpenFinanceController::class, 'createConsent']);
        Route::get('/consent/{consentId}', [OpenFinanceController::class, 'getConsent']);
        Route::delete('/consent/{consentId}', [OpenFinanceController::class, 'revokeConsent']);
        Route::get('/accounts', [OpenFinanceController::class, 'accounts']);
        Route::get('/accounts/{accountId}', [OpenFinanceController::class, 'getAccount']);
        Route::get('/accounts/{accountId}/balances', [OpenFinanceController::class, 'balances']);
        Route::get('/accounts/{accountId}/transactions', [OpenFinanceController::class, 'transactions']);
        Route::post('/payments', [OpenFinanceController::class, 'initiatePayment']);
        Route::get('/payments/{paymentId}', [OpenFinanceController::class, 'getPayment']);
        Route::get('/institutions', [OpenFinanceController::class, 'institutions']);
        Route::get('/directorio', [OpenFinanceController::class, 'directorio']);
        Route::post('/token/refresh', [OpenFinanceController::class, 'refreshToken']);
    });

    // ========================================================================
    // M08 - CONTABILIDAD
    // ========================================================================
    Route::prefix('contabilidad')->group(function () {
        Route::get('/plan-cuentas', [ContabilidadController::class, 'planCuentas']);
        Route::get('/asientos', [ContabilidadController::class, 'asientos']);
        Route::post('/asientos', [ContabilidadController::class, 'crearAsiento']);
        Route::get('/asientos/{id}', [ContabilidadController::class, 'getAsiento']);
        Route::get('/balance', [ContabilidadController::class, 'balance']);
        Route::get('/estado-resultados', [ContabilidadController::class, 'estadoResultados']);
        Route::get('/flujo-caja', [ContabilidadController::class, 'flujoCaja']);
        Route::get('/libro-mayor/{cuentaId}', [ContabilidadController::class, 'libroMayor']);
        Route::post('/cierre-periodo', [ContabilidadController::class, 'cierrePeriodo']);
    });

    // ========================================================================
    // M05 - ARRIENDOS
    // ========================================================================
    Route::prefix('arriendos')->group(function () {
        Route::get('/', [ArriendoController::class, 'index']);
        Route::post('/', [ArriendoController::class, 'store']);
        Route::get('/{id}', [ArriendoController::class, 'show']);
        Route::put('/{id}', [ArriendoController::class, 'update']);
        Route::delete('/{id}', [ArriendoController::class, 'destroy']);
        Route::get('/{id}/pagos', [ArriendoController::class, 'pagos']);
        Route::post('/{id}/pago', [ArriendoController::class, 'registrarPago']);
        Route::post('/{id}/facturar', [ArriendoController::class, 'facturar']);
        Route::post('/{id}/renovar', [ArriendoController::class, 'renovar']);
        Route::post('/{id}/terminar', [ArriendoController::class, 'terminar']);
    });

    // ========================================================================
    // M06 - MANTENCIONES
    // ========================================================================
    Route::prefix('mantenciones')->group(function () {
        Route::get('/', [MantencionController::class, 'index']);
        Route::post('/', [MantencionController::class, 'store']);
        Route::get('/{id}', [MantencionController::class, 'show']);
        Route::put('/{id}', [MantencionController::class, 'update']);
        Route::delete('/{id}', [MantencionController::class, 'destroy']);
        Route::post('/{id}/ejecutar', [MantencionController::class, 'ejecutar']);
        Route::get('/programadas', [MantencionController::class, 'programadas']);
        Route::get('/historial/{propiedadId}', [MantencionController::class, 'historial']);
    });

    // ========================================================================
    // IE - INDICADORES ECONÓMICOS
    // ========================================================================
    Route::prefix('indicadores')->group(function () {
        Route::get('/uf', [IndicadorController::class, 'uf']);
        Route::get('/utm', [IndicadorController::class, 'utm']);
        Route::get('/ipc', [IndicadorController::class, 'ipc']);
        Route::get('/dolar', [IndicadorController::class, 'dolar']);
        Route::get('/euro', [IndicadorController::class, 'euro']);
        Route::get('/tpm', [IndicadorController::class, 'tpm']);
        Route::get('/historico/{tipo}', [IndicadorController::class, 'historico']);
        Route::get('/convertir', [IndicadorController::class, 'convertir']);
    });
});
