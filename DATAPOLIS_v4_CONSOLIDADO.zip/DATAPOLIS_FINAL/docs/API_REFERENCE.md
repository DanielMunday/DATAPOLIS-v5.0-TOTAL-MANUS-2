# DATAPOLIS v3.0 - API Reference

## Información General

| Atributo | Valor |
|----------|-------|
| Base URL (Laravel) | `http://localhost:8000/api/v1` |
| Base URL (FastAPI) | `http://localhost:8001/api/v1` |
| Autenticación | Bearer Token (JWT) |
| Content-Type | `application/json` |
| Total Endpoints | 450+ |

---

## Autenticación

### Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "usuario@ejemplo.com",
  "password": "contraseña"
}
```

**Response 200:**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "user": {
    "id": 1,
    "name": "Usuario",
    "email": "usuario@ejemplo.com",
    "tenant_id": 1,
    "roles": ["admin"]
  }
}
```

### Headers Requeridos
```http
Authorization: Bearer {access_token}
Accept: application/json
Content-Type: application/json
```

---

## Endpoints por Módulo

### M00 - Expedientes (Laravel)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/expedientes` | Listar expedientes |
| POST | `/expedientes` | Crear expediente |
| GET | `/expedientes/{id}` | Obtener expediente |
| PUT | `/expedientes/{id}` | Actualizar expediente |
| DELETE | `/expedientes/{id}` | Eliminar expediente |
| GET | `/expedientes/{id}/timeline` | Timeline del expediente |
| POST | `/expedientes/{id}/documentos` | Agregar documento |
| POST | `/expedientes/{id}/vincular` | Vincular a propiedad |

**Ejemplo - Crear Expediente:**
```http
POST /expedientes
Authorization: Bearer {token}

{
  "titulo": "Compraventa Depto 1204",
  "tipo": "compraventa",
  "descripcion": "Expediente de compraventa",
  "fecha_inicio": "2026-02-01"
}
```

---

### M01 - Fichas de Propiedad (Laravel)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/fichas` | Listar propiedades |
| POST | `/fichas` | Crear ficha |
| GET | `/fichas/{id}` | Obtener ficha |
| PUT | `/fichas/{id}` | Actualizar ficha |
| GET | `/fichas/{id}/ficha-completa` | Ficha con todos los datos |
| GET | `/fichas/{id}/avaluo` | Obtener avalúo |
| GET | `/fichas/{id}/comparables` | Propiedades comparables |
| GET | `/fichas/{id}/riesgos` | Análisis de riesgos |

---

### M02 - Copropiedades (Laravel)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/copropiedades` | Listar copropiedades |
| POST | `/copropiedades` | Crear copropiedad |
| GET | `/copropiedades/{id}` | Obtener copropiedad |
| PUT | `/copropiedades/{id}` | Actualizar copropiedad |
| DELETE | `/copropiedades/{id}` | Eliminar copropiedad |
| GET | `/copropiedades/{id}/dashboard` | Dashboard completo |
| GET | `/copropiedades/{id}/unidades` | Listar unidades |
| POST | `/copropiedades/{id}/unidades` | Crear unidad |
| GET | `/copropiedades/{id}/antenas` | Listar contratos antenas |
| POST | `/copropiedades/{id}/antenas` | Crear contrato antena |
| GET | `/copropiedades/{id}/morosidad` | Reporte morosidad |
| GET | `/copropiedades/{id}/gastos` | Gastos comunes |

**Ejemplo - Dashboard:**
```http
GET /copropiedades/1/dashboard
Authorization: Bearer {token}
```

**Response:**
```json
{
  "copropiedad": { "id": 1, "nombre": "Edificio Central", ... },
  "metricas": {
    "total_unidades": 120,
    "unidades_al_dia": 108,
    "unidades_morosas": 12,
    "tasa_morosidad": 10.0,
    "ingresos_mes": 15000000,
    "antenas_activas": 3,
    "pae_score": 78.5
  },
  "alertas": [...]
}
```

---

### M11 - PAE Engine (Laravel)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/copropiedades/{id}/pae/analyze` | Análisis completo |
| GET | `/copropiedades/{id}/pae/quick` | Score rápido |
| GET | `/copropiedades/{id}/pae/score` | Último score |
| GET | `/copropiedades/{id}/pae/history` | Historial de análisis |
| GET | `/copropiedades/{id}/pae/alerts` | Alertas activas |
| PUT | `/copropiedades/{id}/pae/alerts/{alertId}` | Actualizar alerta |
| POST | `/copropiedades/{id}/pae/simulate` | Simular escenario |
| GET | `/copropiedades/{id}/pae/projections` | Proyecciones |
| GET | `/copropiedades/{id}/pae/recommendations` | Recomendaciones |

**Ejemplo - Análisis PAE:**
```http
POST /copropiedades/1/pae/analyze
Authorization: Bearer {token}

{
  "include_projections": true,
  "horizon_months": 12
}
```

**Response:**
```json
{
  "id": 45,
  "copropiedad_id": 1,
  "score_total": 72.5,
  "scores": {
    "financial": 65.0,
    "compliance": 80.0,
    "operational": 75.0,
    "risk": 70.0,
    "governance": 72.5
  },
  "alerts": [
    {
      "severity": "high",
      "type": "high_delinquency",
      "message": "Tasa de morosidad elevada: 15%"
    }
  ],
  "projections": [...]
}
```

---

### M03 - Credit Scoring Basel IV (FastAPI)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/credit-scoring/calculate` | Calcular score |
| GET | `/credit-scoring/pd/{entityId}` | Probability of Default |
| GET | `/credit-scoring/lgd/{entityId}` | Loss Given Default |
| GET | `/credit-scoring/ead/{entityId}` | Exposure at Default |
| GET | `/credit-scoring/rwa/{entityId}` | Risk Weighted Assets |
| GET | `/credit-scoring/history/{entityId}` | Historial de scores |
| POST | `/credit-scoring/batch` | Cálculo batch |
| POST | `/credit-scoring/simulate` | Simulación |

**Ejemplo - Calcular Score:**
```http
POST /credit-scoring/calculate
Authorization: Bearer {token}

{
  "entity_type": "copropiedad",
  "entity_id": 1,
  "include_history": true
}
```

**Response:**
```json
{
  "score": 720,
  "grade": "A",
  "pd": 0.0234,
  "lgd": 0.35,
  "ead": 150000000,
  "rwa": 52500000,
  "factors": {
    "payment_history": 0.85,
    "debt_ratio": 0.72,
    "income_stability": 0.90
  }
}
```

---

### M04 - Valorización ML (FastAPI)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/valorizaciones/avaluo` | Generar avalúo ML |
| POST | `/valorizaciones/comparables` | Buscar comparables |
| GET | `/valorizaciones/historial/{propiedadId}` | Historial de valores |
| POST | `/valorizaciones/batch` | Avalúo batch |
| GET | `/valorizaciones/metodologias` | Metodologías disponibles |

**Ejemplo - Avalúo ML:**
```http
POST /valorizaciones/avaluo
Authorization: Bearer {token}

{
  "propiedad_id": 123,
  "metodo": "ml_ensemble"
}
```

**Response:**
```json
{
  "valor_uf": 4500.25,
  "valor_clp": 168759375,
  "confidence": 0.92,
  "metodo_usado": "ml_ensemble",
  "comparables_usados": 15,
  "fecha_avaluo": "2026-02-07T10:30:00Z"
}
```

---

### M01-OF - Open Finance NCG514 (FastAPI)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/open-finance/consent` | Crear consentimiento |
| GET | `/open-finance/consent/{consentId}` | Estado consentimiento |
| DELETE | `/open-finance/consent/{consentId}` | Revocar consentimiento |
| GET | `/open-finance/accounts` | Listar cuentas |
| GET | `/open-finance/accounts/{accountId}` | Detalle cuenta |
| GET | `/open-finance/accounts/{accountId}/balances` | Saldos |
| GET | `/open-finance/accounts/{accountId}/transactions` | Transacciones |
| POST | `/open-finance/payments` | Iniciar pago (PIS) |
| GET | `/open-finance/payments/{paymentId}` | Estado pago |
| GET | `/open-finance/institutions` | Instituciones disponibles |
| GET | `/open-finance/directorio` | Directorio participantes |

**Headers adicionales (FAPI 2.0):**
```http
x-fapi-auth-date: Sun, 07 Feb 2026 10:00:00 GMT
x-fapi-customer-ip-address: 192.168.1.1
x-fapi-interaction-id: 93bac548-d2de-4546-b106-880a5018460d
```

---

### GT-PV - Plusvalías Ley 21.713 (Both)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/plusvalias/calcular` | Calcular plusvalía |
| GET | `/plusvalias/{id}` | Detalle cálculo |
| GET | `/plusvalias/propiedad/{propiedadId}` | Por propiedad |
| POST | `/plusvalias/simular` | Simular escenario |
| GET | `/plusvalias/historial/{propiedadId}` | Historial |
| POST | `/plusvalias/declaracion` | Generar declaración |
| GET | `/plusvalias/declaracion/{id}/pdf` | Descargar PDF |
| GET | `/plusvalias/tasas` | Tasas vigentes |
| GET | `/plusvalias/exenciones` | Exenciones aplicables |
| GET | `/plusvalias/obras-publicas` | Obras que generan plusvalía |
| GET | `/plusvalias/zonas-afectas` | Zonas afectas |

**Ejemplo - Calcular Plusvalía:**
```http
POST /plusvalias/calcular
Authorization: Bearer {token}

{
  "propiedad_id": 123,
  "fecha_calculo": "2026-02-07",
  "incluir_obras_publicas": true
}
```

**Response:**
```json
{
  "propiedad_id": 123,
  "valor_inicial_uf": 3000.00,
  "valor_final_uf": 4500.00,
  "plusvalia_bruta_uf": 1500.00,
  "deducciones_uf": 100.00,
  "plusvalia_neta_uf": 1400.00,
  "tasa_aplicada": 0.10,
  "impuesto_uf": 140.00,
  "exento": false,
  "obras_contribuyentes": ["Metro Línea 7", "Parque Urbano"]
}
```

---

### M17 - GIRES Riesgos (FastAPI)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/gires/riesgos/{ubicacionId}` | Riesgos por ubicación |
| POST | `/gires/analisis` | Análisis de riesgos |
| GET | `/gires/alertas` | Alertas activas |
| GET | `/gires/zonas` | Zonas de riesgo |
| GET | `/gires/mapas/{tipo}` | Mapas (sismico/tsunami/...) |
| POST | `/gires/batch-query` | Consulta batch |

**Ejemplo - Riesgos por Ubicación:**
```http
GET /gires/riesgos/12345
Authorization: Bearer {token}
```

**Response:**
```json
{
  "ubicacion_id": "12345",
  "coordenadas": { "lat": -33.4489, "lng": -70.6693 },
  "riesgos": [
    { "tipo": "sismico", "nivel": "alto", "score": 0.75 },
    { "tipo": "inundacion", "nivel": "bajo", "score": 0.15 },
    { "tipo": "tsunami", "nivel": "muy_bajo", "score": 0.05 }
  ],
  "score_global": 0.32,
  "recomendaciones": [...]
}
```

---

### M22 - ÁGORA GeoViewer (Both)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/agora/capas` | Listar capas |
| POST | `/agora/capas` | Crear capa |
| GET | `/agora/capas/{id}` | Obtener capa |
| GET | `/agora/tiles/{z}/{x}/{y}` | Tiles de mapa |
| GET | `/agora/features` | Features GeoJSON |
| POST | `/agora/query` | Query espacial |
| POST | `/agora/intersect` | Intersección |
| POST | `/agora/buffer` | Buffer |
| GET | `/agora/prc/{comuna}` | Plan Regulador Comunal |
| POST | `/agora/zonificacion` | Consultar zonificación |
| GET | `/agora/normativa/{zonaId}` | Normativa de zona |
| POST | `/agora/analisis-territorial` | Análisis territorial |
| POST | `/agora/geocoding` | Geocodificación |

---

### IE - Indicadores Económicos (FastAPI)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/indicadores/uf` | Valor UF actual |
| GET | `/indicadores/utm` | Valor UTM actual |
| GET | `/indicadores/ipc` | IPC actual |
| GET | `/indicadores/dolar` | USD/CLP |
| GET | `/indicadores/euro` | EUR/CLP |
| GET | `/indicadores/tpm` | Tasa Política Monetaria |
| GET | `/indicadores/historico/{tipo}` | Serie histórica |
| GET | `/indicadores/convertir` | Convertir valores |

**Ejemplo - Valor UF:**
```http
GET /indicadores/uf?fecha=2026-02-07
Authorization: Bearer {token}
```

**Response:**
```json
{
  "codigo": "uf",
  "valor": 37501.23,
  "fecha": "2026-02-07",
  "fuente": "BCCH"
}
```

---

## Códigos de Error

| Código | Descripción |
|--------|-------------|
| 200 | OK |
| 201 | Created |
| 204 | No Content |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 422 | Validation Error |
| 429 | Too Many Requests |
| 500 | Internal Server Error |

**Formato de Error:**
```json
{
  "message": "Error message",
  "errors": {
    "field": ["Validation error message"]
  }
}
```

---

## Paginación

```http
GET /expedientes?page=2&per_page=20
```

**Response:**
```json
{
  "data": [...],
  "meta": {
    "current_page": 2,
    "last_page": 10,
    "per_page": 20,
    "total": 195
  }
}
```

---

## Rate Limiting

| Tipo | Límite |
|------|--------|
| Standard | 1000 req/min |
| Open Finance | 100 req/min |
| Batch Operations | 10 req/min |

Headers de respuesta:
```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1707300000
```

---

**DATAPOLIS v3.0** | API Reference | Febrero 2026
