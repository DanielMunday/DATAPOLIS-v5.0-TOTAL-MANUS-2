# DATAPOLIS v3.0 - Arquitectura Técnica

## 1. Visión General

DATAPOLIS v3.0 es una plataforma integral PropTech/FinTech/RegTech/GovTech que unifica la gestión inmobiliaria, análisis financiero, cumplimiento regulatorio e inteligencia territorial.

### Métricas del Sistema

| Componente | Cantidad |
|------------|----------|
| Módulos | 23 |
| Endpoints | 450+ |
| Líneas de código | ~160,000 |
| Tablas de BD | 64 |
| Backends | 2 (FastAPI + Laravel) |

---

## 2. Arquitectura de Alto Nivel

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              CLIENTES                                    │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐                    │
│  │ Web App │  │ Mobile  │  │  API    │  │ B2B     │                    │
│  │ (Vue.js)│  │  App    │  │ Partners│  │ Integr. │                    │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘                    │
│       └────────────┴────────────┴────────────┘                          │
│                           │                                              │
│  ┌────────────────────────┴────────────────────────┐                    │
│  │              API GATEWAY (Kong/Nginx)           │                    │
│  │  • Rate Limiting  • Auth  • SSL/TLS  • CORS    │                    │
│  └────────────────────────┬────────────────────────┘                    │
│                           │                                              │
│       ┌───────────────────┼───────────────────┐                         │
│       │                   │                   │                         │
│  ┌────┴────┐        ┌────┴────┐        ┌────┴────┐                     │
│  │ FASTAPI │        │ LARAVEL │        │ WORKERS │                     │
│  │ :8001   │        │ :8000   │        │ (Queue) │                     │
│  │         │        │         │        │         │                     │
│  │ • ML/AI │        │ • CRUD  │        │ • Jobs  │                     │
│  │ • OF    │        │ • PAE   │        │ • Email │                     │
│  │ • Score │        │ • Auth  │        │ • PDF   │                     │
│  └────┬────┘        └────┬────┘        └────┬────┘                     │
│       │                  │                   │                          │
│  ┌────┴──────────────────┴───────────────────┴────┐                    │
│  │              DATA LAYER                         │                    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐     │                    │
│  │  │PostgreSQL│  │  Redis   │  │  MinIO   │     │                    │
│  │  │+ PostGIS │  │  Cache   │  │  Files   │     │                    │
│  │  └──────────┘  └──────────┘  └──────────┘     │                    │
│  └─────────────────────────────────────────────────┘                    │
│                                                                          │
│  ┌─────────────────────────────────────────────────┐                    │
│  │           EXTERNAL INTEGRATIONS                  │                    │
│  │  SII │ CMF │ BCCH │ MINVU │ SHOA │ CONAF       │                    │
│  └─────────────────────────────────────────────────┘                    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Stack Tecnológico

### Backend FastAPI (Python)
- **Framework**: FastAPI 0.109+
- **ORM**: SQLAlchemy 2.0
- **ML**: scikit-learn, XGBoost, LightGBM
- **Async**: asyncio, httpx
- **Validation**: Pydantic v2

### Backend Laravel (PHP)
- **Framework**: Laravel 11
- **Auth**: Sanctum
- **Queue**: Redis + Horizon
- **Permissions**: Spatie Laravel Permission

### Frontend
- **Framework**: Vue.js 3.4
- **State**: Pinia
- **Router**: Vue Router 4
- **Maps**: Leaflet + Turf.js
- **Charts**: Chart.js
- **CSS**: TailwindCSS 3.4

### Base de Datos
- **Principal**: PostgreSQL 15
- **GIS**: PostGIS 3.3
- **Cache**: Redis 7
- **Search**: PostgreSQL FTS

### Infraestructura
- **Containers**: Docker + Docker Compose
- **CI/CD**: GitHub Actions
- **Reverse Proxy**: Nginx / Kong
- **SSL**: Let's Encrypt

---

## 4. Dominios y Módulos

### 4.1 PropTech (Gestión Inmobiliaria)

| Código | Módulo | Descripción | Backend |
|--------|--------|-------------|---------|
| M00 | Expediente | Gestión de casos inmobiliarios | Laravel |
| M01 | Ficha Propiedad | Fichas detalladas | Both |
| M02 | Copropiedad | Gestión Ley 21.442 | Laravel |
| M05 | Arriendos | Contratos y SCF | Laravel |
| M06 | Mantenciones | Gestión de mantenciones | Laravel |
| MS | Mercado Suelo | Análisis de mercado | FastAPI |

### 4.2 FinTech (Servicios Financieros)

| Código | Módulo | Descripción | Backend |
|--------|--------|-------------|---------|
| M01-OF | Open Finance | NCG 514 FAPI 2.0 | FastAPI |
| M03 | Credit Scoring | Basel IV (PD/LGD/EAD) | FastAPI |
| M04 | Valorización | Avalúo ML | FastAPI |
| M07 | Inversiones | Análisis ROI/TIR/VAN | FastAPI |
| M08 | Contabilidad | IFRS y reportería | Laravel |
| M13 | Garantías | Colaterales Basel IV | Both |
| RR | Rentabilidad Real | Análisis financiero | FastAPI |

### 4.3 RegTech (Cumplimiento)

| Código | Módulo | Descripción | Backend |
|--------|--------|-------------|---------|
| M11 | PAE | Precession Analysis Engine | Laravel |
| M14 | Reavalúo SII | Integración SII | FastAPI |
| M16 | Basel IV | Motor regulatorio | FastAPI |
| GT-PV | Plusvalías | Ley 21.713 | Both |

### 4.4 GovTech (Gobierno)

| Código | Módulo | Descripción | Backend |
|--------|--------|-------------|---------|
| M17 | GIRES | Riesgos naturales | FastAPI |
| M22 | ÁGORA | GeoViewer territorial | Both |

### 4.5 DataTech (Datos e IA)

| Código | Módulo | Descripción | Backend |
|--------|--------|-------------|---------|
| IE | Indicadores | UF, UTM, IPC, TPM | FastAPI |

---

## 5. Patrones de Arquitectura

### 5.1 Arquitectura Hexagonal

```
┌─────────────────────────────────────────┐
│              APPLICATION                 │
│  ┌─────────────────────────────────┐    │
│  │         USE CASES               │    │
│  │  ┌───────────────────────────┐  │    │
│  │  │      DOMAIN MODEL         │  │    │
│  │  │  • Entities               │  │    │
│  │  │  • Value Objects          │  │    │
│  │  │  • Business Rules         │  │    │
│  │  └───────────────────────────┘  │    │
│  └─────────────────────────────────┘    │
├─────────────────────────────────────────┤
│   PORTS (Interfaces)                    │
│   • Input: Controllers, CLI, Events     │
│   • Output: Repositories, Services      │
├─────────────────────────────────────────┤
│   ADAPTERS                              │
│   • REST API  • Database  • External    │
└─────────────────────────────────────────┘
```

### 5.2 CQRS (Command Query Responsibility Segregation)

- **Commands**: Operaciones de escritura a través de Services
- **Queries**: Operaciones de lectura optimizadas
- **Event Sourcing**: Para PAE y audit trail

### 5.3 Multi-Tenancy

```php
// Tenant-aware queries
Copropiedad::query()
    ->where('tenant_id', auth()->user()->tenant_id)
    ->get();
```

---

## 6. Seguridad

### 6.1 Capas de Seguridad

| Capa | Tecnología | Propósito |
|------|------------|-----------|
| Network | WAF, DDoS Protection | Protección perimetral |
| Transport | TLS 1.3, mTLS | Cifrado en tránsito |
| API Gateway | Rate Limiting, JWT | Control de acceso |
| Application | RBAC, Sanctum | Autorización |
| Data | AES-256, bcrypt | Cifrado en reposo |

### 6.2 Open Finance (FAPI 2.0)

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│  Client  │────▶│ Auth     │────▶│ Resource │
│  (TPP)   │◀────│ Server   │◀────│ Server   │
└──────────┘     └──────────┘     └──────────┘
     │                │                │
     │    mTLS        │    OAuth2      │
     │    PKCE        │    JWT         │
     └────────────────┴────────────────┘
```

### 6.3 Roles y Permisos

| Rol | Descripción | Permisos |
|-----|-------------|----------|
| super_admin | Administrador del sistema | Todos |
| admin | Administrador de tenant | CRUD en su tenant |
| manager | Gerente/Supervisor | Operaciones + reportes |
| accountant | Contador | Contabilidad + certificados |
| operator | Operador | Operaciones básicas |
| viewer | Visualizador | Solo lectura |

---

## 7. Base de Datos

### 7.1 Esquema Principal

```sql
-- Multi-tenancy
tenants (id, name, slug, settings)
users (id, tenant_id, name, email, password)

-- PropTech
copropiedades (id, tenant_id, nombre, rut, direccion, ...)
unidades (id, copropiedad_id, numero, tipo, superficie_m2, ...)
antenas (id, copropiedad_id, empresa, monto_mensual, ...)
propiedades (id, tenant_id, rol, direccion, tipo, ...)
expedientes (id, tenant_id, titulo, tipo, estado, ...)

-- FinTech
garantias (id, propiedad_id, tipo, valor_uf, ltv, ...)
credit_scores (id, entity_type, entity_id, score, pd, lgd, ead, rwa, ...)

-- RegTech
pae_analyses (id, copropiedad_id, score_total, scores, ...)
pae_alerts (id, copropiedad_id, severity, type, message, ...)
plusvalias (id, propiedad_id, valor_inicial_uf, plusvalia_neta_uf, ...)

-- GovTech (PostGIS)
gires_zonas (id, tipo, geometria GEOMETRY, nivel_riesgo, ...)
agora_capas (id, nombre, geometria GEOMETRY, metadata, ...)

-- DataTech
indicadores_economicos (id, tipo, valor, fecha, fuente)
```

### 7.2 Índices Críticos

```sql
CREATE INDEX idx_copropiedades_tenant_comuna ON copropiedades(tenant_id, comuna);
CREATE INDEX idx_unidades_estado_pago ON unidades(copropiedad_id, estado_pago);
CREATE INDEX idx_pae_alerts_status ON pae_alerts(copropiedad_id, status, severity);
CREATE INDEX idx_propiedades_geom ON propiedades USING GIST(geom);
```

---

## 8. APIs

### 8.1 REST API

- **Base URL**: `/api/v1`
- **Auth**: Bearer Token (JWT)
- **Format**: JSON
- **Pagination**: `?page=1&per_page=15`

### 8.2 OpenAPI Specification

Disponible en:
- `/api/docs` (Swagger UI)
- `/api/openapi.yaml` (Spec file)

### 8.3 Endpoints por Backend

| Backend | Endpoints | Responsabilidad |
|---------|-----------|-----------------|
| FastAPI | 264 | ML, Analytics, Open Finance |
| Laravel | 186 | CRUD, PAE, Auth, Files |

---

## 9. Integraciones Externas

| Servicio | API | Propósito |
|----------|-----|-----------|
| SII | REST | Avalúos fiscales, certificados |
| CMF | FAPI 2.0 | Open Finance NCG 514 |
| BCCH | REST | UF, UTM, IPC, TPM |
| MINVU | WFS/WMS | Normativa urbana |
| SHOA | REST | Zonas de tsunami |
| SERNAGEOMIN | REST | Riesgos geológicos |
| CONAF | REST | Zonas de incendio |

---

## 10. Despliegue

### 10.1 Docker Compose

```yaml
services:
  fastapi:
    build: ./backend/fastapi
    ports: ["8001:8000"]
    depends_on: [postgres, redis]
    
  laravel:
    build: ./backend/laravel
    ports: ["8000:80"]
    depends_on: [postgres, redis]
    
  frontend:
    build: ./frontend
    ports: ["3000:80"]
    
  postgres:
    image: postgis/postgis:15-3.3
    volumes: [pgdata:/var/lib/postgresql/data]
    
  redis:
    image: redis:7-alpine
```

### 10.2 Requisitos de Hardware

| Ambiente | CPU | RAM | Disco |
|----------|-----|-----|-------|
| Desarrollo | 2 cores | 4 GB | 20 GB |
| Staging | 4 cores | 8 GB | 50 GB |
| Producción | 8+ cores | 16+ GB | 100+ GB |

---

## 11. Monitoreo

### Métricas Clave

- Response time (p50, p95, p99)
- Error rate
- Throughput (req/s)
- Database connections
- Cache hit ratio
- Queue depth

### Herramientas

- **Logs**: Structured JSON logging
- **Metrics**: Prometheus
- **Dashboards**: Grafana
- **APM**: Sentry

---

**DATAPOLIS v3.0** | Arquitectura Técnica | Febrero 2026
