# DATAPOLIS v3.0 - Guía de Despliegue en cPanel

## Requisitos Previos

### Hosting cPanel
- PHP 8.2+
- MySQL 8.0+ o PostgreSQL 15+
- Node.js 18+ (opcional para build)
- Acceso SSH
- SSL/TLS habilitado
- Cron Jobs habilitado

### Dominios Sugeridos
- `app.tudominio.com` - Frontend
- `api.tudominio.com` - Laravel API
- `ml.tudominio.com` - FastAPI (requiere Python)

---

## Paso 1: Preparar Archivos

### 1.1 En tu máquina local

```bash
# Descomprimir paquete
unzip DATAPOLIS_v3_Full.zip
cd DATAPOLIS_v3_Full

# Build del frontend
cd frontend
npm install
npm run build
# Resultado en: frontend/dist/

# Preparar Laravel
cd ../backend/laravel
composer install --optimize-autoloader --no-dev
```

### 1.2 Crear archivo .env para Laravel

```bash
cp .env.example .env
# Editar .env con tus credenciales
```

---

## Paso 2: Subir Archivos via cPanel

### 2.1 Acceder al File Manager

1. Login a cPanel
2. Ir a **File Manager**
3. Navegar a `public_html`

### 2.2 Estructura de Directorios

```
/home/usuario/
├── public_html/
│   ├── app/                    # Frontend Vue.js
│   │   └── (contenido de dist/)
│   │
│   └── api/                    # Laravel public/
│       └── (contenido de public/)
│
├── datapolis/                  # Código Laravel (fuera de public_html)
│   ├── app/
│   ├── bootstrap/
│   ├── config/
│   ├── database/
│   ├── routes/
│   ├── storage/
│   ├── vendor/
│   ├── .env
│   └── artisan
│
└── logs/
```

### 2.3 Subir Frontend

1. Comprimir carpeta `frontend/dist/` como ZIP
2. Subir a `public_html/app/`
3. Extraer
4. Eliminar ZIP

### 2.4 Subir Laravel

1. Comprimir carpeta `backend/laravel/` como ZIP
2. Subir a `/home/usuario/datapolis/`
3. Extraer
4. Mover contenido de `public/` a `public_html/api/`

---

## Paso 3: Configurar Base de Datos

### 3.1 Crear Base de Datos en cPanel

1. Ir a **MySQL Databases** o **PostgreSQL Databases**
2. Crear base de datos: `usuario_datapolis`
3. Crear usuario: `usuario_datapolis_user`
4. Asignar permisos completos

### 3.2 Si usas PostgreSQL

```sql
-- Conectar via phpPgAdmin o SSH
CREATE EXTENSION postgis;
CREATE EXTENSION pg_trgm;
```

---

## Paso 4: Configurar Laravel

### 4.1 Editar .env

Via File Manager, editar `/home/usuario/datapolis/.env`:

```env
APP_NAME=DATAPOLIS
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://api.tudominio.com

DB_CONNECTION=pgsql
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=usuario_datapolis
DB_USERNAME=usuario_datapolis_user
DB_PASSWORD=tu_password_seguro

CACHE_DRIVER=file
SESSION_DRIVER=file
QUEUE_CONNECTION=database
```

### 4.2 Configurar index.php

Editar `public_html/api/index.php`:

```php
<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Verificar modo mantenimiento
if (file_exists($maintenance = __DIR__.'/../datapolis/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Autoloader - AJUSTAR RUTA
require __DIR__.'/../../datapolis/vendor/autoload.php';

// Bootstrap - AJUSTAR RUTA
$app = require_once __DIR__.'/../../datapolis/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);

$response = $kernel->handle(
    $request = Request::capture()
)->send();

$kernel->terminate($request, $response);
```

### 4.3 Ejecutar Comandos via SSH

```bash
# Conectar por SSH
ssh usuario@tudominio.com

# Navegar al directorio
cd ~/datapolis

# Generar key
php artisan key:generate

# Migraciones
php artisan migrate --force

# Seeders (opcional)
php artisan db:seed

# Optimizar
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Permisos
chmod -R 755 storage bootstrap/cache
```

---

## Paso 5: Configurar .htaccess

### 5.1 Frontend (public_html/app/.htaccess)

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^index\.html$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>

# Seguridad
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
</IfModule>
```

### 5.2 API Laravel (public_html/api/.htaccess)

```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews -Indexes
    </IfModule>

    RewriteEngine On

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # Redirect Trailing Slashes
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} (.+)/$
    RewriteRule ^ %1 [L,R=301]

    # Send Requests To Front Controller
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
</IfModule>

# CORS Headers
<IfModule mod_headers.c>
    Header set Access-Control-Allow-Origin "https://app.tudominio.com"
    Header set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header set Access-Control-Allow-Headers "Content-Type, Authorization, X-Requested-With"
</IfModule>
```

---

## Paso 6: Configurar SSL

### 6.1 Via cPanel

1. Ir a **SSL/TLS Status**
2. Seleccionar dominios
3. Click **Run AutoSSL**

### 6.2 Forzar HTTPS

Agregar a `.htaccess` principal:

```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## Paso 7: Configurar Cron Jobs

### 7.1 Via cPanel

Ir a **Cron Jobs** y agregar:

```bash
# Laravel Scheduler (cada minuto)
* * * * * cd /home/usuario/datapolis && php artisan schedule:run >> /dev/null 2>&1

# Queue Worker (cada 5 minutos, reinicia si no está corriendo)
*/5 * * * * cd /home/usuario/datapolis && php artisan queue:work --stop-when-empty >> /dev/null 2>&1
```

---

## Paso 8: Verificación Post-Deploy

### 8.1 Health Checks

```bash
# API Laravel
curl -s https://api.tudominio.com/api/v1/health
# Esperado: {"status":"healthy","version":"3.0.0"}

# Frontend
curl -s -o /dev/null -w "%{http_code}" https://app.tudominio.com
# Esperado: 200
```

### 8.2 Test de Login

```bash
curl -X POST https://api.tudominio.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@tudominio.com","password":"password"}'
```

### 8.3 Checklist Post-Deploy

| Ítem | Verificar |
|------|-----------|
| ✅ | SSL activo en todos los dominios |
| ✅ | API responde en /api/v1/health |
| ✅ | Frontend carga correctamente |
| ✅ | Login funciona |
| ✅ | Base de datos conectada |
| ✅ | Cron jobs configurados |
| ✅ | Permisos de storage correctos |
| ✅ | .env en producción (APP_DEBUG=false) |

---

## Paso 9: FastAPI (Opcional - Requiere VPS/Cloud)

> **Nota:** La mayoría de hostings cPanel compartidos no soportan Python/FastAPI. Para esta funcionalidad se recomienda:
> - VPS con acceso root
> - Cloud (AWS, GCP, DigitalOcean)
> - Heroku / Railway / Render

### 9.1 Si tienes acceso Python

```bash
# Via SSH
cd ~/datapolis-fastapi
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Configurar como servicio (si tienes acceso)
# O usar passenger_wsgi.py
```

### 9.2 Alternativa: Separar servicios

- Laravel en cPanel: CRUD, PAE, Auth
- FastAPI en cloud separado: ML, Open Finance

---

## Solución de Problemas

### Error 500

```bash
# Verificar logs
tail -f ~/datapolis/storage/logs/laravel.log

# Verificar permisos
chmod -R 755 ~/datapolis/storage
chmod -R 755 ~/datapolis/bootstrap/cache
```

### Error de Base de Datos

```bash
# Verificar conexión
php artisan db:show

# Verificar migraciones
php artisan migrate:status
```

### CORS Errors

Verificar headers en `.htaccess` y en `config/cors.php` de Laravel.

### Cache Issues

```bash
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
```

---

## Comandos Útiles SSH

```bash
# Estado de la aplicación
php artisan about

# Verificar rutas
php artisan route:list

# Crear usuario admin
php artisan tinker
>>> User::create(['name'=>'Admin','email'=>'admin@tudominio.com','password'=>bcrypt('password'),'tenant_id'=>1])

# Backup de base de datos
pg_dump -U usuario_datapolis_user usuario_datapolis > backup.sql
```

---

**DATAPOLIS v3.0** | Despliegue cPanel | Febrero 2026
