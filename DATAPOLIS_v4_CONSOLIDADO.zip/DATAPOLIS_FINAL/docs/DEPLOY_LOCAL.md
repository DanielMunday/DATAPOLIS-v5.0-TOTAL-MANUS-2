# DATAPOLIS v3.0 - Guía de Despliegue Local

## Requisitos del Sistema

### Hardware Mínimo
- CPU: 4 cores
- RAM: 8 GB
- Disco: 20 GB libres

### Software Requerido
- Ubuntu 22.04+ / macOS 12+ / Windows 11 (WSL2)
- Python 3.11+
- PHP 8.2+
- Node.js 20+
- PostgreSQL 15+ con PostGIS 3.3
- Redis 7+
- Composer 2.x
- npm/yarn

---

## Opción 1: Docker (Recomendado)

### Instalación Rápida

```bash
# 1. Clonar/Descomprimir
cd DATAPOLIS_v3_Full

# 2. Configurar variables de entorno
cp .env.example .env
# Editar .env con configuraciones locales

# 3. Levantar servicios
docker-compose up -d

# 4. Ejecutar migraciones
docker-compose exec laravel php artisan migrate --seed

# 5. Verificar
curl http://localhost:8000/api/v1/health
curl http://localhost:8001/health
```

### Servicios y Puertos

| Servicio | Puerto | URL |
|----------|--------|-----|
| Frontend | 3000 | http://localhost:3000 |
| Laravel API | 8000 | http://localhost:8000 |
| FastAPI | 8001 | http://localhost:8001 |
| PostgreSQL | 5432 | localhost:5432 |
| Redis | 6379 | localhost:6379 |

---

## Opción 2: Instalación Manual

### Paso 1: Instalar Dependencias del Sistema

```bash
# Ubuntu 22.04/24.04
sudo apt update && sudo apt upgrade -y

# Python 3.11
sudo apt install python3.11 python3.11-venv python3-pip -y

# PHP 8.2
sudo apt install php8.2 php8.2-fpm php8.2-cli php8.2-pgsql php8.2-mbstring \
    php8.2-xml php8.2-curl php8.2-zip php8.2-bcmath php8.2-redis -y

# Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install nodejs -y

# PostgreSQL 15 + PostGIS
sudo apt install postgresql-15 postgresql-15-postgis-3.3 -y

# Redis
sudo apt install redis-server -y

# Nginx
sudo apt install nginx -y

# Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
```

### Paso 2: Configurar PostgreSQL

```bash
# Crear usuario y base de datos
sudo -u postgres psql << EOF
CREATE USER datapolis WITH PASSWORD 'datapolis_secure_password';
CREATE DATABASE datapolis_db OWNER datapolis;
\c datapolis_db
CREATE EXTENSION postgis;
CREATE EXTENSION pg_trgm;
GRANT ALL PRIVILEGES ON DATABASE datapolis_db TO datapolis;
EOF
```

### Paso 3: Configurar Backend Laravel

```bash
cd backend/laravel

# Instalar dependencias
composer install --optimize-autoloader --no-dev

# Configurar entorno
cp .env.example .env

# Editar .env
cat >> .env << EOF
APP_NAME=DATAPOLIS
APP_ENV=local
APP_KEY=
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=datapolis_db
DB_USERNAME=datapolis
DB_PASSWORD=datapolis_secure_password

REDIS_HOST=127.0.0.1
REDIS_PORT=6379

CACHE_DRIVER=redis
SESSION_DRIVER=redis
QUEUE_CONNECTION=redis
EOF

# Generar key
php artisan key:generate

# Ejecutar migraciones
php artisan migrate --seed

# Optimizar
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Permisos
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Paso 4: Configurar Backend FastAPI

```bash
cd backend/fastapi

# Crear entorno virtual
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Configurar entorno
cat > .env << EOF
DATABASE_URL=postgresql://datapolis:datapolis_secure_password@localhost:5432/datapolis_db
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=$(openssl rand -hex 32)
DEBUG=true
CORS_ORIGINS=http://localhost:3000,http://localhost:8000
EOF

# Verificar
python -c "from app.main import app; print('FastAPI OK')"
```

### Paso 5: Configurar Frontend

```bash
cd frontend

# Instalar dependencias
npm install

# Configurar entorno
cat > .env << EOF
VITE_API_URL=http://localhost:8000/api/v1
VITE_FASTAPI_URL=http://localhost:8001/api/v1
EOF

# Build para producción (opcional)
npm run build
```

### Paso 6: Configurar Nginx

```bash
sudo tee /etc/nginx/sites-available/datapolis << 'EOF'
# Frontend
server {
    listen 3000;
    server_name localhost;
    root /var/www/datapolis/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}

# Laravel API
server {
    listen 8000;
    server_name localhost;
    root /var/www/datapolis/backend/laravel/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
}

# FastAPI Proxy
server {
    listen 8001;
    server_name localhost;

    location / {
        proxy_pass http://127.0.0.1:8002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/datapolis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Paso 7: Configurar Servicios Systemd

```bash
# FastAPI Service
sudo tee /etc/systemd/system/datapolis-fastapi.service << 'EOF'
[Unit]
Description=DATAPOLIS FastAPI
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/datapolis/backend/fastapi
Environment="PATH=/var/www/datapolis/backend/fastapi/venv/bin"
ExecStart=/var/www/datapolis/backend/fastapi/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8002 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Laravel Queue Worker
sudo tee /etc/systemd/system/datapolis-queue.service << 'EOF'
[Unit]
Description=DATAPOLIS Laravel Queue Worker
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/datapolis/backend/laravel
ExecStart=/usr/bin/php artisan queue:work --sleep=3 --tries=3 --max-time=3600
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Habilitar servicios
sudo systemctl daemon-reload
sudo systemctl enable datapolis-fastapi datapolis-queue
sudo systemctl start datapolis-fastapi datapolis-queue
```

---

## Verificación de Instalación

### Health Checks

```bash
# Laravel
curl -s http://localhost:8000/api/v1/health | jq .
# Esperado: {"status":"healthy","version":"3.0.0"}

# FastAPI
curl -s http://localhost:8001/health | jq .
# Esperado: {"status":"healthy","version":"3.0.0"}

# PostgreSQL
psql -U datapolis -d datapolis_db -c "SELECT 1"

# Redis
redis-cli ping
# Esperado: PONG
```

### Validación Completa

```bash
# Ejecutar script de validación
bash scripts/validate_100_percent.sh
```

### Tests

```bash
# Tests E2E
cd tests && pytest test_e2e.py -v

# Tests Laravel
cd backend/laravel && php artisan test

# Tests FastAPI
cd backend/fastapi && pytest tests/ -v
```

---

## Crear Usuario Administrador

```bash
cd backend/laravel
php artisan tinker

# En tinker:
>>> use App\Models\User;
>>> User::create([
...     'name' => 'Admin',
...     'email' => 'admin@datapolis.cl',
...     'password' => bcrypt('admin123'),
...     'tenant_id' => 1
... ]);
>>> exit
```

---

## Solución de Problemas

### Error: Connection refused (PostgreSQL)

```bash
sudo systemctl status postgresql
sudo systemctl start postgresql
sudo -u postgres psql -c "SELECT 1"
```

### Error: Permission denied (Laravel)

```bash
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache
```

### Error: Module not found (FastAPI)

```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Ver logs

```bash
# Laravel
tail -f backend/laravel/storage/logs/laravel.log

# FastAPI
journalctl -u datapolis-fastapi -f

# Nginx
tail -f /var/log/nginx/error.log
```

---

## Comandos Útiles

```bash
# Reiniciar servicios
sudo systemctl restart nginx php8.2-fpm datapolis-fastapi datapolis-queue

# Limpiar caché Laravel
cd backend/laravel
php artisan cache:clear
php artisan config:clear
php artisan route:clear

# Ver estado de todos los servicios
sudo systemctl status nginx php8.2-fpm postgresql redis datapolis-fastapi datapolis-queue
```

---

**DATAPOLIS v3.0** | Despliegue Local | Febrero 2026
