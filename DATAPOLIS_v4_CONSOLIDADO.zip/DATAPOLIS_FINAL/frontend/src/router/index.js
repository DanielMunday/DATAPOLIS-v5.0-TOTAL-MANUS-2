import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

// Views
import LoginView from '@/views/LoginView.vue'
import DashboardView from '@/views/DashboardView.vue'
import ExpedientesView from '@/views/ExpedientesView.vue'
import PropiedadesView from '@/views/PropiedadesView.vue'
import CopropiedadesView from '@/views/CopropiedadesView.vue'
import CopropiedadDetailView from '@/views/CopropiedadDetailView.vue'
import PlusvaliaView from '@/views/PlusvaliaView.vue'
import AgoraView from '@/views/AgoraView.vue'
import GiresView from '@/views/GiresView.vue'
import OpenFinanceView from '@/views/OpenFinanceView.vue'
import CreditScoringView from '@/views/CreditScoringView.vue'

const routes = [
  {
    path: '/login',
    name: 'login',
    component: LoginView,
    meta: { requiresAuth: false }
  },
  {
    path: '/',
    name: 'dashboard',
    component: DashboardView,
    meta: { requiresAuth: true }
  },
  {
    path: '/expedientes',
    name: 'expedientes',
    component: ExpedientesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/propiedades',
    name: 'propiedades',
    component: PropiedadesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/copropiedades',
    name: 'copropiedades',
    component: CopropiedadesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/copropiedades/:id',
    name: 'copropiedad-detail',
    component: CopropiedadDetailView,
    meta: { requiresAuth: true }
  },
  {
    path: '/plusvalia',
    name: 'plusvalia',
    component: PlusvaliaView,
    meta: { requiresAuth: true }
  },
  {
    path: '/agora',
    name: 'agora',
    component: AgoraView,
    meta: { requiresAuth: true }
  },
  {
    path: '/gires',
    name: 'gires',
    component: GiresView,
    meta: { requiresAuth: true }
  },
  {
    path: '/open-finance',
    name: 'open-finance',
    component: OpenFinanceView,
    meta: { requiresAuth: true }
  },
  {
    path: '/credit-scoring',
    name: 'credit-scoring',
    component: CreditScoringView,
    meta: { requiresAuth: true }
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

// Navigation guard
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next({ name: 'login' })
  } else if (to.name === 'login' && authStore.isAuthenticated) {
    next({ name: 'dashboard' })
  } else {
    next()
  }
})

export default router
