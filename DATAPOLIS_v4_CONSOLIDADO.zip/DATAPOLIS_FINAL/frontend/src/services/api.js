import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
})

// Request interceptor
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  error => Promise.reject(error)
)

// Response interceptor
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api

// API Services
export const authService = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
}

export const expedientesService = {
  list: (params) => api.get('/expedientes', { params }),
  get: (id) => api.get(`/expedientes/${id}`),
  create: (data) => api.post('/expedientes', data),
  update: (id, data) => api.put(`/expedientes/${id}`, data),
  delete: (id) => api.delete(`/expedientes/${id}`),
}

export const copropiedadesService = {
  list: (params) => api.get('/copropiedades', { params }),
  get: (id) => api.get(`/copropiedades/${id}`),
  create: (data) => api.post('/copropiedades', data),
  update: (id, data) => api.put(`/copropiedades/${id}`, data),
  delete: (id) => api.delete(`/copropiedades/${id}`),
  dashboard: (id) => api.get(`/copropiedades/${id}/dashboard`),
  paeAnalyze: (id, options) => api.post(`/copropiedades/${id}/pae/analyze`, options),
  paeQuick: (id) => api.get(`/copropiedades/${id}/pae/quick`),
  paeAlerts: (id) => api.get(`/copropiedades/${id}/pae/alerts`),
}

export const propiedadesService = {
  list: (params) => api.get('/fichas', { params }),
  get: (id) => api.get(`/fichas/${id}`),
  create: (data) => api.post('/fichas', data),
  fichaCompleta: (id) => api.get(`/fichas/${id}/ficha-completa`),
}

export const creditScoringService = {
  calculate: (data) => api.post('/credit-scoring/calculate', data),
  getPD: (entityId) => api.get(`/credit-scoring/pd/${entityId}`),
  getLGD: (entityId) => api.get(`/credit-scoring/lgd/${entityId}`),
  getRWA: (entityId) => api.get(`/credit-scoring/rwa/${entityId}`),
}

export const plusvaliaService = {
  calcular: (data) => api.post('/plusvalias/calcular', data),
  get: (id) => api.get(`/plusvalias/${id}`),
  simular: (data) => api.post('/plusvalias/simular', data),
  tasas: () => api.get('/plusvalias/tasas'),
  zonasAfectas: () => api.get('/plusvalias/zonas-afectas'),
}

export const giresService = {
  riesgos: (ubicacionId) => api.get(`/gires/riesgos/${ubicacionId}`),
  alertas: () => api.get('/gires/alertas'),
  mapas: (tipo) => api.get(`/gires/mapas/${tipo}`),
}

export const agoraService = {
  capas: () => api.get('/agora/capas'),
  query: (data) => api.post('/agora/query', data),
  prc: (comuna) => api.get(`/agora/prc/${comuna}`),
  zonificacion: (data) => api.post('/agora/zonificacion', data),
}

export const openFinanceService = {
  createConsent: (data) => api.post('/open-finance/consent', data),
  getConsent: (consentId) => api.get(`/open-finance/consent/${consentId}`),
  revokeConsent: (consentId) => api.delete(`/open-finance/consent/${consentId}`),
  accounts: () => api.get('/open-finance/accounts'),
  balances: (accountId) => api.get(`/open-finance/accounts/${accountId}/balances`),
  transactions: (accountId) => api.get(`/open-finance/accounts/${accountId}/transactions`),
  institutions: () => api.get('/open-finance/institutions'),
}

export const indicadoresService = {
  uf: (fecha) => api.get('/indicadores/uf', { params: { fecha } }),
  utm: () => api.get('/indicadores/utm'),
  ipc: () => api.get('/indicadores/ipc'),
  historico: (tipo, params) => api.get(`/indicadores/historico/${tipo}`, { params }),
}
