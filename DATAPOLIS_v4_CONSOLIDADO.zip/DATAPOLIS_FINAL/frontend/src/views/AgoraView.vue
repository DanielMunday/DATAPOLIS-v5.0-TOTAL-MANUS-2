<template>
  <div class="min-h-screen bg-gray-100 p-6">
    <div class="max-w-7xl mx-auto">
      <h1 class="text-2xl font-bold text-gray-900 mb-6">{{ title }}</h1>
      <div class="bg-white rounded-lg shadow p-6">
        <p class="text-gray-600">Módulo en desarrollo...</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const title = computed(() => route.name?.replace(/-/g, ' ').toUpperCase() || 'Módulo')
</script>
