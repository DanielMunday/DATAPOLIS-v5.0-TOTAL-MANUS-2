<template>
  <div class="min-h-screen bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow">
      <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-indigo-600">DATAPOLIS</h1>
        <div class="flex items-center space-x-4">
          <span class="text-gray-600">{{ authStore.userName }}</span>
          <button @click="handleLogout" class="text-sm text-gray-500 hover:text-gray-700">
            Cerrar Sesión
          </button>
        </div>
      </div>
    </header>

    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <!-- Navigation -->
      <nav class="flex space-x-4 mb-8 overflow-x-auto">
        <router-link 
          v-for="item in navItems" 
          :key="item.to"
          :to="item.to"
          class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap"
          :class="$route.path === item.to ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'"
        >
          {{ item.label }}
        </router-link>
      </nav>

      <!-- Stats -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div v-for="stat in stats" :key="stat.label" class="bg-white rounded-lg shadow p-6">
          <p class="text-sm font-medium text-gray-500">{{ stat.label }}</p>
          <p class="mt-2 text-3xl font-semibold text-gray-900">{{ stat.value }}</p>
          <p v-if="stat.change" :class="stat.change > 0 ? 'text-green-600' : 'text-red-600'" class="text-sm mt-2">
            {{ stat.change > 0 ? '+' : '' }}{{ stat.change }}%
          </p>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Recent Expedientes -->
        <div class="bg-white rounded-lg shadow p-6">
          <h2 class="text-lg font-semibold text-gray-900 mb-4">Expedientes Recientes</h2>
          <div class="space-y-3">
            <div v-for="exp in recentExpedientes" :key="exp.id" class="flex justify-between items-center p-3 bg-gray-50 rounded">
              <div>
                <p class="font-medium text-gray-900">{{ exp.titulo }}</p>
                <p class="text-sm text-gray-500">{{ exp.tipo }}</p>
              </div>
              <span :class="estadoClass(exp.estado)" class="px-2 py-1 text-xs rounded-full">
                {{ exp.estado }}
              </span>
            </div>
          </div>
          <router-link to="/expedientes" class="block mt-4 text-indigo-600 text-sm hover:underline">
            Ver todos →
          </router-link>
        </div>

        <!-- Alertas PAE -->
        <div class="bg-white rounded-lg shadow p-6">
          <h2 class="text-lg font-semibold text-gray-900 mb-4">Alertas PAE</h2>
          <div class="space-y-3">
            <div v-for="alert in paeAlerts" :key="alert.id" class="flex items-start space-x-3 p-3 rounded" :class="alertBgClass(alert.severity)">
              <div :class="alertIconClass(alert.severity)" class="w-2 h-2 mt-2 rounded-full"></div>
              <div>
                <p class="font-medium text-gray-900">{{ alert.message }}</p>
                <p class="text-sm text-gray-500">{{ alert.copropiedad }}</p>
              </div>
            </div>
          </div>
          <router-link to="/copropiedades" class="block mt-4 text-indigo-600 text-sm hover:underline">
            Ver todas →
          </router-link>
        </div>
      </div>

      <!-- Modules Grid -->
      <h2 class="text-lg font-semibold text-gray-900 mb-4">Módulos</h2>
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <router-link 
          v-for="module in modules" 
          :key="module.to"
          :to="module.to"
          class="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow"
        >
          <div class="text-3xl mb-2">{{ module.icon }}</div>
          <h3 class="font-semibold text-gray-900">{{ module.name }}</h3>
          <p class="text-sm text-gray-500 mt-1">{{ module.description }}</p>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const navItems = [
  { to: '/', label: 'Dashboard' },
  { to: '/expedientes', label: 'Expedientes' },
  { to: '/propiedades', label: 'Propiedades' },
  { to: '/copropiedades', label: 'Copropiedades' },
  { to: '/plusvalia', label: 'Plusvalías' },
  { to: '/agora', label: 'ÁGORA' },
  { to: '/gires', label: 'GIRES' },
  { to: '/open-finance', label: 'Open Finance' },
]

const stats = ref([
  { label: 'Expedientes Activos', value: '24', change: 12 },
  { label: 'Copropiedades', value: '156', change: 5 },
  { label: 'Tasa Morosidad Promedio', value: '8.3%', change: -2.1 },
  { label: 'Alertas PAE Activas', value: '7', change: null },
])

const recentExpedientes = ref([
  { id: 1, titulo: 'Compraventa Depto 1204', tipo: 'Compraventa', estado: 'activo' },
  { id: 2, titulo: 'Due Diligence Local 5', tipo: 'Due Diligence', estado: 'pendiente' },
  { id: 3, titulo: 'Tasación Parcela Lo Aguirre', tipo: 'Tasación', estado: 'cerrado' },
])

const paeAlerts = ref([
  { id: 1, severity: 'critical', message: 'Score financiero crítico', copropiedad: 'Edificio Los Robles' },
  { id: 2, severity: 'high', message: 'Morosidad > 20%', copropiedad: 'Condominio El Parque' },
  { id: 3, severity: 'medium', message: 'Asamblea pendiente', copropiedad: 'Torre Central' },
])

const modules = [
  { to: '/expedientes', icon: '📁', name: 'Expedientes', description: 'Gestión de casos' },
  { to: '/propiedades', icon: '🏠', name: 'Propiedades', description: 'Fichas inmobiliarias' },
  { to: '/copropiedades', icon: '🏢', name: 'Copropiedades', description: 'Ley 21.442' },
  { to: '/credit-scoring', icon: '📊', name: 'Credit Score', description: 'Basel IV' },
  { to: '/plusvalia', icon: '📈', name: 'Plusvalías', description: 'Ley 21.713' },
  { to: '/agora', icon: '🗺️', name: 'ÁGORA', description: 'GeoViewer' },
  { to: '/gires', icon: '⚠️', name: 'GIRES', description: 'Riesgos naturales' },
  { to: '/open-finance', icon: '🏦', name: 'Open Finance', description: 'NCG 514' },
]

function estadoClass(estado) {
  const classes = {
    activo: 'bg-green-100 text-green-800',
    pendiente: 'bg-yellow-100 text-yellow-800',
    cerrado: 'bg-gray-100 text-gray-800',
  }
  return classes[estado] || 'bg-gray-100 text-gray-800'
}

function alertBgClass(severity) {
  const classes = {
    critical: 'bg-red-50',
    high: 'bg-orange-50',
    medium: 'bg-yellow-50',
    low: 'bg-blue-50',
  }
  return classes[severity] || 'bg-gray-50'
}

function alertIconClass(severity) {
  const classes = {
    critical: 'bg-red-500',
    high: 'bg-orange-500',
    medium: 'bg-yellow-500',
    low: 'bg-blue-500',
  }
  return classes[severity] || 'bg-gray-500'
}

async function handleLogout() {
  await authStore.logout()
  router.push({ name: 'login' })
}

onMounted(async () => {
  await authStore.fetchUser()
})
</script>
