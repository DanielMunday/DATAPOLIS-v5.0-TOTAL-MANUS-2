#!/bin/bash
# ==============================================================================
# DATAPOLIS v3.0 - Build and Package Script
# ==============================================================================
set -e

VERSION="3.0.0"
DATE=$(date +%Y%m%d_%H%M%S)
OUTPUT_NAME="DATAPOLIS_v3_Full"

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║     DATAPOLIS v3.0 - Build & Package                          ║"
echo "╚═══════════════════════════════════════════════════════════════╝"

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

# 1. Validar
echo "[1/4] Validando estructura..."
bash scripts/validate_100_percent.sh || echo "Continuando con warnings..."

# 2. Preparar directorio
echo "[2/4] Preparando directorio de salida..."
rm -rf "$OUTPUT_NAME" "$OUTPUT_NAME.zip" 2>/dev/null || true
mkdir -p "$OUTPUT_NAME"

# 3. Copiar archivos
echo "[3/4] Copiando archivos..."
cp -r backend "$OUTPUT_NAME/"
cp -r frontend "$OUTPUT_NAME/"
cp -r docs "$OUTPUT_NAME/"
cp -r tests "$OUTPUT_NAME/"
cp -r scripts "$OUTPUT_NAME/"
cp -r ci "$OUTPUT_NAME/"
cp VERSION README.md docker-compose.yml "$OUTPUT_NAME/" 2>/dev/null || true

# Limpiar
find "$OUTPUT_NAME" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$OUTPUT_NAME" -name "*.pyc" -delete 2>/dev/null || true
find "$OUTPUT_NAME" -name ".DS_Store" -delete 2>/dev/null || true
rm -rf "$OUTPUT_NAME/backend/laravel/vendor" 2>/dev/null || true
rm -rf "$OUTPUT_NAME/frontend/node_modules" 2>/dev/null || true
rm -rf "$OUTPUT_NAME/backend/fastapi/venv" 2>/dev/null || true

# 4. Crear ZIP
echo "[4/4] Creando ZIP..."
zip -r "$OUTPUT_NAME.zip" "$OUTPUT_NAME" -x "*.git*" > /dev/null

# Resumen
SIZE=$(du -sh "$OUTPUT_NAME.zip" | cut -f1)
FILES=$(unzip -l "$OUTPUT_NAME.zip" | tail -1 | awk '{print $2}')

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "BUILD COMPLETADO"
echo "═══════════════════════════════════════════════════════════════"
echo "  Versión: $VERSION"
echo "  Archivo: $OUTPUT_NAME.zip"
echo "  Tamaño: $SIZE"
echo "  Archivos: $FILES"
echo ""
echo "Próximos pasos:"
echo "  1. Descomprimir: unzip $OUTPUT_NAME.zip"
echo "  2. Validar: bash scripts/validate_100_percent.sh"
echo "  3. Desplegar: Ver docs/DEPLOY_LOCAL.md o docs/DEPLOY_CPANEL.md"
